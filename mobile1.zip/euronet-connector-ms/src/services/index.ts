import { createProducer } from '../kafka/producer';
import { CompressionTypes, ProducerRecord } from 'kafkajs';
import axios, { AxiosResponse } from 'axios';
import { logger } from '../core/Logger';
import { euronetBaseUrl, axiosTimeOut, defaultErrorMessage } from '../config';
import { ConsumerHeader } from 'app-request';

export const handleT24Request = async (credentials: ConsumerHeader) => {
  const data = JSON.parse(credentials.data);
  try {
    let axiosData: AxiosResponse;
    if (!data.method) data.method = 'get';
    switch (data.method) {
      case 'post':
        axiosData = await axios.post(`${euronetBaseUrl}${data.route}`, data.body, {
          timeout: axiosTimeOut,
          headers: {
            'Content-Type': 'application/json',
            Authorization: data.authorization || '',
            'x-correlation-id': credentials.correlationId,
            ...credentials.tracingHeaders
          }
        });
        break;
      case 'delete':
        axiosData = await axios.delete(`${euronetBaseUrl}${data.route}`, {
          timeout: axiosTimeOut,
          headers: {
            'Content-Type': 'application/json',
            Authorization: data.authorization || '',
            'x-correlation-id': credentials.correlationId,
            ...credentials.tracingHeaders
          }
        });
        break;
      default:
        axiosData = await axios.get(`${euronetBaseUrl}${data.route}`, {
          timeout: axiosTimeOut,
          headers: {
            Authorization: data.authorization || '',
            'x-correlation-id': credentials.correlationId,
            ...credentials.tracingHeaders
          }
        });
        break;
    }
    if (axiosData.data && axiosData.data.Status) {
      const response = {
        error: false,
        message: axiosData.data
      };
      const producer = await createProducer();
      const producerOptions: ProducerRecord = {
        topic: credentials.replyTopic.toString(),
        compression: CompressionTypes.GZIP,
        messages: [
          {
            value: JSON.stringify(response),
            partition: Number(credentials.partitionReply),
            headers: {
              correlationId: credentials.correlationId
            }
          }
        ]
      };
      await producer.send(producerOptions);
      logger.info(data.route, { correlationId: credentials.correlationId, status: 200 });
    } else {
      logger.error(`${defaultErrorMessage} ${500} ${data.method || 'get'} ${data.route}`, {
        correlationId: credentials.correlationId
      });
      logger.debug(data.route, {
        correlationId: credentials.correlationId,
        error: axiosData.data.Message,
        status: 500
      });
      await handleT24Errors(credentials, axiosData.data.Message);
    }
  } catch (e) {
    logger.error(
      `${defaultErrorMessage} ${e.response ? e.response.status : 500} ${data.method || 'get'} ${
        data.route
      }`,
      {
        correlationId: credentials.correlationId
      }
    );
    logger.debug(data.route, {
      correlationId: credentials.correlationId,
      error: e.message,
      status: e.response ? e.response.status : 500
    });
    await handleT24Errors(credentials, e.response?.data?.Message || e.message);
  }
};

export const handleT24Errors = async (credentials: ConsumerHeader, error: string) => {
  const producer = await createProducer();
  const data = {
    error: true,
    message: error
  };
  const producerOptions: ProducerRecord = {
    topic: credentials.replyTopic.toString(),
    compression: CompressionTypes.GZIP,
    messages: [
      {
        value: JSON.stringify(data),
        partition: Number(credentials.partitionReply || 0),
        headers: {
          correlationId: credentials.correlationId
        }
      }
    ]
  };
  await producer.send(producerOptions);
};
