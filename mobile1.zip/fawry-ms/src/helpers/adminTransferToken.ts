import { AuthFailureError } from '../core/ApiError';
import { adminTransfersCredentials } from '../config';
import { logger } from '../core/Logger';
import * as config from '../config';
import axios from 'axios';

export default async () => {
  try {
    const body = {
      user: adminTransfersCredentials.username,
      password: adminTransfersCredentials.password
    };

    console.log('insideAdminREfreshToken', body);
    const url = `${config.t24Url}hid/generatetoken`;
    const result = await axios.post(url, body, { timeout: config.promiseTimeout });
    return String(result.data?.tokens?.accessToken || '');
  } catch (e) {
    console.log(e);
    logger.debug(e.message);
    throw new AuthFailureError();
  }
};
