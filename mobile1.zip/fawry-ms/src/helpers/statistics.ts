import { produce } from '../kafka';
import { kafkaTopics } from '../config';
import correlation from 'express-correlation-id';

export default async (updateValue: string, kibanaInfo = {}, correlationId = '') => {
  try {
    console.log(`correlationId inside updateStatisitcs :  ${correlationId}`);
    correlationId = correlationId || (correlation.getId() as string);
    if (updateValue) {
      const data = {
        topic: kafkaTopics.statistics,
        date: new Date(),
        updateValue
      };
      await produce(data, false, correlationId, {});
    }
    if (Object.keys(kibanaInfo).length) {
      const kibanaData = {
        topic: kafkaTopics.kibana,
        date: new Date(),
        kibanaInfo
      };
      await produce(kibanaData, false, correlationId, {});
    }
  } catch (e) {
    return null;
  }
};
