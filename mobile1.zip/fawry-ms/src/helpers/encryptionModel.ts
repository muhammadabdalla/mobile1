import { NextFunction } from 'express';
import { Schema } from 'mongoose';
import {
  encryptData,
  encryptAllDocumentSensitiveFields,
  decryptArrayOfDocuments
} from './encryptionUtils';

export const encryptionModel = (model: Schema, sensitiveFields: string[]) => {
  model.pre('save', function (next: NextFunction) {
    this.isEncrypted = true;
    encryptAllDocumentSensitiveFields(this, sensitiveFields);
    next();
  });

  model.pre('aggregate', function (next: NextFunction) {
    // @ts-ignore
    const pipeline = <any>this.pipeline();
    const matchStagesPipelineIndex: any = {};
    pipeline.forEach((stage: any, index: number) => {
      for (const matchFieldKey in stage['$match']) {
        pipeline[index]['$match'][matchFieldKey] = sensitiveFields.includes(matchFieldKey)
          ? encryptData(pipeline[index]['$match'][matchFieldKey])
          : pipeline[index]['$match'][matchFieldKey];
      }
    });
    for (const matchStageIndex in matchStagesPipelineIndex) {
      const subStageName = matchStagesPipelineIndex[matchStageIndex];
      pipeline[matchStageIndex]['$match'][subStageName] = pipeline[matchStageIndex]['$match'][
        subStageName
      ].map((field: any) => {
        return sensitiveFields.includes(Object.keys(field)[0])
          ? {
              [Object.keys(field)[0]]: destructComplexMatchStage(field[Object.keys(field)[0]])
            }
          : field;
      });
    }
    next();
  });

  model.pre(['updateOne', 'findOneAndUpdate'], async function (next: NextFunction) {
    const document = <any>this;
    const directUpdates = document._update;
    const updatesInSet = document._update.$set;
    const query = document.getQuery();
    encryptAllDocumentSensitiveFields(query, sensitiveFields);
    encryptAllDocumentSensitiveFields(directUpdates, sensitiveFields);
    encryptAllDocumentSensitiveFields(updatesInSet, sensitiveFields);

    next();
  });

  model.pre(['findOne', 'findOneAndDelete', 'find', 'count'], async function (next: NextFunction) {
    const query = this.getQuery();
    encryptAllDocumentSensitiveFields(query, sensitiveFields);
    next();
  });

  model.post(
    ['find', 'findOne', 'findOneAndDelete', 'updateOne', 'findOneAndUpdate'],
    function (data) {
      if (!data) return;
      decryptArrayOfDocuments(data, sensitiveFields);
      return data;
    }
  );

  model.post('aggregate', function (data) {
    const doc: any = data;
    decryptArrayOfDocuments(doc, sensitiveFields);
    return doc;
  });
};

const destructComplexMatchStage = function (matchStageValue: any) {
  if (typeof matchStageValue !== 'object') return encryptData(`${matchStageValue}`?.toLowerCase());

  const encryptedMatchStage = { ...matchStageValue };
  if (encryptedMatchStage.$regex) {
    encryptedMatchStage.$regex = encryptData(`${encryptedMatchStage.$regex}`?.toLowerCase());
  } else if (encryptedMatchStage.$eq) {
    encryptedMatchStage.$eq = encryptData(`${encryptedMatchStage.$eq}`);
  }
  return encryptedMatchStage;
};
