import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/fawry';
import { validate } from 'express-validation';
import authenticate from '../../helpers/authenticate';
import { ProtectedRequest } from 'app-request';
import schema from './schema';
import tracingHeaders from '../../helpers/tracingHeaders';
const router = express.Router();
router.get(
  '/billers/:category',
  authenticate(),
  validate(schema.paginationSchema),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getListOfBillers(
      {
        limit: Number(req.query.limit || 10),
        page: Number(req.query.page || 0),
        search: String(req.query.search || '')
      },
      String(req.params.category),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/categories',
  authenticate(),
  validate(schema.paginationSchema),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getListOfCategories(
      { limit: Number(req.query.limit || 15), page: Number(req.query.page || 0) },
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/bill',
  authenticate(),
  validate(schema.getBill),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getBill(
      req.body,
      req.user,
      req.headers.authorization || '',
      '',
      false,
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);
router.post(
  '/multipleBills',
  authenticate(),
  validate(schema.getMultipleBills),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getMultipleBills(
      req.body,
      req.user,
      req.headers.authorization || '',
      false,
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/favorite',
  authenticate(),
  validate(schema.addFavorite),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.addFavorite(
      req.body,
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      String(req.headers.platform),
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );

    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/favorite',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getUserFavorites(req.user.cif);

    new SuccessResponse('Success', result).send(res);
  })
);
router.get(
  '/onlineUserFavorite',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getOnlineUserFavorites(
      req.user.cif,
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );

    new SuccessResponse('Success', result).send(res);
  })
);

router.put(
  '/favorite/:id',
  authenticate(),
  validate(schema.updateFavorite),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.updateFavorite(
      req.body,
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      req.params.id,
      String(req.headers.platform),
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.delete(
  '/favorite/:id',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.deleteFavorite(
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      req.params.id,
      String(req.headers.platform),
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/payment',
  authenticate(),
  validate(schema.fawryPayment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.accountPayment(
      req.body,
      req.user.cif,
      req.user.id,
      String(req.query.paymentType || ''),
      String(req.headers.authorization || ''),
      '',
      false,
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/payment/schedule',
  authenticate(),
  validate(schema.payAndSchedule),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.payAndSchedule(
      req.body,
      req.user.cif,
      req.user.id,
      String(req.headers.authorization || ''),
      '',
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/multiplePayment',
  authenticate(),
  validate(schema.fawryMultiplePayment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.accountMultiplePayment(
      req.body,
      req.user.cif,
      req.user.id,
      String(req.query.paymentType || ''),
      String(req.headers.authorization || ''),
      String(req.headers.platform),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);
router.get(
  '/history',
  authenticate(),
  validate(schema.history),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getPaymentHistory(
      req.user.cif,
      Number(req.query.page || 1),
      Number(req.query.limit || 20),
      {
        search: String(req.query.search || ''),
        startDate: String(req.query.startDate || req.query.fromDate || ''),
        endDate: String(req.query.endDate || req.query.toDate || ''),
        lastTransaction: String(req.query.lastTransaction || '')
      }
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/biller',
  authenticate(),
  validate(schema.getBillerById),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getBillerById(
      {
        billerId: String(req.query.billerId || ''),
        billTypeCode: String(req.query.billTypeCode || '')
      },
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/fees',
  authenticate(),
  validate(schema.getBillFees),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getBillFee(
      req.body,
      String(req.headers.authorization || ''),
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/schedule',
  authenticate(),
  validate(schema.schedulePayment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.schedulePayment(req.body, {
      user: req.user.cif,
      userId: req.user.id,
      scheduleDate: req.body.scheduleDate,
      nextPaymentDate: req.body.scheduleDate,
      scheduleType: req.body.scheduleType,
      paymentType: req.body.paymentType,
      category: req.body.category,
      platform: req.headers.platform || ''
    });
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/scheduleOnlinePayment',
  authenticate(),
  validate(schema.schedulePayment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.scheduleOnlinePayment(req.body, {
      user: req.user.cif,
      userId: req.user.id,
      scheduleDate: req.body.scheduleDate,
      nextPaymentDate: req.body.scheduleDate,
      scheduleType: req.body.scheduleType,
      paymentType: req.body.paymentType,
      category: req.body.category,
      platform: req.headers.platform || ''
    });
    new SuccessResponse('Success', result).send(res);
  })
);

router.put(
  '/schedule/:id',
  authenticate(),
  validate(schema.editSchedulePayment),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.editSchedulePayment(req.params.id, req.body, {
      user: req.user.cif,
      userId: req.user.id,
      paymentType: req.body.paymentType,
      scheduleDate: req.body.scheduleDate,
      nextPaymentDate: req.body.scheduleDate,
      scheduleType: req.body.scheduleType,
      platform: req.headers.platform || ''
    });
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/schedule/list',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getSchedulePayments(req.user.cif);
    new SuccessResponse('Success', result).send(res);
  })
);

router.delete(
  '/schedule/:id',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.deleteSchedulePayments(
      req.user.cif,
      req.params.id,
      req.user.id,
      String(req.headers.platform)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

export default router;
