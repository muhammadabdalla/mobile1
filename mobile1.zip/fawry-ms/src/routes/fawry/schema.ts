import Joi from 'joi';
import moment from 'moment';
import { scheduleTypes } from '../../config';

const schedulePaymentSchema = Joi.object({
  paymentType: Joi.string().required().allow('account', 'creditCard'),
  BillTypeCode: Joi.string().required(),
  Amount: Joi.number().required(),
  DebitAcc: Joi.when('paymentType', {
    is: 'account',
    then: Joi.string().required()
  }),
  ContractId: Joi.when('paymentType', {
    is: 'creditCard',
    then: Joi.string().required()
  }),
  BillerName: Joi.string().optional(),
  ServiceName: Joi.string().optional(),
  PmtType: Joi.string().required(),
  BillingAcct: Joi.string().required(),
  BillerId: Joi.string().required(),
  scheduleDate: Joi.date().required().greater(new Date()),
  scheduleType: Joi.string().required(),
  otp: Joi.string().optional(),
  category: Joi.string().required()
});

const paymentSchemaObject = {
  BillTypeCode: Joi.string().required(),
  Amount: Joi.number().required(),
  DebitAcc: Joi.when('paymentType', {
    is: 'account',
    then: Joi.string().required()
  }),
  ContractId: Joi.when('paymentType', {
    is: 'creditCard',
    then: Joi.string().required()
  }),
  BillerName: Joi.string().optional(),
  ServiceName: Joi.string().optional(),
  PmtType: Joi.string().required(),
  BillingAcct: Joi.when('BillerId', {
    switch: [
      { is: '1', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
      { is: '2', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
      { is: '3', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
      { is: '4', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
      { is: '5', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
      { is: '7', then: Joi.string().regex(RegExp('^[0-9]*$')).required() }
    ],
    otherwise: Joi.string().required()
  }),
  BillRefNumber: Joi.string().optional(),
  BillerId: Joi.string().required(),
  otp: Joi.string().required()
};

export default {
  paginationSchema: {
    query: Joi.object({
      page: Joi.string().optional().min(0),
      limit: Joi.number().optional().min(0),
      search: Joi.string().optional().allow('')
    })
  },
  addFavorite: {
    body: Joi.object({
      BillerId: Joi.string().required(),
      category: Joi.string().required(),
      BillTypeCode: Joi.string().required(),
      BillTypeAcctLabel: Joi.string().required(),
      BillingAcct: Joi.string().required(),
      PmtType: Joi.string().required(),
      name: Joi.string().required()
    })
  },
  updateFavorite: {
    body: Joi.object({
      BillingAcct: Joi.string().optional(),
      name: Joi.string().required()
    })
  },
  getBill: {
    body: Joi.object({
      BillingAcct: Joi.string().required(),
      BillerId: Joi.string().required(),
      BillTypeCode: Joi.string().required(),
      PmtType: Joi.string().required()
    })
  },
  getMultipleBills: {
    body: Joi.object({
      bills: Joi.array()
        .items(
          Joi.object({
            BillingAcct: Joi.string().required(),
            BillerId: Joi.string().required(),
            BillTypeCode: Joi.string().required(),
            PmtType: Joi.string().required(),
            Name: Joi.string().required(),
            BillTypeName: Joi.string().required()
          })
        )
        .min(1)
    })
  },
  fawryPayment: {
    query: Joi.object({
      paymentType: Joi.string().required().allow('account', 'creditCard')
    }),
    body: Joi.object(paymentSchemaObject)
  },
  fawryMultiplePayment: {
    query: Joi.object({
      paymentType: Joi.string().required().allow('account', 'creditCard')
    }),
    body: Joi.object({
      payments: Joi.array()
        .items(
          Joi.object({
            BillTypeCode: Joi.string().required(),
            Amount: Joi.number().required(),
            DebitAcc: Joi.when('paymentType', {
              is: 'account',
              then: Joi.string().required()
            }),
            ContractId: Joi.when('paymentType', {
              is: 'creditCard',
              then: Joi.string().required()
            }),
            BillerName: Joi.string().optional(),
            ServiceName: Joi.string().optional(),
            PmtType: Joi.string().required(),
            BillingAcct: Joi.when('BillerId', {
              switch: [
                { is: '1', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
                { is: '2', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
                { is: '3', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
                { is: '4', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
                { is: '5', then: Joi.string().regex(RegExp('^[0-9]*$')).required() },
                { is: '7', then: Joi.string().regex(RegExp('^[0-9]*$')).required() }
              ],
              otherwise: Joi.string().required()
            }),
            BillRefNumber: Joi.string().optional(),
            BillerId: Joi.string().required(),
            Name: Joi.string().required()
          })
        )
        .min(1),
      otp: Joi.string().required()
    })
  },

  history: {
    query: Joi.object({
      page: Joi.number().optional().min(1),
      limit: Joi.number().optional().min(1),
      search: Joi.string().optional().allow(''),
      startDate: Joi.string().optional(),
      endDate: Joi.string().optional(),
      fromDate: Joi.string().optional(),
      toDate: Joi.string().optional(),
      lastTransaction: Joi.string().optional()
    })
  },
  getBillerById: {
    query: Joi.object({
      billerId: Joi.string().required(),
      billTypeCode: Joi.string().optional()
    })
  },
  getBillFees: {
    body: Joi.object({
      BillerId: Joi.string().required(),
      BillTypeCode: Joi.string().required(),
      BillingAcct: Joi.string().required(),
      PmtType: Joi.string().required(),
      Amt: Joi.string().required()
    })
  },
  schedulePayment: {
    body: schedulePaymentSchema
  },
  editSchedulePayment: {
    body: Joi.object({
      DebitAcc: Joi.when('paymentType', {
        is: 'account',
        then: Joi.string().required()
      }),
      ContractId: Joi.when('paymentType', {
        is: 'creditCard',
        then: Joi.string().required()
      }),
      paymentType: Joi.string().required().allow('account', 'creditCard'),
      Amount: Joi.number().min(1).required(),
      scheduleDate: Joi.date().required(),
      scheduleType: Joi.string()
        .valid(...Object.values(scheduleTypes))
        .required(),
      otp: Joi.string().required()
    })
  },
  payAndSchedule: {
    body: Joi.object({
      fawryPaymentInput: Joi.object({
        paymentDetails: Joi.object({ ...paymentSchemaObject }),
        paymentType: Joi.string().required().allow('account', 'creditCard')
      }),
      schedulePaymentInput: schedulePaymentSchema,
      otp: Joi.string().required()
    })
  }
};
