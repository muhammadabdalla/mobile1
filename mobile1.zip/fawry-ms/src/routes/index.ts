import express from 'express';
import fawry from './fawry/index';

const router = express.Router();

router.use('/fawry', fawry);

export default router;
