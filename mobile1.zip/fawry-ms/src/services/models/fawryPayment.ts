import mongoose from 'mongoose';
import { encryptionModel } from '../../helpers/encryptionModel';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionConfig } from '../../config';
const model = new mongoose.Schema(
  {
    countryCode: String,
    cif: String,
    debitAcc: String,
    contractId: String,
    currency: String,
    amount: String,
    transactionId: String,
    billerId: String,
    billerName: String,
    serviceName: String,
    billRefNumber: String,
    billTypeCode: String,
    pmtType: String,
    billingAcct: String,
    billTypeAcctLabel: String,
    isEncrypted: Boolean
  },
  { timestamps: true }
);
model.index({ cif: 1 });

if (encryptionConfig.ENCRYPTION === 'true') {
  encryptionModel(model, SensitiveFields);
}
export default mongoose.model('fawryPayment', model);
