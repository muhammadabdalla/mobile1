import mongoose from 'mongoose';
import { encryptionModel } from '../../helpers/encryptionModel';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionConfig } from '../../config';
const model = new mongoose.Schema(
  {
    body: {
      BillTypeCode: String,
      Amount: Number,
      DebitAcc: String,
      ContractId: String,
      BillerName: String,
      ServiceName: String,
      PmtType: String,
      BillingAcct: String,
      BillerId: String
    },
    paymentType: String,
    scheduleDate: Date,
    scheduleType: String,
    nextPaymentDate: Date,
    user: String,
    userId: String,
    category: String,
    platform: String,
    isEncrypted: Boolean
  },
  { timestamps: true }
);
model.index(
  { 'body.BillingAcct': 1, 'body.BillerId': 1, 'body.BillTypeCode': 1 },
  { unique: true }
);
model.index({ user: 1 });
model.index({ nextPaymentDate: 1 });

if (encryptionConfig.ENCRYPTION === 'true') {
  encryptionModel(model, SensitiveFields);
}

export default mongoose.model('SchedulePayment', model);
