import { getHeartbeatTime, produce } from '../../kafka';
import {
  InternalError,
  BlockedTokenError,
  InvalidOtpError,
  ScheduleError,
  ScheduleDuplicateError,
  ScheduleDuplicateInAnotherAccError,
  DebitError,
  EditScheduleError,
  TimeError,
  PaymentDayError,
  ForbiddenError
} from '../../core/ApiError';
import { logger } from '../../core/Logger';
import { Consumer } from 'kafkajs';
import Favorite from '../models/favorite';
import * as queryString from 'query-string';
import Payments from '../models/fawryPayment';
import SchedulePayments from '../models/schedule';
import moment from 'moment';
import messages from '../../messages';
import { Bill } from 'app-request';
import { randomUUID } from 'crypto';
import updateStatistics from '../../helpers/statistics';
import { CronJob } from 'cron';
let partitionId: any;
import {
  defaultCountry,
  defaultCurrency,
  kafkaTopics,
  statistics,
  status,
  transactionCodes,
  scheduleTypes
} from '../../config';
import adminTransferToken from '../../helpers/adminTransferToken';
import mongoose from 'mongoose';
import promiseAllsettled from 'promise.allsettled';
import correlation from 'express-correlation-id';
import * as lodash from 'lodash';
import { handlePagination } from '../../helpers/pagination';

export const getListOfBillers = async (
  params: { limit: number; page: number; search: string },
  category: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const query: any = {
      ServiceName: category,
      offset: params.page,
      limit: params.limit
    };
    if (params.search) query.BillerName = params.search;
    const route = queryString.stringifyUrl({ url: 'fawry/biller', query });
    const data = {
      route,
      authorization
    };
    const producerData = await produce(data, true, '', tracingHeaders);
    return prepareKafkaResponse(producerData);
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getListOfCategories = async (
  params: { limit: number; page: number },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `fawry/billerCategories?offset=${params.page}&limit=${params.limit}`,
      authorization
    };
    const producerData = await produce(data, true, '', tracingHeaders);
    return prepareKafkaResponse(producerData);
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const addFavorite = async (
  body: any,
  cif: string,
  user: string,
  phoneNumber: string,
  platform: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    body.cif = cif;
    const existFavourite: any = await Favorite.findOne({
      cif: cif,
      BillerId: body.BillerId,
      BillTypeCode: body.BillTypeCode,
      BillingAcct: body.BillingAcct
    });
    if (existFavourite) {
      throw new InternalError(messages.authorization.favouriteBill.en);
    } else {
      const favorite = new Favorite(body);
      await favorite.save();
      const biller = await getBillerById(
        { billerId: body.BillerId, billTypeCode: body.BillTypeCode },
        authorization,
        tracingHeaders
      );

      updateStatistics('', {
        cif: cif,
        user: user,
        phoneNumber: phoneNumber,
        BillingAcct: body.BillingAcct,
        type: 'favoritePayment',
        subType: 'addFavoritePayment',
        status: status.success,
        date: new Date(),
        microservice: 'fawry',
        action: 'add',
        favoriteName: body.name,
        category: body.category,
        fawryBiller: biller.BillerName || '',
        fawryService: biller.BillerInfo[0].Name || '',
        platform: platform
      });
      return { message: 'Success' };
    }
  } catch (e) {
    logger.debug(e.message);
    updateStatistics('', {
      cif: cif,
      user: user,
      phoneNumber: phoneNumber,
      BillingAcct: body.BillingAcct,
      type: 'favoritePayment',
      subType: 'addFavoritePayment',
      status: status.fail,
      reason: e.message,
      date: new Date(),
      microservice: 'fawry',
      action: 'add',
      favoriteName: body.name,
      category: body.category,
      platform: platform
    });
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const deleteFavorite = async (
  cif: string,
  user: string,
  phoneNumber: string,
  id: string,
  platform: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const favoritePayment: any = await Favorite.findOneAndDelete({ _id: id, cif });
    const biller = await getBillerById(
      { billerId: favoritePayment.BillerId, billTypeCode: favoritePayment.BillTypeCode },
      authorization,
      tracingHeaders
    );
    updateStatistics('', {
      cif: cif,
      user: user,
      phoneNumber: phoneNumber,
      BillingAcct: favoritePayment.BillingAcct,
      type: 'favoritePayment',
      subType: 'deleteFavoritePayment',
      status: status.success,
      date: new Date(),
      microservice: 'fawry',
      action: 'delete',
      favoriteName: favoritePayment.name,
      category: favoritePayment.category,
      fawryBiller: biller.BillerName || '',
      fawryService: biller.BillerInfo[0].Name || '',
      platform: platform
    });
    return { message: 'Success' };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const updateFavorite = async (
  body: any,
  cif: string,
  user: string,
  phoneNumber: string,
  id: string,
  platform: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const favouriteBill: any = await Favorite.findOne({ cif, _id: id });
    const existFavourite: any = await Favorite.findOne({
      cif: cif,
      BillerId: favouriteBill.BillerId,
      BillTypeCode: favouriteBill.BillTypeCode,
      BillingAcct: body.BillingAcct,
      _id: {
        $ne: new mongoose.Types.ObjectId(id)
      }
    });
    if (existFavourite) {
      throw new InternalError(messages.authorization.favouriteBill.en);
    }

    const favoritePayment: any = await Favorite.findOneAndUpdate({ _id: id, cif }, { $set: body });

    const biller = await getBillerById(
      {
        billerId: favoritePayment.BillerId,
        billTypeCode: favoritePayment.BillTypeCode
      },
      authorization,
      tracingHeaders
    );

    updateStatistics('', {
      cif: cif,
      user: user,
      phoneNumber: phoneNumber,
      BillingAcct: body.BillingAcct ? body.BillingAcct : favouriteBill.BillingAcct,
      type: 'favoritePayment',
      subType: 'updateFavoritePayment',
      status: status.success,
      date: new Date(),
      microservice: 'fawry',
      action: 'update',
      favoriteName: body.name,
      category: favoritePayment.category,
      fawryBiller: biller.BillerName || '',
      fawryService: biller.BillerInfo[0].Name || '',
      platform: platform
    });

    return { message: 'Success' };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getUserFavorites = async (cif: string) => {
  try {
    return Favorite.aggregate([
      { $match: { cif } },
      { $sort: { _id: -1 } },
      { $project: { __v: 0 } }
    ]);
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};
export const getOnlineUserFavorites = async (
  cif: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const favorites: any = await getUserFavorites(cif);

    for (let i = 0; i < favorites.length; i++) {
      const Biller = await getBillerById(
        { billerId: favorites[i].BillerId, billTypeCode: favorites[i].BillTypeCode },
        authorization,
        tracingHeaders
      );
      favorites[i].BillTypeName = Biller.BillerInfo[0].Name;
    }
    return favorites;
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getBill = async (
  body: Bill,
  user: any,
  authorization: string,
  correlationId = '',
  autoBillPayment = false,
  platform: string,
  tracingHeaders: any = {}
) => {
  const { cif, id } = user;
  try {
    const data = {
      route: `fawry/bill`,
      method: 'post',
      authorization,
      body
    };

    const producerData = await produce(data, true, correlationId, tracingHeaders);
    const dataResponce = await prepareKafkaResponse(producerData);
    await updateStatistics(statistics.successPayments, {
      type: 'bill',
      subType: 'billInquiry',
      cif,
      id,
      platform,
      ...body,
      dataResponse: { ...dataResponce },
      success: true,
      date: new Date()
    });
    return dataResponce;
  } catch (e) {
    await updateStatistics('', {
      type: 'bill',
      subType: 'billInquiry',
      cif,
      id,
      platform,
      ...body,
      success: false,
      date: new Date()
    });
    logger.debug(e.message);
    if (autoBillPayment) throw new InternalError(e.message);
    else throw new InternalError();
  }
};
export const getMultipleBills = async (
  body: {
    bills: [
      {
        BillingAcct: string;
        BillerId: string;
        BillTypeCode: string;
        PmtType: string;
        Name: string;
        BillTypeName: string;
      }
    ];
  },
  user: any,
  authorization: string,
  autoBillPayment = false,
  platform: string,
  tracingHeaders: any = {}
) => {
  try {
    const successResults = [];
    const failedResults = [];
    if (body.bills.length > 10) {
      throw new ForbiddenError();
    }
    for (const bill of body.bills) {
      try {
        const fawryBill: any = {
          BillingAcct: bill.BillingAcct,
          BillerId: bill.BillerId,
          BillTypeCode: bill.BillTypeCode,
          PmtType: bill.PmtType
        };

        const billData: any = await getBill(
          fawryBill,
          user,
          authorization,
          '',
          false,
          platform,
          tracingHeaders
        );

        if (billData[0]?.Status?.StatusCode !== 200 || !billData[0]?.BillInqRs) {
          throw new InternalError();
        }
        billData[0].BillInqRs.BillRec[0].PmtType = bill.PmtType;
        billData[0].BillInqRs.BillRec[0].Name = bill.Name;
        billData[0].BillInqRs.BillRec[0].BillTypeName = bill.BillTypeName;

        const currentBill: any = billData[0].BillInqRs;

        successResults.push(currentBill);
      } catch (e) {
        logger.error(e.message);
        failedResults.push({
          BillingAcct: bill.BillingAcct,
          BillerId: bill.BillerId,
          BillTypeCode: bill.BillTypeCode,
          Name: bill.Name,
          BillTypeName: bill.BillTypeName
        });
      }
    }
    return { success: successResults, failed: failedResults };
  } catch (e) {
    logger.debug(e.message);
    if (autoBillPayment) throw new InternalError(e.message);
    else throw new InternalError();
  }
};

export const accountPayment = async (
  body: any,
  cif: string,
  user: string,
  paymentType: string,
  authorization: string,
  correlationId = '',
  autoBillPayment = false,
  platform = '',
  tracingHeaders: any = {}
) => {
  let billerServiceName = body.ServiceName;

  if (!body.ServiceName) {
    try {
      const { Name } = (
        await getBillerById(
          { billerId: body.BillerId, billTypeCode: body.BillTypeCode },
          authorization,
          tracingHeaders
        )
      ).BillerInfo[0];

      billerServiceName = Name;
    } catch (e) {
      logger.debug(e.message);
    }
  }
  try {
    let route: string;
    const TransCode = platform === 'web' ? transactionCodes.fawryPayment.web : null;
    const paymentBody: any = {
      CountryCode: defaultCountry,
      Cif: cif,
      Currency: defaultCurrency,
      Amount: body.Amount,
      TransCode,
      PmtInfo: {
        BillerId: body.BillerId,
        BillRefNumber: body.BillRefNumber,
        BillTypeCode: body.BillTypeCode,
        PmtType: body.PmtType,
        BillingAcct: body.BillingAcct
      }
    };
    if (paymentType === 'account') {
      paymentBody.DebitAcc = body.DebitAcc;
      route = 'txn/pay/fawry/by/account';
    } else {
      paymentBody.ContractId = body.ContractId;
      route = 'txn/pay/fawry/by/creditcard';
    }
    const data = {
      route,
      method: 'post',
      topic: kafkaTopics.t24Request,
      authorization,
      body: paymentBody
    };

    const producerData = await produce(data, true, correlationId, tracingHeaders);
    const kafkaData = await prepareKafkaResponse(producerData, true);
    updateStatistics(
      statistics.successPayments,
      {
        cif,
        user,
        type: 'transfer',
        subType: 'fawryPayment',
        date: new Date(),
        microservice: 'fawry',
        source: paymentType === 'account' ? 'account' : 'card',
        debit: paymentType === 'account' ? body.DebitAcc : body.ContractId,
        beneficiary: body.BillingAcct,
        amount: `EGP ${body.Amount}`,
        transactionId: kafkaData.TransactionId,
        beneficiaryBank: `FAWRY ${billerServiceName} ${body.PmtType}`,
        status: status.success,
        platform: platform
      },
      correlationId
    );
    if (!autoBillPayment) updateCustomerTransfers(cif, authorization, tracingHeaders);
    return { transactionId: kafkaData.TransactionId };
  } catch (e) {
    logger.debug(e.message);
    updateStatistics(
      statistics.failedPayments,
      {
        cif,
        user,
        type: 'transfer',
        subType: 'fawryPayment',
        date: new Date(),
        microservice: 'fawry',
        source: paymentType === 'account' ? 'account' : 'card',
        debit: paymentType === 'account' ? body.DebitAcc : body.ContractId,
        beneficiary: body.BillingAcct,
        amount: `EGP ${body.Amount}`,
        beneficiaryBank: `FAWRY ${billerServiceName} ${body.PmtType}`,
        status: e.message === messages.cards.timeout.en ? status.timeout : status.fail,
        platform: platform
      },
      correlationId
    );
    if (autoBillPayment) throw new InternalError(e.message);
    throw new InternalError();
  }
};

export const accountMultiplePayment = async (
  body: {
    payments: [
      {
        BillTypeCode: string;
        Amount: number;
        DebitAcc: string;
        ContractId: string;
        BillerName: string;
        ServiceName: string;
        PmtType: string;
        BillingAcct: string;
        BillRefNumber: string;
        BillerId: string;
        Name: string;
      }
    ];
  },
  cif: string,
  user: string,
  paymentType: string,
  authorization: string,
  platform: string,
  tracingHeaders: any
) => {
  try {
    const successResults: any = [];
    const failedResults: any = [];
    if (body.payments.length > 10) {
      throw new ForbiddenError();
    }
    const promises = body.payments.map((payment) => {
      return new Promise(async (resolve, reject) => {
        try {
          const result: any = await accountPayment(
            payment,
            cif,
            user,
            paymentType,
            authorization,
            `${correlation.getId()}-${lodash.random(999999999)}`,
            false,
            platform,
            tracingHeaders
          );
          resolve({
            transactionId: result?.transactionId,
            BillerId: payment.BillerId,
            Amount: payment.Amount,
            Name: payment.Name
          });
        } catch (error) {
          logger.error(error.message);
          reject({
            BillerId: payment.BillerId,
            Amount: payment.Amount,
            Name: payment.Name
          });
        }
      });
    });
    const res = await promiseAllsettled(promises);
    res.forEach((result) => {
      if (result.status === 'fulfilled') successResults.push(result.value);
      else failedResults.push(result.reason);
    });
    return { success: successResults, failed: failedResults };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const payAndSchedule = async (
  data: any,
  cif: string,
  user: string,
  authorization: string,
  correlationId = '',
  platform = '',
  tracingHeaders: any = {}
) => {
  const { fawryPaymentInput: paymentData } = data;
  const { schedulePaymentInput: scheduleData } = data;

  const payment = await accountPayment(
    paymentData.paymentDetails,
    cif,
    user,
    String(paymentData.paymentType || ''),
    authorization,
    correlationId,
    false,
    platform,
    tracingHeaders
  );

  try {
    const schedulePaymentResponce = await scheduleOnlinePayment(scheduleData, {
      user: cif,
      userId: user,
      scheduleDate: scheduleData.scheduleDate,
      nextPaymentDate: scheduleData.scheduleDate,
      scheduleType: scheduleData.scheduleType,
      paymentType: scheduleData.paymentType,
      category: scheduleData.category,
      platform: platform
    });
    return { ...payment, ...schedulePaymentResponce };
  } catch (error) {
    const scheduledError = true;
    logger.error(error.message);
    return { ...payment, scheduledError };
  }
};

export const prepareKafkaResponse = async (message: any, returnErrorMessage = false) => {
  if (!message.value) throw new InternalError(messages.cards.missingValue.en);
  const data = JSON.parse(message.value.toString());
  if (!data.error) {
    return data.message.Data || data.message.data || data.message;
  } else {
    logger.debug(data.message);
    if (returnErrorMessage) throw new InternalError(data.message);
    if (data.message === messages.authorization.otpBlocked.en) throw new BlockedTokenError();
    if (data.message === messages.cards.notActive.en) throw new InternalError('cardNotActive');
    if (data.message === messages.authorization.invalidOtp.en) throw new InvalidOtpError();
    else throw new InternalError(messages.cards.internalError.en);
  }
};

export const getPaymentHistory = async (
  cif: string,
  page: number,
  limit: number,
  settings: { search: string; startDate: string; endDate: string; lastTransaction: string },
  pagination = true
) => {
  try {
    const user: any = { cif };
    const totalDocs = await Payments.find(user).count();

    let fromDateTyped;
    let toDateTyped;

    if (settings.startDate) {
      fromDateTyped = formatDate(settings.startDate);
      user['createdAt'] = { $gte: fromDateTyped, $lte: new Date() };
      if (settings.endDate) {
        toDateTyped = formatDate(settings.endDate);
        user['createdAt'] = { $gte: fromDateTyped, $lte: toDateTyped };
      }
    }

    let result = await Payments.find(user, { _v: 0, cif: 0 });

    if (settings.search) result = handlePaymentSearch(result, settings.search);
    result = lodash.orderBy(result, ['createdAt'], ['desc']);

    if (!pagination) return result;

    return {
      docs: handlePagination(result, limit || 20, settings.lastTransaction || '', 'transactionId'),
      page,
      totalDocs,
      hasNextPage: totalDocs / limit > page,
      hasPrevPage: !(page === 1),
      limit,
      totalPages: Math.ceil(totalDocs / limit),
      pagingCounter: page
    };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const getBillerById = async (
  params: { billerId: string; billTypeCode: string },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const correlationId = correlation.getId();

    const data = {
      route: `fawry/billerById?BillerId=${params.billerId}&BillTypeCode=${params.billTypeCode}`,
      authorization
    };

    const producerData = await produce(data, true, '', tracingHeaders);
    const kafkaData = await prepareKafkaResponse(producerData);
    console.log(
      ` ${correlationId} functionName: getBillerById // ENCRYPTION_CHECK `,
      kafkaData[0]?.docs[0]
    );
    return kafkaData[0]?.docs[0] || {};
  } catch (e) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const getBillFee = async (
  body: {
    BillerId: string;
    BillTypeCode: string;
    PmtType: string;
    Amt: string;
    BillingAcct: string;
  },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `fawry/fees`,
      method: 'post',
      body: {
        BillerId: body.BillerId,
        BillTypeCode: body.BillTypeCode,
        PmtType: body.PmtType,
        BillingAcct: body.BillingAcct,
        CurAmt: {
          Amt: body.Amt,
          CurCode: defaultCurrency
        }
      },
      authorization
    };
    const producerData = await produce(data, true, '', tracingHeaders);
    const kafkaData = await prepareKafkaResponse(producerData);
    return kafkaData[0] || {};
  } catch (e) {
    logger.error(e.message);
    throw new InternalError();
  }
};

const checkDebitAccount = (debitAcc: string, cif: string) => {
  if (debitAcc.slice(0, 8) !== cif) {
    throw new DebitError();
  }
};

export const schedulePayment = async (paymentBody: any, scheduleBody: any) => {
  try {
    if (paymentBody.paymentType == 'account') {
      checkDebitAccount(paymentBody.DebitAcc, scheduleBody.user);
    }

    const oldSchedule = await SchedulePayments.findOne({
      'body.BillingAcct': paymentBody.BillingAcct,
      'body.BillerId': paymentBody.BillerId,
      'body.BillTypeCode': paymentBody.BillTypeCode,
      user: scheduleBody.user
    });

    if (oldSchedule) throw new ScheduleDuplicateError();

    const checkAnotherAccount = await SchedulePayments.findOne({
      'body.BillingAcct': paymentBody.BillingAcct,
      'body.BillerId': paymentBody.BillerId,
      'body.BillTypeCode': paymentBody.BillTypeCode
    });

    if (checkAnotherAccount) throw new ScheduleDuplicateInAnotherAccError();

    await new SchedulePayments({ body: paymentBody, ...scheduleBody }).save();

    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: true,
      action: 'add',
      billingAcct: paymentBody.BillingAcct,
      paymentCategory: scheduleBody.category,
      fawryBiller: paymentBody.BillerName,
      fawryService: paymentBody.ServiceName,
      paymentAmount: paymentBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'addSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform: scheduleBody.platform
    });

    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: false,
      action: 'add',
      billingAcct: paymentBody.BillingAcct,
      paymentCategory: scheduleBody.category,
      fawryBiller: paymentBody.BillerName,
      fawryService: paymentBody.ServiceName,
      paymentAmount: paymentBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'addSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform: scheduleBody.platform
    });
    if (e instanceof ScheduleDuplicateError || e.type === 'SchedulePaymentDuplicated') {
      throw new ScheduleDuplicateError();
    }

    if (
      e instanceof ScheduleDuplicateInAnotherAccError ||
      e.type === 'ScheduleDuplicateInAnotherAccError'
    ) {
      throw new ScheduleDuplicateInAnotherAccError();
    }
    if (e.message === messages.authorization.schedulePayment.en) throw new ScheduleError();
    else if (e.message === messages.authorization.debitAccount.en) throw new DebitError();
    else throw new InternalError();
  }
};

export const scheduleOnlinePayment = async (paymentBody: any, scheduleBody: any) => {
  let duplicated = false;
  let scheduledError = false;
  let scheduleAmount = null;
  let scheduleDate = null;
  let scheduleErrorReason = '';
  try {
    if (paymentBody.paymentType == 'account') {
      checkDebitAccount(paymentBody.DebitAcc, scheduleBody.user);
    }

    const oldSchedule = await SchedulePayments.findOne({
      'body.BillingAcct': paymentBody.BillingAcct,
      'body.BillerId': paymentBody.BillerId,
      'body.BillTypeCode': paymentBody.BillTypeCode,
      user: scheduleBody.user
    });

    if (oldSchedule) {
      duplicated = true;
      scheduledError = true;
      scheduleAmount = oldSchedule.body?.Amount;
      scheduleDate = oldSchedule.scheduleDate;
      scheduleErrorReason = 'existsInThisAccount';
      throw new ScheduleDuplicateError();
    }

    const checkAnotherAccount = await SchedulePayments.findOne({
      'body.BillingAcct': paymentBody.BillingAcct,
      'body.BillerId': paymentBody.BillerId,
      'body.BillTypeCode': paymentBody.BillTypeCode
    });

    if (checkAnotherAccount) {
      duplicated = true;
      scheduledError = true;
      scheduleErrorReason = 'existsInAnotherAccount';
      throw new ScheduleDuplicateInAnotherAccError();
    }

    await new SchedulePayments({ body: paymentBody, ...scheduleBody }).save();

    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: true,
      action: 'add',
      billingAcct: paymentBody.BillingAcct,
      paymentCategory: scheduleBody.category,
      fawryBiller: paymentBody.BillerName,
      fawryService: paymentBody.ServiceName,
      paymentAmount: paymentBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'addSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform: scheduleBody.platform
    });

    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: false,
      action: 'add',
      billingAcct: paymentBody.BillingAcct,
      paymentCategory: scheduleBody.category,
      fawryBiller: paymentBody.BillerName,
      fawryService: paymentBody.ServiceName,
      paymentAmount: paymentBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'addSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform: scheduleBody.platform
    });
    if (e instanceof ScheduleDuplicateError || e.type === 'SchedulePaymentDuplicated') {
      logger.debug(e.type);
      return { duplicated, scheduledError, scheduleAmount, scheduleDate, scheduleErrorReason };
    }

    if (
      e instanceof ScheduleDuplicateInAnotherAccError ||
      e.type === 'ScheduleDuplicateInAnotherAccError'
    ) {
      logger.debug(e.type);
      return { duplicated, scheduledError, scheduleErrorReason };
    }
    if (e.message === messages.authorization.schedulePayment.en) throw new ScheduleError();
    else if (e.message === messages.authorization.debitAccount.en) throw new DebitError();
    else throw new InternalError();
  }
};

const conditionalDate = (type: string, date?: any, month?: any, day?: any): any => {
  switch (type) {
    case 'timestamp': {
      if (date) {
        return new Date(date).getTime();
      }
      return moment().set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).toDate().getTime();
    }
    case 'moment': {
      if (month && day) {
        return moment()
          .set({ hour: 0, minute: 0, second: 0, millisecond: 0 })
          .add(month, 'months')
          .set({ date: day });
      }
      if (date) {
        return moment(date);
      }
      if (day) {
        return moment().set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).set({ date: day });
      }
      return moment().set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    }
    case 'date': {
      if (date) {
        return moment(date).date();
      }
      return moment().date();
    }
    default:
      break;
  }
};

const isPaymentDate = (oldScheduleBody: any): boolean => {
  const { nextPaymentDate: nextPaymentDateFormat } = oldScheduleBody;
  const dateNow = conditionalDate('timestamp');
  const nextPaymentDate = conditionalDate('timestamp', nextPaymentDateFormat);
  if (nextPaymentDate === dateNow) {
    return true;
  }
  return false;
};

const validateTime = (oldScheduleBody: any, newScheduleBody: any): boolean => {
  const { scheduleDate: oldScheduleDateFormat, scheduleType: oldScheduleType } = oldScheduleBody;
  const { scheduleDate: newScheduleDateFormat, scheduleType: newScheduleType } = newScheduleBody;
  const oldScheduleDate = conditionalDate('timestamp', oldScheduleDateFormat);
  const newScheduleDate = conditionalDate('timestamp', newScheduleDateFormat);
  const dateNow = conditionalDate('timestamp');
  if (
    newScheduleDate !== oldScheduleDate &&
    (newScheduleDate < dateNow || newScheduleDate === dateNow)
  ) {
    throw new TimeError();
  }
  const isChanged = isPaymentDate(oldScheduleBody);
  if (isChanged) throw new PaymentDayError();
  if (
    oldScheduleDate === newScheduleDate &&
    oldScheduleType !== newScheduleType &&
    oldScheduleDate < dateNow
  ) {
    return true;
  }
  return false;
};

const checkingValidateValue = (oldScheduleBody: any, newScheduleBody: any): any => {
  const { scheduleDate: oldScheduleDateFormat, scheduleType: oldScheduleType } = oldScheduleBody;
  let nextPaymentDate = null;
  const oldDay = conditionalDate('date', oldScheduleDateFormat);
  if (oldScheduleType === scheduleTypes.monthly) {
    nextPaymentDate = conditionalDate('moment', null, 3, oldDay);
  } else if (oldScheduleType === scheduleTypes.quarterly) {
    const myDay = conditionalDate('date');
    if (oldDay < myDay) {
      nextPaymentDate = conditionalDate('moment', null, 1, oldDay);
    } else {
      nextPaymentDate = conditionalDate('moment', null, null, oldDay);
    }
  }
  return {
    ...newScheduleBody,
    nextPaymentDate
  };
};

const handlePaymentSearch = (result: any, search: string) => {
  const searchRegex = new RegExp(`\\b${search}`, 'i');
  return lodash.filter(result, (item) => {
    const serviceName = searchRegex.test(item.serviceName);
    const billerName = searchRegex.test(item.billerName);

    const searchByAmount = searchRegex.test(item.amount);
    const searchByname = serviceName ? serviceName : billerName;

    return searchByAmount || searchByname;
  });
};

const formatDate = (date: string) => {
  const newDate = new Date(
    parseInt(date.slice(0, 4)),
    parseInt(date.slice(4, 6)) - 1,
    parseInt(date.slice(6))
  );
  return newDate;
};

const createNewScheduleBody = (status: boolean, options: any): any => {
  const { oldScheduleBody, newScheduleBody } = options;
  let myBody = {
    ...newScheduleBody
  };
  if (status) {
    myBody = checkingValidateValue(oldScheduleBody, newScheduleBody);
  }
  return myBody;
};

export const editSchedulePayment = async (id: string, paymentBody: any, scheduleBody: any) => {
  try {
    if (paymentBody.paymentType == 'account') {
      checkDebitAccount(paymentBody.DebitAcc, scheduleBody.user);
    }
    const oldScheduleBody: any | null = await SchedulePayments.findOne({
      _id: new mongoose.Types.ObjectId(id),
      user: scheduleBody.user
    });
    if (!oldScheduleBody) throw new EditScheduleError();
    const { DebitAcc, Amount, ContractId } = paymentBody;
    const status = validateTime(oldScheduleBody, scheduleBody);
    const newBody = createNewScheduleBody(status, {
      oldScheduleBody,
      newScheduleBody: scheduleBody
    });
    const updatedFields = [];

    if (oldScheduleBody.body.DebitAcc !== paymentBody.DebitAcc) updatedFields.push('Debit Account');
    if (oldScheduleBody.body.ContractId !== paymentBody.ContractId)
      updatedFields.push('Credit Card');
    if (oldScheduleBody.body.Amount !== paymentBody.Amount) updatedFields.push('Amount');
    if (oldScheduleBody.scheduleType !== paymentBody.scheduleType) updatedFields.push('Frequency');
    if (
      new Date(oldScheduleBody.scheduleDate).getTime() !==
      new Date(paymentBody.scheduleDate).getTime()
    )
      updatedFields.push('Payment start date');
    await SchedulePayments.updateOne(
      { _id: new mongoose.Types.ObjectId(id) },
      {
        $set: {
          'body.DebitAcc': DebitAcc ? DebitAcc : '',
          'body.ContractId': ContractId ? ContractId : '',
          'body.Amount': Amount,
          ...newBody
        }
      }
    );
    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: true,
      action: 'edit',
      billingAcct: oldScheduleBody.body.BillingAcct,
      paymentCategory: oldScheduleBody.category,
      fawryBiller: oldScheduleBody.body.BillerName,
      fawryService: oldScheduleBody.body.ServiceName,
      paymentAmount: paymentBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'editSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      updatedFields,
      platform: scheduleBody.platform
    });
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    updateStatistics('', {
      date: new Date(),
      user: scheduleBody.userId,
      cif: scheduleBody.user,
      success: false,
      action: 'edit',
      paymentAmount: scheduleBody.Amount,
      paymentFrequency: scheduleBody.scheduleType,
      paymentStartDate: scheduleBody.scheduleDate,
      type: 'editSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform: scheduleBody.platform
    });
    if (e.message === messages.authorization.editSchedulePayment.en) {
      throw new EditScheduleError();
    } else if (e.message === messages.authorization.timeSchedulePayment.en) {
      throw new TimeError();
    } else if (e.message === messages.authorization.timePaymentDay.en) {
      throw new PaymentDayError();
    } else {
      throw new InternalError();
    }
  }
};

export const getSchedulePayments = async (cif: string) => {
  try {
    return SchedulePayments.find({ user: cif }).sort({ updatedAt: -1 });
  } catch (e) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const runSchedulePayment = async () => {
  try {
    await getPartitionId();
    const job = new CronJob(
      '0 0 1,12 * * *',
      async () => {
        if (partitionId === 0) {
          logger.info('Job Started in run Schedule Payment');
          const startDate = new Date(moment().startOf('day').utc().format());
          const endDate = new Date(moment().endOf('day').utc().format());
          const query = {
            nextPaymentDate: { $gte: startDate, $lte: endDate }
          };
          const count = await SchedulePayments.countDocuments(query);
          let recordCount = 0;
          const scheduleData = await SchedulePayments.find(query).cursor();
          scheduleData.on('data', async (data) => {
            scheduleData.pause();
            if (!data.platform) data.platform = 'mobile';
            const paymentData = {
              topic: kafkaTopics.schedulePayment,
              data
            };
            const correlationId = randomUUID();
            await produce(paymentData, false, correlationId, {});
            recordCount++;
            if (recordCount === count) scheduleData.close();
            scheduleData.resume();
          });
          scheduleData.on('close', () => logger.info('Streaming data is closed'));
        }
      },
      null,
      true,
      'Africa/Cairo'
    );
    job.start();
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError();
  }
};

export const executeSchedulePayment = async (message: any, correlationId: string) => {
  logger.debug('functionName: executeSchedulePayment ,started');
  if (!message.value) throw new InternalError();
  const kafkaData = JSON.parse(message.value.toString());
  try {
    const authorization = await adminTransferToken();
    if (kafkaData.data.body.PmtType.toLowerCase() === 'post') {
      const bill = await getBill(
        {
          BillingAcct: kafkaData.data.body.BillingAcct,
          BillerId: kafkaData.data.body.BillerId,
          BillTypeCode: kafkaData.data.body.BillTypeCode,
          PmtType: kafkaData.data.body.PmtType
        },
        {},
        `Bearer ${authorization}`,
        correlationId,
        true,
        'generic',
        {}
      );
      if (!Object.keys(bill[0]?.BillInqRs).length)
        throw new InternalError(messages.authorization.billError.en);

      const paymentAmount = bill[0]?.BillInqRs?.BillRec[0]?.BillInfo?.BillSummAmt[0]?.CurAmt?.Amt;
      const paymentFees = bill[0]?.BillInqRs?.BillRec[0]?.BillInfo?.BillSummAmt[1]?.CurAmt?.Amt;
      if (!paymentAmount) {
        logger.error(
          `Error in auto bill payment: Amount is not provided for user ${kafkaData.data.user}`,
          { correlationId }
        );
        throw new InternalError();
      }
      if (paymentAmount + paymentFees > kafkaData.data.body.Amount) {
        const biller = await getBillerById(
          {
            billerId: kafkaData.data.body.BillerId,
            billTypeCode: kafkaData.data.body.BillTypeCode
          },
          `Bearer ${authorization}`,
          {}
        );
        if (
          !biller.BillerInfo[0].PaymentRules.IsFracAcpt &&
          !biller.BillerInfo[0].PaymentRules.IsPrtAcpt
        ) {
          logger.error(
            `Error in auto bill payment: Partial payment is not allowed for this biller ${biller.BillerInfo[0].Name} for user ${kafkaData.data.user}`,
            { correlationId }
          );
          throw new InternalError();
        }
      } else {
        kafkaData.data.body.Amount = paymentAmount;
      }
      kafkaData.data.body.BillRefNumber = bill[0]?.BillInqRs?.BillRec[0]?.BillRefNumber || '';
    }
    await accountPayment(
      kafkaData.data.body,
      kafkaData.data.user,
      kafkaData.data.userId,
      kafkaData.data.paymentType,
      `Bearer ${authorization}`,
      correlationId,
      true,
      kafkaData.data.platform,
      {}
    );
    logger.info(`Auto bill payment success for user ${kafkaData.data.user}`, { correlationId });
  } catch (e) {
    updateStatistics(
      '',
      {
        type: 'autoBillPayment',
        error: e.message,
        cif: kafkaData.data.user,
        microservice: 'fawry',
        user: kafkaData.data.userId,
        date: new Date(),
        platform: kafkaData.data.platform
      },
      correlationId
    );
    logger.error(`Error in auto bill payment for user ${kafkaData.data.user}`, { correlationId });
    logger.error(e.message, { correlationId });
  }
  const duration = kafkaData.data.scheduleType === 'monthly' ? 1 : 3;
  const nextPaymentDate = moment().add(duration, 'months').format();
  const newScheduleDate = kafkaData.data.nextPaymentDate;
  return SchedulePayments.updateOne(
    { _id: kafkaData.data._id },
    { $set: { scheduleDate: newScheduleDate, nextPaymentDate } }
  );
};

export const getPartitionId = async () => {
  try {
    const options: { consumer: Consumer; interval: number } = await getHeartbeatTime();
    const consumerAssignments: { [key: string]: number } = {};
    options.consumer.on(options.consumer.events.GROUP_JOIN, (data: any) => {
      if (Object.keys(data.payload.memberAssignment)?.length) {
        Object.keys(data.payload.memberAssignment).forEach((memberId) => {
          consumerAssignments[memberId] = Math.min(...data.payload.memberAssignment[memberId]);
          partitionId = consumerAssignments[kafkaTopics.fawryResponse];
        });
      } else partitionId = null;
    });
  } catch (e) {
    partitionId = null;
  }
};

export const deleteSchedulePayments = async (
  cif: string,
  id: string,
  user: string,
  platform: string
) => {
  try {
    const schedulePayment: any = await SchedulePayments.findOne({ _id: id, user: cif });

    if (schedulePayment) {
      await SchedulePayments.deleteOne({ _id: id, user: cif });
      updateStatistics('', {
        date: new Date(),
        user: user,
        cif: cif,
        success: true,
        action: 'delete',
        billingAcct: schedulePayment.body.BillingAcct,
        paymentCategory: schedulePayment.category,
        fawryBiller: schedulePayment.body.BillerName,
        fawryService: schedulePayment.body.ServiceName,
        paymentAmount: schedulePayment.body.Amount,
        paymentFrequency: schedulePayment.scheduleType,
        paymentStartDate: schedulePayment.scheduleDate,
        type: 'deleteSchedulePayment',
        subType: 'schedulePayment',
        microservice: 'fawry',
        platform
      });
      return { message: 'Success' };
    } else throw new InternalError();
  } catch (e) {
    updateStatistics('', {
      date: new Date(),
      user: user,
      cif: cif,
      success: false,
      action: 'delete',
      type: 'deleteSchedulePayment',
      subType: 'schedulePayment',
      microservice: 'fawry',
      platform
    });
    logger.error(e.message);
    throw new InternalError();
  }
};

export const updateCustomerTransfers = async (
  cif: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      topic: kafkaTopics.customerResponse,
      function: 'updateCustomerTransfers',
      consumerType: 'customerSettings',
      body: {
        cif
      },
      authorization: `Bearer ${authorization}`
    };
    await produce(data, false, '', tracingHeaders);
  } catch (error) {
    logger.error(error.message);
  }
};
