// Mapper for environment variables

export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;
export const enableCron = process.env.ENABLE_CRON === 'true';
export const corsUrl = process.env.CORS_URL;

export const kafkaOptions = {
  clientId: process.env.KAFKA_CLIENT_ID || '',
  hosts: process.env.KAFKA_HOSTS?.split(',') || [],
  connectionTimeout: parseInt(process.env.KAFKA_CONNECTION_TIMEOUT || '3000'),
  requestTimeout: parseInt(process.env.KAFKA_REQUEST_TIMEOUT || '25000'),
  initialRetryTime: parseInt(process.env.KAFKA_INITIAL_RETRY_TIME || '1'),
  retries: parseInt(process.env.KAFKA_RETRIES || '1'),
  producerPolicy: {
    allowAutoTopicCreation: true
  },
  consumerPolicy: {
    groupId: process.env.CONSUMER_GROUP_ID || 'fawry-ms',
    maxWaitTimeInMs: Number(process.env.CONSUMER_MAX_WAIT_TIME || '100'),
    scheduleGroupId: process.env.SCHEDULE_CONSUMER_GROUP_ID || 'schedule-fawry-ms',
    allowAutoTopicCreation: true,
    sessionTimeout: Number(process.env.CONSUMER_SESSION_TIMEOUT || '30000'),
    heartbeatInterval: Number(process.env.CONSUMER_HEART_BEAT || '3000'),
    retry: {
      retries: parseInt(process.env.KAFKA_RETRIES || '1')
    }
  },
  numberOfPartitions: Number(process.env.KAFKA_PARTITION_NUMBER || '3')
};

export const transactionCodes = {
  ownAccountTransfer: {
    web: 'ACOI'
  },
  internalTransfer: {
    web: 'ACBI'
  },
  externalTransfer: {
    web: 'OTLI'
  },
  fawryPayment: {
    web: 'ACIF'
  },
  cardPayment: {
    web: 'ACCI'
  }
};

export const kafkaTopics = {
  fawryRequest: 'fawryRequest',
  fawryResponse: 'fawryResponse',
  t24Request: 't24Request',
  validateTopic: 'validateTopic',
  statistics: 'statistics',
  kibana: 'kibanastatistics',
  schedulePayment: 'schedulePayment',
  customerResponse: 'customerResponse'
};

export const promiseTimeout = parseInt(process.env.PROMISE_TIMEOUT || '20000');

export const defaultCurrency = 'EGP';

export const defaultCountry = 'EG';

export const mongoConfig = {
  url: process.env.DB_URL || ''
};

export const statistics = {
  successPayments: 'successPayments',
  failedPayments: 'failedPayments'
};

export const status = {
  success: 'success',
  fail: 'fail',
  timeout: 'timeout'
};

export const adminCredentials = {
  username: process.env.ADMIN_USER,
  password: process.env.ADMIN_PASSWORD
};

export const adminTransfersCredentials = {
  username: process.env.ADMIN_TRANSFER_USER,
  password: process.env.ADMIN_TRANSFER_PASSWORD
};

export const t24Url = process.env.T24_BASE_URL;

export const scheduleTypes = {
  monthly: 'monthly',
  quarterly: 'quarterly'
};

export const encryptionConfig = {
  DB_ENCRYPTION_KEY: process.env.DB_ENCRYPTION_KEY,
  algorithm: 'aes-256-gcm',
  separationSymbol: '::)',
  DB_ENCRYPTION_IV: process.env.DB_ENCRYPTION_IV,
  ENCRYPTION: process.env.ENCRYPTION
};
