export default {
  cards: {
    timeout: {
      en: 'Request Timeout'
    },
    missingValue: {
      en: 'Missing Value'
    },
    internalError: {
      en: 'Internal Server Error'
    },
    notActive: {
      en: 'Card not active'
    }
  },
  authorization: {
    notFound: {
      en: 'Authorization must be provided'
    },
    invalid: {
      en: 'Invalid token'
    },
    otpBlocked: {
      en: 'Your token is locked'
    },
    invalidOtp: {
      en: 'Invalid OTP'
    },
    schedulePayment: {
      en: 'Schedule payment already exists'
    },
    debitAccount: {
      en: 'Invalid debit account'
    },
    editSchedulePayment: {
      en: 'Schedule payment does not exists'
    },
    timeSchedulePayment: {
      en: 'Schedule date should be greater than today'
    },
    timePaymentDay: {
      en: "You can't edit schedule payment in the payment date"
    },
    billError: {
      en: 'Error while getting billRefNumber'
    },
    favouriteBill: {
      en: 'Favourite Bill already exists'
    }
  }
};
