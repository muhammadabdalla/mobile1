import * as kafka from '../../src/kafka';
export const produceResult = {
  billers: {
    value:
      '{"error": false, "message": { "Data": [{"docs": [{"_id": "6175f380171202aa7fbe6555", "BillerId": "7", "BillerName": "WE Internet", "BillerInfo": [{}] }]}] }}'
  },
  category: {
    value:
      '{"error": false, "message": { "Data": [{"docs": ["charity", "Traveling"], "totalDocs": "1" }] }}'
  },
  bill: {
    value:
      '{"error": false, "message": { "Data": [{ "RqUID": "af7ae454-7c52-4150-9bf5-b527912df183", "AsyncRqUID": "e549a662-40d2-4d99-9a31-b52b2418f0db", "BillInqRs": { "BillRec": [{ "BillInfo": { "BillSummAmt": [{ "BillSummAmtCode": "Fees", "CurAmt": { "Amt": 5.5 } }] } }] } }] }}'
  },
  payment: {
    value: '{"error": false, "message": {  "TransactionId": "testId" }}'
  },
  biller: {
    value: '{"error": false, "message": { "Data": [{ "docs": [{ "BillerId": "1" }] }] }}'
  },
  fee: {
    value: '{"error": false, "message": { "Data": [{ "Amt": 5 }] }}'
  }
};
export const billersResult = [
  {
    docs: [
      {
        _id: '6175f380171202aa7fbe6555',
        BillerId: '7',
        BillerName: 'WE Internet',
        BillerInfo: [{}]
      }
    ]
  }
];

export const billerById = {
  BillerId: '1'
};

export const categoriesResult = [
  {
    docs: ['charity', 'Traveling'],
    totalDocs: '1'
  }
];

export const billResult = [
  {
    RqUID: 'af7ae454-7c52-4150-9bf5-b527912df183',
    AsyncRqUID: 'e549a662-40d2-4d99-9a31-b52b2418f0db',
    BillInqRs: {
      BillRec: [{ BillInfo: { BillSummAmt: [{ BillSummAmtCode: 'Fees', CurAmt: { Amt: 5.5 } }] } }]
    }
  }
];

export const paymentResult = {
  transactionId: 'testId'
};

export const mockKafkaSuccess = () => {
  jest.spyOn(kafka, 'createConsumer');
  const mock = jest.spyOn(kafka, 'produce');
  mock.mockImplementation(async (data) => {
    switch (data.route) {
      case 'fawry/biller?ServiceName=sports&offset=1&limit=1':
        return Promise.resolve(produceResult.billers);
      case 'fawry/billerCategories?offset=1&limit=1':
        return Promise.resolve(produceResult.category);
      case 'fawry/bill':
        return Promise.resolve(produceResult.bill);
      case 'txn/pay/fawry/by/account':
        return Promise.resolve(produceResult.payment);
      case 'txn/pay/fawry/by/creditcard':
        return Promise.resolve(produceResult.payment);
      case 'fawry/billerById?BillerId=1&BillTypeCode=111':
        return Promise.resolve(produceResult.biller);
      case 'fawry/fees':
        return Promise.resolve(produceResult.fee);
      default:
        return Promise.resolve(produceResult.billers);
    }
  });
};
