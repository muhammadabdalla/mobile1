import Model from '../../src/services/models/favorite';
import SchedulePayments from '../../src/services/models/schedule';
import Fawry from '../../src/services/models/fawryPayment';

export const favoriteData = [
  {
    _id: '617bbd71081f1d681de4319c',
    billerId: '36',
    billTypeCode: '326',
    BillTypeAcctLabel: 'Mobile Number',
    BillingAcct: '+961 70743281',
    PmtType: 'PREP',
    name: 'Charles kassouf',
    cif: '10012626',
    createdAt: {
      $date: '2021-10-29T09:22:57.211Z'
    },
    updatedAt: {
      $date: '2021-10-29T09:22:57.211Z'
    }
  }
];

export const body = [
  {
    _id: '617bbd71081f1d681de4319c',
    billerId: '36',
    billTypeCode: '326',
    BillTypeAcctLabel: 'Mobile Number',
    BillingAcct: '+961 70743281',
    PmtType: 'PREP',
    name: 'Charles kassouf',
    cif: '10012626',
    createdAt: {
      $date: '2021-10-29T09:22:57.211Z'
    },
    updatedAt: {
      $date: '2021-10-29T09:22:57.211Z'
    }
  }
];

export const mockMongoSuccess = () => {
  Model.aggregate = jest.fn().mockResolvedValue(body);
  Model.remove = jest.fn().mockResolvedValue({});
  Model.updateOne = jest.fn().mockResolvedValue({});
  Model.findOneAndUpdate = jest.fn().mockResolvedValue({});
  Model.findOneAndDelete = jest.fn().mockResolvedValue({});
  Model.prototype.save = jest.fn().mockResolvedValue({});
  Fawry.prototype.save = jest.fn().mockResolvedValue({});
  SchedulePayments.findOne = jest.fn().mockResolvedValue(null);
  SchedulePayments.prototype.save = jest.fn().mockResolvedValue({});
};
