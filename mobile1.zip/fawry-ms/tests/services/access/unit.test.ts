import * as service from '../../../src/services/fawry';
import {
  mockKafkaSuccess,
  billersResult,
  categoriesResult,
  billResult,
  paymentResult,
  billerById
} from '../../mocks/kafka';
import { favoriteData, mockMongoSuccess } from '../../mocks/mongo';
import { Bill } from '../../../src/types/app-request';

describe('Get list of Billers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    const params = {
      page: 1,
      limit: 1,
      search: ''
    };
    const category = 'sports';
    const response = await service.getListOfBillers(params, category, '', null);
    expect(response).toStrictEqual(billersResult);
  });
});

describe('Get list of Categories', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    const params = {
      page: 1,
      limit: 1
    };
    const response = await service.getListOfCategories(params, '', null);
    expect(response).toStrictEqual(categoriesResult);
  });
});

describe('Get bills', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    const body: Bill = {
      BillingAcct: 'string',
      BillerId: 'string',
      BillTypeCode: 'string',
      PmtType: 'string'
    };
    const response = await service.getBill(body, {}, '', '', false, '', {});
    expect(response).toStrictEqual(billResult);
  });
});

describe('Favorites', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Get favorites', async () => {
    mockMongoSuccess();
    const response = await service.getUserFavorites('10100111');
    expect(response).toStrictEqual(favoriteData);
  });
  it('delete favorites', async () => {
    mockKafkaSuccess();
    const response = await service.deleteFavorite(
      '10100111',
      'user',
      '1283121213',
      '',
      'web',
      '',
      {}
    );
    expect(response).toStrictEqual({ message: 'Success' });
  });
});

describe('Fawry Payment', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    mockMongoSuccess();
    const response = await service.accountPayment(
      {},
      '10100111',
      '',
      'account',
      '',
      '',
      false,
      'web',
      null
    );
    expect(response).toStrictEqual(paymentResult);
  });
});

describe('Get biller by id', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.getBillerById({ billerId: '1', billTypeCode: '111' }, '', null);
    expect(response).toStrictEqual(billerById);
  });
});

describe('Get fees', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess();
    const response = await service.getBillFee(
      { BillerId: '1', BillTypeCode: '111', Amt: '5', PmtType: 'POST', BillingAcct: '123123' },
      '',
      null
    );
    expect(response).toStrictEqual({ Amt: 5 });
  });
});

describe('Add schedule Payment', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockMongoSuccess();
    const response = await service.schedulePayment(
      { DebitAcc: '100007328786' },
      { user: '10000732', scheduleDate: '2025-01-01' }
    );
    expect(response).toStrictEqual({ message: 'Success' });
  });
});
