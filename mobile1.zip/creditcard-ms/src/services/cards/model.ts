import mongoose from 'mongoose';
import { encryptionModel } from '../../helpers/encryptionModel';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionConfig } from '../../config';
const model = new mongoose.Schema(
  {
    cif: {
      type: String
    },
    isCreditCard: {
      type: Boolean
    },
    cardNumber: String,
    isEncrypted: Boolean
  },
  { timestamps: true, versionKey: false }
);
model.index({ cif: 1, cardNumber: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('cardReplacement', model);
