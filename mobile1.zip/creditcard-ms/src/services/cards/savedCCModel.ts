import mongoose from 'mongoose';
import { encryptionModel } from '../../helpers/encryptionModel';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionConfig } from '../../config';
const model = new mongoose.Schema(
  {
    cif: String,
    name: String,
    nickName: String,
    cardNumber: String,
    isEncrypted: Boolean
  },
  { timestamps: true }
);
model.index({ cif: 1, cardNumber: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('savedCreditCard', model);
