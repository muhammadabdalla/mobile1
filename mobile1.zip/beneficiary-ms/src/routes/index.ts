import express from 'express';
import beneficiaries from './beneficiary/beneficiary';

const router = express.Router();

router.use('/beneficiary', beneficiaries);

export default router;
