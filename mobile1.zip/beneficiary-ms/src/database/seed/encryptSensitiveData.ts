import mongoose from 'mongoose';
import { logger } from '../../core/Logger';
import { mongoConfig } from '../../config';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptAllDocumentSensitiveFields } from '../../helpers/encryptionUtils';
import { ExcludedCollectionsEncryption } from '../../helpers/enums/excludedCollectionsEncryption';
const database = mongoConfig.url;

async function getListOfCollections() {
  try {
    await mongoose.connect(database);
    const collections = await mongoose.connection.db.listCollections().toArray();
    await mongoose.connection.close();
    logger.info(`Function getListOfCollection: Collections retrieved successfully`);

    return collections
      .filter(function (collection: any) {
        return !ExcludedCollectionsEncryption.includes(collection.name);
      })
      .map(function (collection: any) {
        return collection.name;
      });
  } catch (error) {
    logger.info(error);
    throw new Error(error.message);
  }
}
let startTime: any;
let endTime: any;

let counterRef = 0;
function incRef() {
  counterRef += 1;
}

function decRef() {
  counterRef -= 1;
  if (counterRef == 0) {
    mongoose.connection.close();
    endTime = new Date().getTime();
    const executionTime = endTime - startTime;
    console.log(`Execution time (ms): ${executionTime}`);
  }
}

const failedDocumentEncryptedIds = {} as any;
const failedStreamDocumentsIds = {} as any;
const failedUpdatedIds = {} as any;
let countUPDATEDDocsFAIL = 0;
let countENCRYPTEDDocsFAIL = 0;
let countMONGOSTREAMDocsFAIL = 0;

function loggingSummary() {
  logger.info(' SUMMARY : ');
  logger.info(
    `Function: exBulkEncryptFields: Count of error of Encryption: ${countENCRYPTEDDocsFAIL}`
  );

  console.log(
    `info : Function: exBulkEncryptFields: Encryption Total Ids errors: ${JSON.stringify(
      failedDocumentEncryptedIds
    )}`
  );

  logger.info(
    `Function: exBulkDecryptFields: Total number of errors in update doc: ${countUPDATEDDocsFAIL}`
  );
  logger.info(
    `Function: exBulkDecryptFields: Ids with errors in update doc: ${JSON.stringify(
      failedUpdatedIds
    )}`
  );

  logger.info(
    `Function: exBulkEncryptFields: Total number of errors in Mongo Stream: ${countMONGOSTREAMDocsFAIL}`
  );
  console.log(
    `info Function: exBulkEncryptFields: Stream error documents: ${JSON.stringify(
      failedStreamDocumentsIds
    )} `
  );
}

async function exBulkEncryptFields(collections: any) {
  startTime = new Date().getTime();
  try {
    const dbConnection = await mongoose.connect(database);

    for (const index in collections) {
      const collection = dbConnection.connection.collection(collections[index]);
      const collectionStream = collection
        .find({ $or: [{ isEncrypted: false }, { isEncrypted: { $exists: false } }] })
        .stream();

      incRef();
      collectionStream
        .on('data', async (document: any) => {
          try {
            if (!document['isEncrypted']) {
              encryptAllDocumentSensitiveFields(document, SensitiveFields);

              incRef();
              collection
                .updateOne({ _id: document._id }, { $set: { ...document } })
                .then(() => {
                  decRef();
                  if (!counterRef) {
                    loggingSummary();
                  }
                })
                .catch((e) => {
                  logger.error(
                    `Function: Script: update document / error: ${e} / document._id  ${document._id}`
                  );

                  countUPDATEDDocsFAIL += 1;
                  if (!failedUpdatedIds[collections[index]])
                    failedUpdatedIds[collections[index]] = [document._id];
                  else failedUpdatedIds[collections[index]].push(document._id);

                  decRef();
                  if (!counterRef) {
                    loggingSummary();
                  }
                });
              console.log(
                `${collection.collectionName} : ${document._id} : Encrypted successfully`
              );
            }
          } catch (error) {
            countENCRYPTEDDocsFAIL += 1;
            if (!failedDocumentEncryptedIds[collections[index]])
              failedDocumentEncryptedIds[collections[index]] = [document._id];
            else failedDocumentEncryptedIds[collections[index]].push(document._id);
            logger.error(
              `error bec of failure either to Encrypt or update document / error: ${error.message} : ${collection.collectionName} : ${document._id}`
            );
          }
        })
        .on('error', (error: Error, document: any) => {
          countMONGOSTREAMDocsFAIL += 1;
          logger.error(`${error.message} : ${document}`);
          if (!failedStreamDocumentsIds[collections[index]])
            failedStreamDocumentsIds[collections[index]] = [document._id];
          else failedStreamDocumentsIds[collections[index]].push(document._id);
        })
        .on('end', () => {
          decRef();
          if (!counterRef) {
            loggingSummary();
          }
        });
    }
  } catch (error) {
    logger.info(`Function exBulkEncryptFields: ${error.message}`);
  }
}

async function main() {
  const collections = await getListOfCollections();
  await exBulkEncryptFields(collections);
}
main().catch((error) => console.error(error));
