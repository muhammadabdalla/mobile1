import { encryptData, decryptData } from './encryptionUtils';

export const encryptionDecryptionUtil = (doc: any, encryption: boolean): any => {
  return encryption ? encryptAllDocument(doc) : decryptAllDocument(doc);
};

export const decryptAllDocument = (document: any) => {
  Object.keys(document).forEach((key: string) => {
    if (typeof document[key] === 'object') decryptAllDocument(document[key]);
    else document[key] = decryptData(document[key]);
  });
  return document;
};

export const encryptAllDocument = (document: any) => {
  Object.keys(document).forEach((key: string) => {
    if (typeof document[key] === 'object') encryptAllDocument(document[key]);
    else document[key] = encryptData(document[key]);
  });
  return document;
};
