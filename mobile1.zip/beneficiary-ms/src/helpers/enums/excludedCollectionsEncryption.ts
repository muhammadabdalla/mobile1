export const ExcludedCollectionsEncryption = [
  'atmsandbranches',
  'instantpays',
  'statistics',
  'relations'
];
