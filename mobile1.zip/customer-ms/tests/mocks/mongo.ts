import Model from '../../src/services/settings/model';
import { dailyTransferLimit } from '../../src/config';

export const customerData = {
  firstLogin: true,
  showSoftTokenApp: true,
  showMobileAdd: true,
  dailyTransferLimit: dailyTransferLimit,
  deliveryMechanism: 'Electronic',
  deliveryMechanismFirstTime: true
};

export const mockMongoSuccess = () => {
  Model.findOne = jest.fn().mockResolvedValue(null);
  Model.updateOne = jest.fn().mockResolvedValue({});
  Model.prototype.save = jest.fn().mockResolvedValue({});
};
