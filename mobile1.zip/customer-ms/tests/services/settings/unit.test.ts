import * as service from '../../../src/services/settings';
import { mockMongoSuccess } from '../../mocks/mongo';
beforeAll(() => {
  mockMongoSuccess();
});

describe('Get Customer settings', () => {
  it('Should return success', async () => {
    const data = await service.updateUserSettings('10100111', { showSoftTokenApp: true });
    expect(data).toStrictEqual({ message: 'Success' });
  });
});
