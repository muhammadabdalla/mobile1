import { Response, NextFunction } from 'express';
import { ProtectedRequest } from 'app-request';
import { kafkaTopics } from '../config';
import { AuthFailureError } from '../core/ApiError';
import messages from '../messages';
import { produce, prepareKafkaResponse } from '../kafka';
import tracingHeaders from './tracingHeaders';
import * as config from '../config';

export default () => async (req: ProtectedRequest, res: Response, next: NextFunction) => {
  try {
    const data = {
      topic: kafkaTopics.validateTopic,
      authorization: req.headers.authorization
    };
    const producerData = await produce(data, tracingHeaders(req));
    const result = await prepareKafkaResponse(producerData);
    if (result && result.user && result.user.id === config.adminCredentials.username) {
      next();
    } else next(new AuthFailureError(messages.authorization.invalid.en));
  } catch (error) {
    next(new AuthFailureError(messages.authorization.invalid.en));
  }
};
