export const staticPages: any = {
  login: {
    en: [
      {
        question: 'Can I self-register to the Mobile App or do I have to go to AAIB Branch?',
        answer:
          '<p>Yes, you can self-register to the Mobile App, without any need to go to the branch. However, to avoid any service interruption, you must visit any of our branches within 6 months of registration to sign the Terms & Conditions.</p>'
      },
      {
        question:
          'If I am already a user of AAIB Online Banking, do I need to register for the Mobile App?',
        answer: '<p>No, you can login with the Online Banking credentials to the Mobile App.</p>'
      },
      {
        question: 'How can I self-register on the Mobile App?',
        answer:
          '<div>' +
          'To register as a user, you will go through two main steps; entering your personal information and setting up your login credentials.' +
          '</div>' +
          '<br>' +
          '<div>' +
          '  Please follow the below steps to register on AAIB Mobile App:<br>' +
          '  <ul>' +
          '  <li><span>Click on “Register New User” at the login screen</span></li>' +
          '  <li><span>Select whether you want to register with your Debit Card number or Customer Information File (CIF), which is your reference number in the bank</span></li>' +
          '  <li><span>Enter your Debit Card number/CIF and your National ID</span></li>' +
          '  <li><span>Enter the One Time Password (OTP) sent to your registered mobile number to confirm<span></li>' +
          '  <li><span>Create your new login credentials (please make sure to follow the password criteria stated to ease your registration process)</span></li>' +
          '</ul>' +
          '</div>'
      },
      {
        question: "How can I benefit from AAIB's Mobile App?",
        answer:
          '<ul>' +
          '  <li><span>Transfer to local third-party beneficiaries and between your own accounts<span></li>' +
          '  <li><span>Pay your bills and daily expenses<span></li>' +
          '  <li><span>Settle your Credit Card payments from your own accounts<span></li>' +
          '  <li><span>Enable/disable your Credit Cards abroad and online payments, POS purchases, and ATM withdrawals<span></li>' +
          '  <li><span>Enable/disable your Debit Cards abroad and online payments<span></li>' +
          '  <li><span>Activate/block your Debit or Credit Cards<span></li>' +
          '  <li><span>Manage your accounts & keep track of your daily transactions<span></li>' +
          '  <li><span>Keep track of your current loans and their due payments<span></li>' +
          '  <li><span>Oversee all your investment products and their details<span></li>' +
          '</ul>'
      },
      {
        question: 'Is it secure to perform a transaction through the Mobile App?',
        answer:
          '<p>Yes, our financial transactions are secure and authenticated through “AAIB Token” Application, which generates One Time Passwords necessary to complete/ confirm transactions. Without it, you won’t be able to perform transfers and bill payments.</p>'
      }
    ],
    ar: [
      {
        question:
          'هل يمكنني التسجيل بنفسي في تطبيق البنك العربي الافريقي الدولي أم يجب على الذهاب إلى أحد الفروع؟',
        answer:
          '<p>نعم، يمكنك التسجيل بنفسك في تطبيق البنك العربي الافريقي الدولي دون الحاجة للذهاب إلى الفرع. لكن لتجنب أي انقطاع في الخدمة، يجب عليك زيارة أي فرع من فروعنا في خلال 6 أشهر من التسجيل للتوقيع على الشروط والأحكام</p>'
      },
      {
        question:
          'إذا كنت من مستخدمي خدمة الإنترنت البنكي من البنك العربي الافريقي الدولي، فهل أحتاج إلى التسجيل في تطبيق الهاتف المحمول؟',
        answer:
          '<p>لا، يمكنك تسجيل الدخول باستخدام بيانات دخول خدمة الإنترنت البنكي على تطبيق الهاتف المحمول</p>'
      },
      {
        question: 'كيف يمكنني التسجيل على تطبيق الهاتف المحمول؟',
        answer:
          '<div>' +
          'للتسجيل كمستخدم ستمر بخطوتين رئيسيتين؛ إدخال معلوماتك الشخصية وإنشاء بيانات الدخول الخاصة بك' +
          '</div>' +
          '<br>' +
          '<div>' +
          'برجاء اتباع الخطوات التالية للتسجيل في تطبيق البنك العربي الافريقي الدولي:<br>' +
          '  <ul>' +
          '  <li><span>اضغط على "تسجيل مستخدم جديد" في شاشة تسجيل الدخول</span></li>' +
          '  <li><span>اختر إذا كنت تريد التسجيل برقم بطاقة الخصم أو ملف معلومات العميل (CIF)، وهو رقمك المرجعي في بالبنك</span></li>' +
          '  <li><span>أدخل رقم بطاقة الخصم الفوري / CIF والرقم القومي</span></li>' +
          '  <li><span>للتأكيد أدخل الرمز السري المتغير (OTP) المرسلة على رقم الموبايل المسجل<span></li>' +
          '  <li><span>قم بإنشاء بيانات الدخول الخاصة بك (يرجى التأكد من اتباع معايير كلمة المرور المذكورة لتسهيل عملية التسجيل)</span></li>' +
          '</ul>' +
          '</div>'
      },
      {
        question: 'كيف يمكنني الاستفادة من تطبيق البنك العربي الافريقي الدولي؟',
        answer:
          '<ul>' +
          '  <li><span>إجراء تحويلات إلى مستفيدين محليين تابعين لجهات خارجية وبين حساباتك الخاصة<span></li>' +
          '  <li><span>دفع الفواتير ومصاريفك اليومية<span></li>' +
          '  <li><span>تسديد بطاقتك الائتمانية من حساباتك<span></li>' +
          '  <li><span>تفعيل/إلغاء بطاقات الائتمان الخاصة بك في الخارج، والدفع الإلكتروني، وعمليات الشراء عبر نقاط البيع، والسحب من خلال أجهزة الصراف الآلي<span></li>' +
          '  <li><span>تفعيل/إلغاء بطاقات الخصم الخاصة بك في الخارج والدفع الإلكتروني<span></li>' +
          '  <li><span>تفعيل / إيقاف بطاقات الخصم الفوري أو الائتمان الخاصة بك<span></li>' +
          '  <li><span>إدارة حساباتك ومتابعة معاملاتك اليومية<span></li>' +
          '  <li><span>متابعة قروضك الحالية والمستحقات<span></li>' +
          '  <li><span>إظهار جميع منتجاتك الاستثمارية وتفاصيلها<span></li>' +
          '</ul>'
      },
      {
        question: 'هل إجراء المعاملات من خلال تطبيق البنك العربي الافريقي الدولي آمن؟',
        answer:
          '<p>نعم، معاملاتنا المالية آمنة من خلال تطبيق AAIB لرموز الأمان، الذي ينشئ الرمز السري المتغير لإكمال أو تأكيد المعاملات وبدونها لن تتمكن من إجراء التحويلات ودفع الفواتير</p>'
      }
    ]
  },
  profile: {
    en: [
      {
        question: 'Is it secure to perform a transaction through the Mobile App?',
        answer:
          '<p>Yes, our financial transactions are secure and authenticated through &ldquo;AAIB Token&rdquo; Application, which generates One Time Passwords necessary to complete/ confirm transactions. Without it, you won&rsquo;t be able to perform transfers and bill payments.</p>'
      },
      {
        question: 'How can I download & activate the “AAIB Token” App?',
        answer:
          '<p>Please follow the below steps to <strong>download</strong> &ldquo;AAIB Token&rdquo;:</p><ul><li><span>Click on the Token Settings option in the profile screen</span></li><li><span>Click on Download button to be directed to the App Store/Play Store, where you can install &ldquo;AAIB Token&rdquo; on your device<br /><em>* Note: You can directly download the &ldquo;AAIB Token&rdquo; App from App Store/Play Store without accessing AAIB Mobile App.</em></span></li></ul><p>&nbsp;</p><p>Please follow the below steps to <strong>activate</strong> &ldquo;AAIB Token&rdquo; after download:</p><ul><li><span>Open the &ldquo;AAIB Token&rdquo; App </span></li><li><span>Enter the activation code received by SMS on your registered mobile number, then enter your AAIB mobile banking username</span></li><li><span>Create your &ldquo;AAIB Token&rdquo; PIN</span></li></ul>'
      },
      {
        question: 'How can I enable/disable biometric authentication?',
        answer:
          '<p>Please follow the below steps to <strong>enable</strong> biometric authentication:</p><ul><li><span>After your first login, a Biometric Login pop-up will appear</span></li><li><span>Click on the Enable button<br /><em>* Note: You can alternatively enable it from the Biometric Login option in your profile screen</em></span></li><li><span>Read and accept biometrics terms &amp; conditions</span></li><li><span>Enter the activation code received via SMS on your registered mobile number</span></li></ul><p>&nbsp;</p><p>Please follow the below steps to <strong>disable</strong> biometric authentication:</p><ul><li><span>Go to your profile screen</span></li><li><span>Disable biometric login by tapping the toggle</span></li></ul>'
      },
      {
        question: 'What can I do if I lost my card, or it got stolen? How can I block my card?',
        answer:
          '<p>You can block your Debit / Credit Card through the Mobile App by following the below steps:<br></p><ul><li><span>If you want to block your <strong>Debit Card</strong>, go to your Accounts screen, select the account of which you want to block its card, and click on view my cards</span></li><li><span>If you want to block your <strong>Credit Card</strong>, go to your Credit Cards screen</span></li><li><span>Click on the Block Card button</span></li><li><span>Select the time period for blocking your card (Temporary/Permanent)</span></li></ul><p><em><br />For example:</em><br><em>If you cannot find your card, you can easily block your card <strong>temporarily</strong> to make sure no one will be able to use it. You can then reactivate the card with one click once you find it.</em></p><br /><p><em>If you are sure that you will not find the card again and want to replace it with a new one, you can easily block your card <strong>permanently</strong>.<br /></em></p><ul><li><span>Confirm the block action to successfully block your card</span></li></ul>'
      },
      {
        question: 'How can I activate my card?',
        answer:
          '<p>You can activate your Debit/Credit Card through the Mobile App by following the below steps:<br/></p><ul><li><span>If you want to activate your <strong>Debit Card</strong>, go to your Accounts screen, select the Account of which you want to activate its card, and click on View my cards</span></li><li><span>If you want to activate your <strong>Credit Card</strong>, go to your Credit Cards screen</span></li><li><span>Click on the Activate Card button</span></li></ul><br/><p><em>For example:</em><br /><em>If you issued a new card, you can activate it with one click, without any need to go to the branch or contact the Call Center. Once activated through the application, you can start using it normally.</em></p><br/><p><em>If you have temporarily blocked your card before and want to start using it again, you can easily reactivate it without any need to go to the branch or contact the Call Center.</em></p><br/><ul><li><span>Enter your card expiry date</span></li><li><span>Enter the activation code received by SMS on your registered mobile number</span></li></ul>'
      },
      {
        question: 'How can I transfer to a third-party beneficiary?',
        answer:
          '<p>If beneficiary doesn&rsquo;t exist:</p><ul><li><span>Go to the Transfers screen</span></li><li><span>Select transfer to &ldquo;Beneficiary&rdquo;</span></li><li><span>Click on Add new beneficiary button</span></li><li><span>Enter beneficiary details<br /><em>* Note: EGP currency will be pre-selected for you since only local transfers are allowed for the time being</em></span></li><li><span>Select to save beneficiary and proceed with transfer, or save beneficiary only.</span></li><li><span>Enter amount you want to transfer and the reason</span></li><li><span>Select account to transfer from</span></li><li><span>Review and confirm the &ldquo;Transfer Overview&rdquo; screen</span></li><li><span>Select &ldquo;generate OTP&rdquo;<br /><em>* Note: if you don&rsquo;t have the &ldquo;AAIB Token&rdquo; App downloaded on your device, you will be directed to download and activate it before generating OTP</em></span></li><li><span>Token App will open automatically, enter the Token App PIN to generate an OTP for the transfer</span></li><li><span>Enter the generated OTP on AAIB Mobile App to be able to confirm/complete the transaction<br /><em>* Note: the validity of the token code is 60 seconds</em></span></li></ul><p>&nbsp;</p><p>If beneficiary exists:</p><ul><li><span>Go to the Transfers screen</span></li><li><span>Select transfer to &ldquo;Beneficiary&rdquo;</span></li><li><span>Select beneficiary to whom the transfer will occur</span></li><li><span>Enter amount you want to transfer and the reason</span></li><li><span>Select account to transfer from</span></li><li><span>Review and confirm the &ldquo;Transfer Overview&rdquo; screen</span></li><li><span>Select &ldquo;generate OTP&rdquo;<br /><em>* Note: if you don&rsquo;t have the &ldquo;AAIB Token&rdquo; App downloaded on your device, you will be directed to download and activate it before generating OTP</em></span></li><li><span>Token App will open automatically, enter the Token App PIN to generate an OTP for the transfer</span></li><li><span>Enter the generated OTP on AAIB Mobile App to be able to confirm/complete the transaction<br /><em>* Note: the validity of the token code is 60 seconds</em></span></li></ul>'
      },
      {
        question: 'How can I transfer between my own accounts?',
        answer:
          '<p>You can transfer between your own accounts by following the below steps:</p><ul><li><span>Go to the Transfers screen</span></li><li><span>Select transfer to &ldquo;Own account&rdquo; to view all available accounts you can transfer to</span></li><li><span>Select desired account &amp; enter the amount to send</span></li><li><span>Select the account you want to transfer from</span></li><li><span>Review and confirm the &ldquo;Transfer Overview&rdquo; screen</span></li></ul>'
      },
      {
        question: 'How can I pay my bills?',
        answer:
          '<p>You can pay your bills through the Mobile App by following the below steps:</p><ul><li><span>Go to the Payments screen</span></li><li><span>Select the category related to the bill payment</span></li><li><span>Select the biller your payment will be transferred to</span></li><li><span>Enter the mobile number / National ID related to the bill payment, then choose the amount</span></li><li><span>You can optionally add the configured bill payment as a favorite<br /><em>* Note: if you didn&rsquo;t add it as a favorite, you can re-pay the bill any other time by selecting it from the &ldquo;Recents&rdquo; tab</em></span></li><li><span>Enter OTP generated from &ldquo;AAIB Token&rdquo; App to proceed with bill payment</span></li><li><span>Confirm payment</span></li></ul>'
      },
      {
        question: 'How can I settle my Credit Card?',
        answer:
          '<p>You can settle your Credit Card from the Credit Cards or Transfers screen.</p><p>&nbsp;</p><p>In the Credit Cards screen:</p><ul><li><span>Select Credit Card you want to settle</span></li><li><span>Click on the Pay to card button</span></li><li><span>Select the payment amount</span></li><li><span>Select the account you want to pay from</span></li><li><span>Review and confirm the &ldquo;Transfer Overview&rdquo; screen</span></li></ul><p>&nbsp;</p><p>In the Transfers screen:</p><ul><li><span>Select transfer to &ldquo;Credit Card&rdquo;</span></li><li><span>Select desired Credit Card &amp; enter the amount to send</span></li><li><span>Select the account you want to transfer from</span></li><li><span>Review and confirm the &ldquo;Transfer Overview&rdquo; screen</span></li></ul>'
      }
    ],
    ar: [
      {
        question: 'هل إجراء المعاملات من خلال تطبيق البنك العربي الافريقي الدولي آمن؟',
        answer:
          '<p>نعم، معاملاتنا المالية آمنة من خلال تطبيق AAIB لرموز الأمان، الذي ينشئ الرمز السري المتغير لإكمال أو تأكيد المعاملات وبدونها لن تتمكن من إجراء التحويلات ودفع الفواتير.</p>'
      },
      {
        question: 'كيف يمكنني تحميل وتفعيل تطبيق AAIB لرموز الأمان؟',
        answer:
          '<p>يرجى اتباع الخطوات التالية <strong>لتحميل</strong> تطبيق "AAIB لرموز الأمان":</p><ul><li><span>اضغط على إعدادات رموز الأمان في شاشة الملف الشخصي</span></li><li><span>اضغط على "تحميل" ليتم توجيهك إلى App Store / Play Store، حيث يمكنك تحميل تطبيق AAIB لرموز الأمان على جهازك<br /><em>* ملاحظة: يمكنك تحميل تطبيق AAIB لرموز الأمان مباشرةً من App Store / Play Store دون استخدام تطبيق البنك العربي الافريقي الدولي.</em></span></li></ul><p>&nbsp;</p><p>برجاء إتباع الخطوات التالية <strong>لتفعيل</strong> تطبيق "AAIB لرموز الأمان" بعد التحميل:</p><ul><li><span>افتح تطبيق AAIB لرموز الأمان</span></li><li><span>أدخل كود التفعيل المرسل برسالة نصية قصيرة على رقم هاتفك المحمول المسجل، ثم أدخل اسم المستخدم الخاص بتطبيق البنك العربي الافريقي الدولي</span></li><li><span>قم بإنشاء رمز السري على تطبيق AAIB لرموز الأمان</span></li></ul>'
      },
      {
        question: 'كيف يمكنني تفعيل / إلغاء الدخول الذكي؟',
        answer:
          '<p>يرجى اتباع الخطوات التالية <strong>لتفعيل</strong> الدخول الذكي:</p><ul><li><span>بعد تسجيل الدخول لأول مرة، ستظهر نافذة لتسجيل الدخول الذكي</span></li><li><span>اضغط على تفعيل<br /><em>* ملاحظة: يمكنك أيضا تفعيل الدخول الذكي من شاشة الملف الشخصي</em></span></li><li><span>اقرأ الشروط والأحكام ووافق عليها</span></li><li><span>أدخل كود التفعيل المرسل برسالة نصية قصيرة على رقم هاتفك المحمول المسجل</span></li></ul><p>&nbsp;</p><p>يرجى اتباع الخطوات التالية <strong>لإلغاء</strong> الدخول الذكي:</p><ul><li><span>اتجه إلى شاشة الملف الشخصي الخاص بك</span></li><li><span>اضغط على زر التبديل لإلغاء الدخول الذكي</span></li></ul>'
      },
      {
        question: 'ماذا أفعل إذا فقدت بطاقتي أو سُرقت؟ كيف يمكنني إيقاف بطاقتي؟',
        answer:
          '<p>يمكنك إيقاف بطاقة الخصم الفوري / الائتمان الخاصة بك من خلال تطبيق البنك العربي الافريقي الدولي باتباع الخطوات التالية:</p><ul><li><span>إذا كنت ترغب في إيقاف <strong>بطاقة الخصم الفوري</strong> الخاصة بك، فاتجه إلى شاشة الحسابات الخاصة بك، واختر الحساب الذي تريد إيقاف بطاقته، واضغط على زر عرض بطاقاتي</span></li><li><span>إذا كنت ترغب في إيقاف <strong>بطاقتك الائتمانية</strong>، فاتجه إلى شاشة بطاقات الائتمان الخاصة بك</span></li><li><span>اضغط على زر إيقاف البطاقة</span></li><li><span>اختر الفترة الزمنية لإيقاف بطاقتك (مؤقت / دائم)</span></li></ul><p><em>على سبيل المثال:</em><br /><em>إذا لم تتمكن من العثور على بطاقتك، فيمكنك بسهولة إيقاف بطاقتك <strong>مؤقتًا</strong> للتأكد من عدم تمكن أي شخص من استخدامها، ويمكنك بعد ذلك إعادة تفعيل البطاقة بضغطة واحدة بمجرد العثور عليها.</em></p><p><em>إذا كنت متأكدًا من أن بطاقتك مفقودة وترغب في استبدالها، فيمكنك بسهولة إيقاف بطاقتك <strong>بشكل دائم</strong>.</em></p><ul><li><span>تأكيد إجراء الإيقاف</span></li></ul>'
      },
      {
        question: 'كيف يمكنني تفعيل بطاقتي؟',
        answer:
          '<p>يمكنك تفعيل بطاقة الخصم الفوري / الائتمان الخاصة بك من خلال تطبيق البنك العربي الافريقي الدولي باتباع الخطوات التالية:</p><ul><li><span>إذا كنت ترغب في تفعيل <strong>بطاقة الخصم الفوري</strong> الخاصة بك، فانتقل إلى شاشة الحسابات الخاصة بك، واختر الحساب الذي تريد تفعيل بطاقته، واضغط على عرض بطاقاتي</span></li><li><span>إذا كنت ترغب في تفعيل <strong>بطاقتك الائتمانية</strong>، فانتقل إلى شاشة بطاقات الائتمان الخاصة بك</span></li><li><span>اضغط على زر تفعيل البطاقة</span></li></ul><p><em>على سبيل المثال:</em><br /><em>إذا قمت بإصدار بطاقة جديدة، يمكنك تفعيلها بضغطة واحدة دون الحاجة للذهاب إلى الفرع أو الاتصال بمركز الاتصال. يمكنك استخدام التطبيق بشكل طبيعي بمجرد التفعيل من خلال التطبيق.</em></p><p><em>إذا قمت بإيقاف بطاقتك مؤقتًا من قبل وتريد استخدامها مرة أخرى، فيمكنك إعادة تفعيلها بسهولة دون الحاجة إلى الذهاب إلى الفرع أو الاتصال بمركز الاتصال.</em></p><ul><li><span>أدخل تاريخ انتهاء بطاقتك</span></li><li><span>أدخل كود التفعيل المرسل عبر رسالة نصية قصيرة على رقم هاتفك المحمول المسجل</span></li></ul>'
      },
      {
        question: 'كيف يمكنني التحويل إلى مستفيد؟',
        answer:
          '<p>في حالة عدم وجود المستفيد:</p><ul><li><span>اتجه إلى شاشة التحويلات</span></li><li><span>اختر تحويل إلى "مستفيد"</span></li><li><span><em>اضغط على زر "إضافة مستفيد جديد"</em></span></li><li><span><em>أدخل تفاصيل المستفيد <br />* ملاحظة: سيتم تحديد عملة التحويل بالجنيه المصري حيث لا يُسمح إلا بالتحويلات المحلية في الوقت الحالي</em></span></li><li><span><em>احفظ المستفيد والبدء في عملية التحويل أو يمكنك حفظ المستفيد فقط.</em></span></li><li><span><em>أدخل المبلغ الذي تريد تحويله والسبب</em></span></li><li><span><em>اختر حسابًا للتحويل منه</em></span></li><li><span><em>قم بمراجعة وتأكيد شاشة "مراجعة التحويل"</em></span></li><li><span><em>اختر "إنشاء رمز سري متغير"<br />* ملاحظة: : إذا لم يكن لديك تطبيق AAIB لرموز الأمان الذي تم تحميله على جهازك، فسيتم توجيهك لتحميله وتفعيله قبل إنشاء رمز سري متغير</em></span></li><li><span><em>سيفتح تطبيق AAIB لرموز الأمان تلقائيًا، أدخل الرمز السري لتطبيق AAIB لرموز الأمان لإنشاء رمز سري متغير للتحويل</em></span></li><li><span><em>أدخل الرمز السري المتغير الذي تم إنشاؤه على تطبيق البنك العربي الافريقي الدولي لتتمكن من تأكيد أو إكمال المعاملة<br />* ملاحظة: صلاحية الرمز السري المتغير 60 ثانية</em></span></li></ul><p>&nbsp;</p><p>في حالة وجود المستفيد:</p><ul><li><span><em>اتجه إلى شاشة التحويلات</em></span></li><li><span><em>اختر تحويل إلى "مستفيد"</em></span></li><li><span><em>اختر المستفيد الذي سيتم التحويل إليه</em></span></li><li><span><em>أدخل المبلغ الذي تريد تحويله والسبب</em></span></li><li><span><em>اختر حسابًا للتحويل منه</em></span></li><li><span><em>قم بمراجعة وتأكيد شاشة "مراجعة التحويل"</em></span></li><li><span><em>اختر "إنشاء رمز سري متغير"<br />* ملاحظة: إذا لم يكن لديك تطبيق AAIB لرموز الأمان الذي تم تحميله على جهازك، فسيتم توجيهك لتحميله وتفعيله قبل إنشاء رمز سري متغير</em></span></li><li><span><em>سيفتح تطبيق AAIB لرموز الأمان تلقائيًا، أدخل الرمز السري لتطبيق AAIB لرموز الأمان لإنشاء رمز سري متغير للتحويل</em></span></li><li><span><em>أدخل الرمز السري المتغير الذي تم إنشاؤه على تطبيق البنك العربي الافريقي الدولي لتتمكن من تأكيد أو إكمال المعاملة<br />* ملاحظة: صلاحية الرمز السري متغير 60 ثانية</em></span></li></ul>'
      },
      {
        question: 'كيف يمكنني التحويل بين حساباتي الشخصية؟',
        answer:
          '<p>يمكنك التحويل بين حساباتك الشخصية عن طريق إتباع الخطوات التالية:</p><ul><li><span>اتجه إلى شاشة "التحويلات"</span></li><li><span>اختر تحويل إلى "حسابي الشخصي" لعرض جميع الحسابات المتاحة التي يمكنك التحويل إليها</span></li><li><span>اختر الحساب المطلوب وأدخل المبلغ المراد تحويله</span></li><li><span>اختر الحساب الذي تريد التحويل منه</span></li><li><span>قم بمراجعة وتأكيد شاشة "مراجعة التحويل"</span></li></ul>'
      },
      {
        question: 'كيف يمكنني دفع فواتيري؟',
        answer:
          '<p>يمكنك دفع فواتيرك من خلال تطبيق الموبايل عن طريق إتباع الخطوات التالية:</p><ul><li><span><em>انتقل إلى شاشة "المدفوعات"<br /></em></span></li><li><span><em>اختر الفئة المتعلقة بدفع الفواتير<br /></em></span></li><li><span><em>اختر المفوتر الذي سيتم الدفع له<br /></em></span></li><li><span><em>أدخل رقم الهاتف المحمول أو الرقم القومي المتعلق بسداد الفاتورة ثم اختر المبلغ<br /></em></span></li><li><span><em>يمكنك ان تختار إضافة دفع هذه الفاتورة إلى المدفوعات المفضلة<br />* ملاحظة: إذا لم تقم بإضافته إلى مدفوعات المفضلة، يمكنك إعادة دفع الفاتورة في أي وقت آخر عن طريق "أخر مدفوعات</em></span></li><li><span>أدخل الرمز السري المتغير الذي تم إنشاؤه من تطبيق AAIB لرموز الأمان لمتابعة دفع الفاتورة</span></li><li><span>تأكيد الدفع</span></li></ul>'
      },
      {
        question: 'كيف يمكنني تسوية بطاقتي الائتمانية؟',
        answer:
          '<p>يمكنك تسوية بطاقتك الائتمانية من شاشة بطاقات الائتمان أو التحويلات.</p><p>&nbsp;</p><p>في شاشة بطاقات الائتمان:</p><ul><li><span>اختر بطاقة الائتمان التي تريد تسويتها</span></li><li><span>اضغط على زر "تسديد البطاقة"</span></li><li><span>اختر مبلغ الدفع</span></li><li><span>حدد الحساب الذي تريد الدفع منه</span></li><li><span>قم بمراجعة وتأكيد شاشة "مراجعة التحويل"</span></li></ul><p>&nbsp;</p><p>في شاشة التحويلات:</p><ul><li><span>اختر تحويل إلى "بطاقة ائتمان"</span></li><li><span>اختر بطاقة الائتمان المطلوبة وأدخل المبلغ للتحويل</span></li><li><span>اختر الحساب الذي تريد التحويل منه</span></li><li><span>قم بمراجعة وتأكيد شاشة "مراجعة التحويل"</span></li></ul>'
      }
    ]
  },
  tips: {
    en: [
      {
        question: 'Information Security',
        answer:
          '<ul>' +
          '<li>' +
          '<span>' +
          'AAIB will never call or email you to ask for your account details or card information (CVV, PIN Code or OTP). If this happened, please hang up immediately and call AAIB hotline on 19555 to verify and report the incident' +
          '</span>' +
          '</li>' +
          '<li><span>Do not access your mobile banking account(s) from any device(s) than your own or using any public Wi-Fi network. In case you forgot to log out, this might impose serious risks to your account(s)</span></li>' +
          '<li><span>Please log off instantly from your online banking upon finishing your transactions</span></li>' +
          '</ul>'
      },
      {
        question: 'Credentials',
        answer:
          '<ul>' +
          "<li><span>Don't use your National ID Number as a Personal Identification Number (PIN), user ID or password</span></li>" +
          '' +
          '<li><span>Your Password should be complex with at least 8 characters including letters, numbers, and symbols. Remember not to use any guessable information in your passwords such as birthday, phone number, name, etc</span></li>' +
          '</ul>'
      },
      {
        question: 'Fraud',
        answer:
          '<ul>' +
          '<li><span>It is advised not to store sensitive personal information or bank account numbers on your mobile device</span></li>' +
          '<li><span>It is advised not to install free software from unknown sources as this may expose your device(s) to attacks</span></li>' +
          '<li><span>Make sure to install an authentic anti-virus and anti-spyware on your device, and ensure running regular device scans</span></li>' +
          '</ul>'
      }
    ],
    ar: [
      {
        question: 'إرشادات أمنية',
        answer:
          '<ul>' +
          '<li>' +
          '<span>' +
          'البنك العربى الافريقى الدولى لم ولن يطلب معلومات عن حساباتك أو بطاقاتك عبر التليفون او البريد الالكتروني. في حالة حدوث ذلك، برجاء الاتصال بمركز خدمة عملاء البنك على 19555 للإبلاغ و التأكد من الواقعة' +
          '</span>' +
          '</li>' +
          '<li><span>ينصح بعدم الدخول على حسابكم المصرفي الالكتروني من أي جهاز غير خاص بكم أو من خلال الشبكات العامة، فذلك من شأنه تعريضكم لمخاطر جسيمة في حال نسيتم تسجيل الخروج من التطبيق</span></li>' +
          '<li><span>عليك بتسجيل الخروج من حسابكم المصرفي الالكتروني فور الانتهاء من معاملاتك المصرفية</span></li>' +
          '</ul>'
      },
      {
        question: 'بيانات الدخول',
        answer:
          '<ul>' +
          '<li><span>لا تستخدم رقمك القومي ككلمة سر، او اسم مستخدم او كرمز التأكيد</span></li>' +
          '' +
          '<li><span>يجب ان تكون كلمة السر مركبة ومكونة من حروف وأرقام و رموز.  تذكر ان لا تستخدم معلومات يسهل تخمينها مثل تاريخ الميلاد، رقم الهاتف، الأسم، الخ</span></li>' +
          '</ul>'
      },
      {
        question: 'الاحتيال',
        answer:
          '<ul>' +
          '<li><span>ينصح بعدم الاحتفاظ بمعلومات حساسة أو سرية عنكم أو عن حساباتكم على الهاتف المحمول</span></li>' +
          '<li><span>ينصح بعدم تحميل أي تطبيقات مجهولة المصدر على اجهزتكم الالكترونية، فمن شأنها تعريض اجهزتكم لمخاطر الاختراق الالكتروني</span></li>' +
          '<li><span>تأكد من تحميل تطبيقات او برامج اصلية للوقاية من الفيروسات و التجسس على اجهزتكم الالكترونية، مع مراعاة اجراء مسح شامل للملفات بشكل دوري</span></li>' +
          '</ul>'
      }
    ]
  },
  otp: {
    en: [
      {
        question: 'How can I activate “AAIB Token” App?',
        answer:
          '<p>Please follow the below steps to activate &ldquo;AAIB Token&rdquo; after downloading it:</p>\n' +
          '<ul>' +
          '<li><span>Open your AAIB mobile App</span></li>' +
          '<li><span>Go to your profile screen, choose token settings and click on &ldquo;Register Token App&rdquo;.</span></li>' +
          '<li><span>Click on send activation code, then you will be directed to Token App</span></li>' +
          '<li><span>Enter the activation code recieved on your registered mobile number along with your mobile banking username</span></li>' +
          '<li><span>Create your &ldquo;AAIB Token&rdquo; PIN</span></li>' +
          '</ul>'
      },
      {
        question: 'What to do if I forgot my “AAIB Token” PIN?',
        answer:
          '<p>You can reset your PIN code through the token settings in your mobile app Profile screen.</p>'
      },
      {
        question: 'What to do if I bought a new device, will I have to re-register?',
        answer:
          '<p>Yes, you should download it on your new device and re-register.</p>' +
          '<p>&nbsp;</p>' +
          '<p>If you don&rsquo;t know how to register, you can follow the registration steps under question number 1.</p>'
      },
      {
        question: 'What is the expiry duration of a OTP?',
        answer:
          '<p>You are expected to enter the generated OTP into the mobile app within 60 seconds of generation. If the 60 seconds passed, you will have to re-generate another OTP.</p>'
      }
    ]
  }
};
