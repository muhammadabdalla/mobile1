import crypto from 'crypto';
import { encryptionConfig } from '../config';
import { logger } from '../core/Logger';

const algorithm = encryptionConfig.algorithm;
const encryptionKey = Buffer.from(encryptionConfig.DB_ENCRYPTION_KEY || '', 'hex');
const separationSymbol = encryptionConfig.separationSymbol;
const iv = Buffer.from(encryptionConfig.DB_ENCRYPTION_IV || '', 'hex');

export function encryptData(data: string, key?: string, _id?: string): string {
  try {
    if (typeof data !== 'string') {
      logger.error(`can't encrypt data of type ${typeof data} `);
      return data;
    }

    if (data.trim() === '') {
      logger.error(`can't encrypt empty string key: ${key} / documendID : ${_id}`);
      return data;
    }

    const [_, encryptDataHex] = data.split(separationSymbol);
    if (encryptDataHex) {
      logger.error(`Cannot Encrypt data already encrypted / key: ${key} / DocumentID: ${_id} `);
      return data;
    }
    const cipher = crypto.createCipheriv(algorithm, encryptionKey, iv);
    let encryptedData = cipher.update(data, 'utf8', 'hex');
    encryptedData += cipher.final('hex');
    const tag = (cipher as crypto.CipherGCM).getAuthTag().toString('hex');
    return `${tag ? `${tag + '' + separationSymbol}` : ''}${encryptedData}`;
  } catch (error: any) {
    logger.error(`Function Name: encryptData error: ${error}`);
    return data;
  }
}

export function decryptData(encryptedData: string, key?: string, _id?: string): string {
  try {
    if (typeof encryptedData !== 'string') {
      logger.error(`can't encrypt data of type ${typeof encryptedData} `);
      return encryptedData;
    }
    const [tagHex, encryptDataHex] = encryptedData.split(separationSymbol);
    if (!encryptDataHex) {
      logger.info(`Cannot Decrypt non encrypted data / key: ${key} / DocumentID : ${_id}`);
      return encryptedData;
    }
    const tag = Buffer.from(tagHex, 'hex');
    const decipher = crypto.createDecipheriv(algorithm, encryptionKey, iv);
    (decipher as crypto.DecipherGCM).setAuthTag(tag);
    let decrypted = decipher.update(encryptDataHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (error) {
    logger.error(`Function Name: decryptData error: ${error}`);
    return encryptedData;
  }
}

export const encryptAllDocumentSensitiveFields = (
  document: any,
  SensitiveFields: string[],
  _id?: string
) => {
  try {
    if (!_id) {
      _id = document._id;
    }
    SensitiveFields.forEach((field: string) => {
      const nestedKeys = field.split('.');
      const key = nestedKeys[0];

      if (!document[key]) return;

      if (nestedKeys.length === 1) {
        document[key] = encryptData(document[key], key, _id);
      } else {
        nestedKeys.shift();
        encryptAllDocumentSensitiveFields(document[key], [nestedKeys.join('.')], _id);
      }
    });
  } catch (error: any) {
    logger.info(`Function exBulkEncryptFields: ${error.message}`);
    if (error.code === 'ERR_CRYPTO_INVALID_IV' || error.code === 'ERR_CRYPTO_INVALID_KEYLEN') {
      throw new Error(error.message);
    }
  }
};

export const decryptArrayOfDocuments = (documents: any, SensitiveFields: string[]) => {
  try {
    const documentsArray = Array.isArray(documents) ? documents : [documents];
    documentsArray.forEach((doc: any) => decryptAllDocumentSensitiveFields(doc, SensitiveFields));
  } catch (e) {
    logger.error(e);
  }
};

const decryptAllDocumentSensitiveFields = (
  document: any,
  SensitiveFields: string[],
  _id?: string
) => {
  try {
    if (!_id) {
      _id = document._id;
    }
    SensitiveFields.forEach((field: string) => {
      const nestedKeys = field.split('.');
      const key = nestedKeys[0];
      if (!document[key]) return;
      if (nestedKeys.length === 1) {
        document[key] = decryptData(document[key], key, _id);
      } else {
        nestedKeys.shift();
        decryptAllDocumentSensitiveFields(document[key], [nestedKeys.join('.')], _id);
      }
    });
  } catch (error: any) {
    logger.info(`Function exBulkEncryptFields: ${error.message}`);
    if (error.code === 'ERR_CRYPTO_INVALID_IV' || error.code === 'ERR_CRYPTO_INVALID_KEYLEN') {
      throw new Error(error.message);
    }
  }
};
