export const securityTips: any = {
  english: {
    informationSecurity: [
      'AAIB will never call or email you to ask for your account details or card information (CVV, PIN Code or OTP). If this happened, please hang up immediately and call AAIB hotline on 19555 to verify and report the incident',
      'Do not access your mobile banking account(s) from any device(s) than your own or using any public Wi-Fi network. In case you forgot to log out, this might impose serious risks to your account(s)',
      'Please log off instantly from your online banking upon finishing your transactions'
    ],
    Credentials: [
      "Don't use your National ID Number as a Personal Identification Number (PIN), user ID or password",
      'Your Password should be complex with at least 8 characters including letters, numbers, and symbols. Remember not to use any guessable information in your passwords such as birthday, phone number, name, etc'
    ],
    Fraud: [
      'It is advised not to store sensitive personal information or bank account numbers on your mobile device',
      'It is advised not to install free software from unknown sources as this may expose your device(s) to attacks',
      'Make sure to install an authentic anti-virus and anti-spyware on your device, and ensure running regular device scans'
    ]
  },
  arabic: {
    informationSecurity: [
      'البنك العربى الافريقى الدولى لم ولن يطلب معلومات عن حساباتك أو بطاقاتك عبر التليفون او البريد الالكتروني. في حالة حدوث ذلك، برجاء الاتصال بمركز خدمة عملاء البنك على 19555 للإبلاغ و التأكد من الواقعة',
      'ينصح بعدم الدخول على حسابكم المصرفي الالكتروني من أي جهاز غير خاص بكم أو من خلال الشبكات العامة، فذلك من شأنه تعريضكم لمخاطر جسيمة في حال نسيتم تسجيل الخروج من التطبيق',
      'عليك بتسجيل الخروج من حسابكم المصرفي الالكتروني فور الانتهاء من معاملاتك المصرفية'
    ],
    Credentials: [
      'لا تستخدم رقمك القومي ككلمة سر، او اسم مستخدم او كرمز التأكيد',
      'يجب ان تكون كلمة السر مركبة ومكونة من حروف وأرقام و رموز.  تذكر ان لا تستخدم معلومات يسهل تخمينها مثل تاريخ الميلاد، رقم الهاتف، الأسم، الخ'
    ],
    Fraud: [
      'ينصح بعدم الاحتفاظ بمعلومات حساسة أو سرية عنكم أو عن حساباتكم على الهاتف المحمول',
      'ينصح بعدم تحميل أي تطبيقات مجهولة المصدر على اجهزتكم الالكترونية، فمن شأنها تعريض اجهزتكم لمخاطر الاختراق الالكتروني',
      'تأكد من تحميل تطبيقات او برامج اصلية للوقاية من الفيروسات و التجسس على اجهزتكم الالكترونية، مع مراعاة اجراء مسح شامل للملفات بشكل دوري'
    ]
  }
};
