export default {
  accounts: {
    overDraftAccount: {
      en: 'Draft account not allowed to transfer'
    }
  },
  cards: {
    timeout: {
      en: 'Request Timeout'
    },
    missingValue: {
      en: 'Missing Value'
    },
    internalError: {
      en: 'Internal Server Error'
    },
    notActive: {
      en: 'Card not active'
    }
  },
  mobileNumberTransfer: {
    notFound: {
      en: 'Mobile number transfer not found for the customer'
    },
    alreadyExists: {
      en: 'Mobile number enabled to another customer'
    }
  },
  authorization: {
    notFound: {
      en: 'Authorization must be provided'
    },
    invalid: {
      en: 'Invalid token'
    },
    youngCustomer: {
      en: 'The user has not been a customer for 3 months yet'
    },
    kycExpired: {
      en: 'The customer has an expired KYC'
    },
    insufficientFunds: {
      en: 'This account has insufficient funds to request this chequebook'
    },
    invalidAccount: {
      en: 'This account does not meet the requirements to request this chequebook'
    }
  },
  customer: {
    pushIdNotFound: {
      en: 'Push Id not found'
    },
    pushNotificationsDisabled: {
      en: 'Push notifications is disabled for the user'
    },
    wrongNotificationCode: {
      en: 'Notification code does not exist'
    }
  }
};
