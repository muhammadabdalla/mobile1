// Mapper for environment variables

export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;

export const corsUrl = process.env.CORS_URL;

export const kafkaOptions = {
  clientId: process.env.KAFKA_CLIENT_ID || '',
  hosts: process.env.KAFKA_HOSTS?.split(',') || [],
  connectionTimeout: parseInt(process.env.KAFKA_CONNECTION_TIMEOUT || '3000'),
  requestTimeout: parseInt(process.env.KAFKA_REQUEST_TIMEOUT || '25000'),
  initialRetryTime: parseInt(process.env.KAFKA_INITIAL_RETRY_TIME || '1'),
  retries: parseInt(process.env.KAFKA_RETRIES || '1'),
  producerPolicy: {
    allowAutoTopicCreation: true
  },
  consumerPolicy: {
    groupId: process.env.CONSUMER_GROUP_ID || 'customer-ms',
    maxWaitTimeInMs: Number(process.env.CONSUMER_MAX_WAIT_TIME || '100'),
    allowAutoTopicCreation: true,
    sessionTimeout: Number(process.env.CONSUMER_SESSION_TIMEOUT || '30000'),
    heartbeatInterval: Number(process.env.CONSUMER_HEART_BEAT || '3000'),
    retry: {
      retries: parseInt(process.env.KAFKA_RETRIES || '1')
    }
  },
  numberOfPartitions: Number(process.env.KAFKA_PARTITION_NUMBER || '3')
};

export const adminCredentials = {
  username: process.env.ADMIN_USER,
  password: process.env.ADMIN_PASSWORD
};

export const paginationDefaults = {
  limit: 10,
  page: 1
};

export const notificationCodes: any = {
  CHQ: 'Cheque Settlement',
  TRF: 'Account to Account Transfer',
  FWRY: 'Bill Payment',
  INTTRF: 'International Transfers',
  'FWRY-CC': 'Bill Payment by Credit Card',
  'PAY-CC': 'Credit Card Payment',
  ACHTRF: 'ACH Transfer'
};

export const kafkaTopics = {
  customerResponse: 'customerResponse',
  validateTopic: 'validateTopic',
  smtp: 'smtp',
  statistics: 'statistics',
  kibana: 'kibanastatistics'
};

export const promiseTimeout = parseInt(process.env.PROMISE_TIMEOUT || '20000');

export const defaultLanguage = 'en';

export const mongoConfig = {
  url: process.env.DB_URL || ''
};

export const defaultRadius = Number(process.env.RADIUS || '5');

export const filters = { all: 'ALL', branch: 'BRANCH', atm: 'ATM' };

export const subAccounts = {
  categories: {
    currentCall: 'CurrAcc Call',
    currentDemand: 'CurrAcc Demand',
    savingMonthly: 'SAVING AC MONTH',
    savingQuarterly: 'SAVING AC QUART',
    savingSemiAnnually: 'SAVING AC SEM A',
    savingAnnually: 'SAVING AC ANUAL'
  }
};

export const status = {
  success: 'success',
  fail: 'fail',
  timeout: 'timeout'
};

export const dailyTransferLimit = 500000;
export const dailyTransferForeignLimit = 5000;
export const t24Url = process.env.T24_BASE_URL;

export const encryptionConfig = {
  DB_ENCRYPTION_KEY: process.env.DB_ENCRYPTION_KEY,
  algorithm: 'aes-256-gcm',
  separationSymbol: '::)',
  DB_ENCRYPTION_IV: process.env.DB_ENCRYPTION_IV,
  ENCRYPTION: process.env.ENCRYPTION
};
