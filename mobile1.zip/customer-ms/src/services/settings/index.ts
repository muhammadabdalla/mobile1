import {
  InternalError,
  YoungCustomerError,
  KYCExpError,
  InsufficientFundsError,
  InvalidChequebookAccount,
  BadRequestError,
  ForbiddenError
} from '../../core/ApiError';
import { logger } from '../../core/Logger';
import Customer from './model';
import ChequesCaching from '../models/ChequesCaching';
import Rating from '../models/rating';
import { staticPages } from '../../helpers/faq';
import { termsAndConditions } from '../../helpers/termsAndConditions';
import { securityTips } from '../../helpers/securityTips';
import { chequebookTermsAndConditions } from '../../helpers/chequebookTaC';
import messages from '../../messages';
import {
  defaultLanguage,
  kafkaTopics,
  notificationCodes,
  filters,
  subAccounts,
  dailyTransferLimit,
  dailyTransferForeignLimit
} from '../../config';
import { atms } from '../../data/atms-branches';
import { branches } from '../../data/branches';
import { hotlines } from '../../data/hotlines';
import { produce, prepareKafkaResponse } from '../../kafka';
import * as lodash from 'lodash';
import moment from 'moment';
import updateStatistics from '../../helpers/statistics';
import Notification from '../models/notification';
import { CustomerSettingInterface } from '../../types/app-request';

export const getUserSettings = async (cif: string) => {
  try {
    const userSettings: CustomerSettingInterface | null = await Customer.findOne(
      { cif },
      { createdAt: 0, updatedAt: 0, cif: 0, _id: 0, __v: 0 }
    );
    let savedUserDocument;
    if (!userSettings || userSettings.firstLogin) {
      if (!userSettings) {
        savedUserDocument = await new Customer({
          cif,
          firstLogin: false
        }).save();
      } else if (userSettings.firstLogin) {
        await Customer.updateOne({ cif }, { $set: { firstLogin: false } });
      }
      return {
        firstLogin: true,
        showSoftTokenApp: true,
        showMobileAdd: true,
        dailyTransferLimit: dailyTransferLimit,
        dailyTransferForeignLimit: dailyTransferForeignLimit,
        deliveryMechanism: savedUserDocument?.deliveryMechanism,
        deliveryMechanismFirstTime: savedUserDocument?.deliveryMechanismFirstTime,
        showLinkingPopUp: true
      };
    }
    userSettings.dailyTransferLimit = dailyTransferLimit;
    userSettings.dailyTransferForeignLimit = dailyTransferForeignLimit;
    const result: any = { ...userSettings };
    return { ...result._doc, disallowedTravelCurr: ['EGP'] };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const updateUserSettings = async (cif: string, body: any) => {
  try {
    await Customer.updateOne({ cif }, { $set: body });
    return { message: 'Success' };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getFaq = async (type: string, language = 'en') => {
  try {
    return { result: staticPages[type][language] || staticPages[type][defaultLanguage] };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getHotline = async (language = 'en') => {
  try {
    return { result: hotlines[language] || hotlines['en'] };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getUserNotifications = async (cif: string, page: number, limit: number) => {
  try {
    const notifications = await Notification.aggregate([
      { $match: { cif } },
      { $sort: { notificationDate: -1 } },
      {
        $skip: Number(page - 1) * Number(limit)
      },
      {
        $limit: Number(limit)
      }
    ]);
    const totalCount = await Notification.aggregate([
      { $match: { cif } },
      { $count: 'totalCount' }
    ]);
    return { totalCount: totalCount[0]?.totalCount || 0, notifications };
  } catch (e: any) {
    throw new InternalError();
  }
};

export const sendNotification = async (body: any, tracingHeaders: any) => {
  try {
    body.title = notificationCodes[body.notificationCode];
    if (!body.title) {
      throw new BadRequestError(messages.customer.wrongNotificationCode.en);
    }
    const customer = await Customer.findOne({ cif: body.cif, pushNotifications: true });

    if (!customer) throw new BadRequestError(messages.customer.pushNotificationsDisabled.en);

    if (customer) {
      if (customer.pushId) {
        const data = {
          topic: kafkaTopics.smtp,
          function: 'sendNotification',
          pushId: customer.pushId,
          title: body.title,
          message: body.message
        };
        await produce(data, tracingHeaders, false);
      }
      const notification = new Notification({ ...body, notificationDate: new Date() });
      await notification.save();
      await Customer.updateOne({ cif: body.cif }, { hasReadNotification: false });
      return { message: 'Sucess' };
    } else {
      throw new BadRequestError(messages.customer.pushIdNotFound.en);
    }
  } catch (e: any) {
    logger.error(e.message);
    if (e.type === 'BadRequestError') {
      throw new BadRequestError(e.message);
    }
    throw new InternalError();
  }
};

export const getTermsAndConditions = async (language = 'en') => {
  try {
    const data = termsAndConditions[language] || termsAndConditions[defaultLanguage];
    return { result: data.replace(/[\n]/gm, '') };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getSecurityTips = async () => {
  try {
    const data = securityTips;
    return { result: data };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const handleFilter = (data: any, filter: string) => {
  let filteringOptions: string[] = [];

  if (filter == filters.all) {
    filteringOptions = ['Branch', 'Payroll', 'Off-site'];
  }
  if (filter == filters.branch) {
    filteringOptions = ['Branch'];
  }
  if (filter == filters.atm) {
    filteringOptions = ['Payroll', 'Off-site'];
  }
  return lodash.filter(data, (item) => {
    return filteringOptions.indexOf(item.type) >= 0;
  });
};

export const handleSearch = (data: any, search: string) => {
  return lodash.filter(data, (item) => {
    return new RegExp(search, 'gi').test(item.name);
  });
};

export const handleProxyLocation = (
  atmsData: any,
  latitude: number,
  longitude: number,
  range: number
) => {
  const filteredData: any[] = [];

  atmsData.map((item: any) => {
    if (latitude === item.googleLatitude && longitude === item.googleLongitude) {
      item.distance = 0;
      filteredData.push(item);
    } else {
      const radLat1 = (Math.PI * latitude) / 180;
      const radLat2 = (Math.PI * item.googleLatitude) / 180;
      const theta = longitude - item.googleLongitude;
      const radTheta = (Math.PI * theta) / 180;
      let dist =
        Math.sin(radLat1) * Math.sin(radLat2) +
        Math.cos(radLat1) * Math.cos(radLat2) * Math.cos(radTheta);
      dist = Math.acos(dist);
      dist = (dist * 180) / Math.PI;
      dist = dist * 60 * 1.1515 * 1.609344;
      if (Number(dist) <= range) {
        item.distance = Number(dist.toFixed(1));
        filteredData.push(item);
      }
    }
  });

  return lodash.orderBy(filteredData, ['distance'], ['asc']);
};

export const getListOfAtms = async (
  latitude: any,
  longitude: any,
  range: number,
  search: any,
  filter: string,
  language = defaultLanguage
) => {
  try {
    const atmsData = atms[language] || atms[defaultLanguage];
    let filteredData: any[] = [];

    if (search) {
      filteredData = handleSearch(atmsData, search);
    } else if (latitude && longitude) {
      filteredData = handleProxyLocation(atmsData, latitude, longitude, range);
    } else {
      filteredData = atmsData;
    }
    return handleFilter(filteredData, filter);
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getListOfBranches = async (search: any, language = defaultLanguage) => {
  const branchesData = branches[language] || branches[defaultLanguage];
  if (search) {
    const filteredData = handleSearch(branchesData, search);
    return filteredData;
  } else {
    return branchesData;
  }
};

export const checkLimit = async (
  Cif: string,
  { CountryCode, TransferScope, Amount, Currency }: any,
  authorization: string,
  tracingHeaders?: any
) => {
  try {
    const data = {
      topic: 't24Request',
      route: `customer/checklimit`,
      method: 'post',
      authorization,
      body: {
        Cif,
        CountryCode,
        TransferScope,
        Amount,
        Currency
      }
    };
    const producerData = await produce(data, tracingHeaders);
    return await prepareKafkaResponse(producerData);
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError();
  }
};

const checkValidAccount = async (
  accID: string,
  fees: number,
  authorization: string,
  tracingHeaders: string
) => {
  const accountData = {
    topic: 't24Request',
    route: `account/${accID}`,
    authorization
  };
  const accountProducerData = await produce(accountData, tracingHeaders);
  const accountKafkaData = await prepareKafkaResponse(accountProducerData);

  const accountInfo = accountKafkaData[0];

  if (
    accountInfo.Currency != 'EGP' ||
    accountInfo.Status != 'ACTIVE' ||
    (accountInfo.Category != subAccounts.categories.currentCall &&
      accountInfo.Category != subAccounts.categories.currentDemand)
  ) {
    throw new InvalidChequebookAccount();
  }

  if (accountInfo.AvailableBalance < fees) {
    throw new InsufficientFundsError();
  }
};

const checkValidCustomer = async (
  cif: string,
  accID: string,
  fees: number,
  authorization: string,
  tracingHeaders: string
) => {
  await checkValidAccount(accID, fees, authorization, tracingHeaders);

  const customerData = {
    topic: 't24Request',
    route: `customer/${cif}`,
    authorization
  };
  const customerProducerData = await produce(customerData, tracingHeaders);
  const customerKafkaData = await prepareKafkaResponse(customerProducerData);

  const customerInfo = customerKafkaData[0];

  const currentDate = moment();
  const customerAge = moment(String(customerInfo.CustomerSince));
  const kycExp = moment(String(customerInfo.KYCDate));

  if (currentDate.diff(customerAge, 'months') < 3) {
    throw new YoungCustomerError();
  }

  if (currentDate.diff(kycExp, 'minutes') > 0) {
    throw new KYCExpError();
  }
};

export const validateChequeBook = async (
  body: any,
  cif: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    body.Cif = cif;
    const data = {
      topic: 't24Request',
      route: `chequebook/validate`,
      authorization,
      method: 'post',
      body
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);

    return {
      Fees: result.Price
    };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError();
  }
};

export const submitChequeBook = async (
  body: any,
  cif: string,
  user: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    await validateDebitAccount(body.AccId);
    const chequebook = await validateChequeBook(body, cif, authorization, tracingHeaders);
    await checkValidCustomer(cif, body.AccId, chequebook.Fees, authorization, tracingHeaders);

    body.Cif = cif;
    const data = {
      topic: 't24Request',
      route: `chequebook/submit`,
      authorization,
      method: 'post',
      body
    };

    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);

    updateStatistics('', {
      cif: cif,
      user,
      type: 'request',
      subType: 'chequeBookRequest',
      microservice: 'customer',
      referenceId: result.TransactionId,
      numberOfLeaflets: body.NumberOfLeaves,
      branch: body.DeliveryBranch,
      success: result.Status,
      date: new Date()
    });

    try {
      const query = { accountId: body.AccId };

      const update = {
        $set: {
          cif,
          accountId: body.AccId,
          ChequeId: result.TransactionId,
          Status: result.Status,
          Fees: chequebook.Fees
        }
      };

      const options = { upsert: true };

      await ChequesCaching.updateOne(query, update, options);
    } catch (error) {
      logger.error('failed to cach cheque book');
    }

    return { message: 'Success' };
  } catch (e: any) {
    logger.debug(e.message);
    updateStatistics('', {
      cif,
      user,
      type: 'request',
      subType: 'chequeBookRequest',
      microservice: 'customer',
      referenceId: null,
      numberOfLeaflets: body.NumberOfLeaves,
      branch: body.DeliveryBranch,
      success: false,
      date: new Date()
    });
    if (e.message === messages.authorization.youngCustomer.en) throw new YoungCustomerError();
    else if (e.message === messages.authorization.kycExpired.en) throw new KYCExpError();
    else if (e.message === messages.authorization.invalidAccount.en)
      throw new InvalidChequebookAccount();
    else if (e.message === messages.authorization.insufficientFunds.en)
      throw new InsufficientFundsError();
    else throw new InternalError();
  }
};

export const validateDebitAccount = async (AccId: string) => {
  const draftAccRegex = /^[0-9]{8}15[0-9][1-9][0-9]{4}$/;
  if (draftAccRegex.test(AccId)) throw new ForbiddenError(messages.accounts.overDraftAccount.en);
};

export const getChequebookTermsAndConditions = async (language = 'en') => {
  try {
    const data =
      chequebookTermsAndConditions[language] || chequebookTermsAndConditions[defaultLanguage];
    return { result: data.replace(/[\n]/gm, '') };
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getChequebookBranches = async (authorization: string, tracingHeaders: any) => {
  try {
    const data = {
      topic: 't24Request',
      route: `list/branch`,
      authorization
    };

    const producerData = await produce(data, tracingHeaders);
    return prepareKafkaResponse(producerData);
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

const formatCachingDataOfChequeBooks = async (accId: string, data: any) => {
  const cashedChequBook: any = await ChequesCaching.find({
    $or: [{ accountId: accId }, { cif: accId }]
  });

  const finalData = data.map((c: any) => {
    const Fees =
      cashedChequBook.filter((f: any) => {
        return c.ID === f.ChequeId;
      })[0]?.Fees || 0;
    return { ...c, Fees };
  });

  return finalData;
};

export const getChequebookHistory = async (
  accountId: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      topic: 't24Request',
      route: `chequebook/requests/${accountId}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);

    const chequeBookData: any = await formatCachingDataOfChequeBooks(
      accountId,
      await prepareKafkaResponse(producerData)
    );

    return chequeBookData;
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getChequebookUnauthHistory = async (
  accountId: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      topic: 't24Request',
      route: `chequebook/requests/unauth/${accountId}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);

    const chequeBookData: any = await formatCachingDataOfChequeBooks(
      accountId,
      await prepareKafkaResponse(producerData)
    );

    return chequeBookData;
  } catch (e: any) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const submitRating = async (
  cif: string,
  user: string,
  phoneNumber: string,
  body: any,
  platform: string
) => {
  try {
    const rating = new Rating({
      cif,
      user,
      phoneNumber,
      ...body
    });
    await rating.save();

    updateStatistics('', {
      cif,
      user,
      phoneNumber,
      type: 'rating',
      subType: 'submitRating',
      microservice: 'customer',
      stars: body.stars || '',
      comment: body.comment || '',
      success: true,
      platform,
      date: new Date()
    });

    return { message: 'Success' };
  } catch (e: any) {
    logger.error(e);
    updateStatistics('', {
      cif,
      user,
      phoneNumber,
      type: 'rating',
      subType: 'submitRating',
      microservice: 'customer',
      stars: body.stars || '',
      comment: body.comment || '',
      success: false,
      error: e.message,
      platform,
      date: new Date()
    });
  }
};
export const reportIssue = async (
  cif: string,
  user: string,
  phoneNumber: string,
  body: any,
  platform: string
) => {
  try {
    updateStatistics('', {
      cif,
      user,
      phoneNumber,
      type: 'report',
      subType: 'reportIssue',
      microservice: 'customer',
      category: body.category,
      comment: body.comment,
      success: true,
      platform,
      date: new Date()
    });
    return { message: 'Success' };
  } catch (e: any) {
    logger.error(e);
    throw new InternalError();
  }
};

export const increaseSuccessfulLogins = async (cif: string) => {
  try {
    const userSettings = await Customer.findOne(
      { cif },
      { createdAt: 0, updatedAt: 0, cif: 0, _id: 0, __v: 0 }
    );
    if (!userSettings) {
      const newUserSettings = new Customer({
        cif,
        firstLogin: true,
        numberOfWebLogins: 1
      });
      await newUserSettings.save();
    } else {
      await Customer.updateOne(
        { cif },
        { $inc: { numberOfWebLogins: 1 }, $set: { firstLogin: false } }
      );
    }
  } catch (e) {
    logger.error(e);
  }
};

export const updateCustomerTransfers = async (cif: string) => {
  try {
    const userSettings = await Customer.findOne(
      { cif },
      { createdAt: 0, updatedAt: 0, cif: 0, _id: 0, __v: 0 }
    );
    if (!userSettings?.transactionsCount) {
      await Customer.updateOne({ cif }, { transactionsCount: 1, showRatePopUp: true });
    } else if (userSettings.loginsInQuarterAfterRate >= 10) {
      await Customer.updateOne({ cif }, { showRatePopUp: true, $inc: { transactionsCount: 1 } });
    } else {
      await Customer.updateOne({ cif }, { $inc: { transactionsCount: 1 } });
    }
  } catch (e) {
    logger.error(e);
  }
};

export const modifyEmail = async (
  cif: string,
  body: any,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    body = {
      Cif: cif,
      Email: body.Email
    };
    const data = {
      topic: 't24Request',
      route: `customer/update/submit`,
      authorization,
      method: 'post',
      body
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);

    return { message: 'Success' };
  } catch (e: any) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const getCustomerInfo = async (cif: string, authorization: string, tracingHeaders: any) => {
  try {
    const data = {
      topic: 't24Request',
      route: `customer/${cif}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    return result;
  } catch (e: any) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const getCustomerAddress = async (
  cif: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const result = await getCustomerInfo(cif, authorization, tracingHeaders);
    return result[0].Address || '';
  } catch (e: any) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const UpdateDeliveryMechanism = async (
  Cif: string,
  { DeliveryMechanism }: any,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      topic: 't24Request',
      route: `customer/update/submit`,
      method: 'post',
      authorization,
      body: {
        Cif,
        DeliveryMechanism
      }
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    await Customer.updateOne(
      { cif: Cif },
      { $set: { deliveryMechanism: DeliveryMechanism, deliveryMechanismFirstTime: false } }
    );
    return { message: 'Success', status: DeliveryMechanism };
  } catch (e: any) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};
