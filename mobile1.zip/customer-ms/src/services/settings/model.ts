import mongoose from 'mongoose';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionModel } from '../../helpers/encryptionModel';
import { encryptionConfig } from '../../config';

const model = new mongoose.Schema(
  {
    cif: String,
    defaultAccount: String,
    pushId: String,
    firstLogin: {
      type: Boolean,
      default: true
    },
    showSoftTokenApp: {
      type: Boolean,
      default: true
    },
    showSharePopup: {
      type: Boolean,
      default: true
    },
    showBalance: {
      type: Boolean,
      default: true
    },
    showMobileTransferPopup: {
      type: Boolean,
      default: true
    },
    pushNotifications: Boolean,
    kycLastUpdatedDate: String,
    registrationAlertUpdatedDate: String,
    tutorials: [String],
    showMobileAdd: { type: Boolean, default: true },
    numberOfWebLogins: Number,
    hasReadNotification: {
      type: Boolean,
      default: true
    },
    lastNotificationId: {
      type: String,
      default: null
    },
    showRatePopUp: {
      type: Boolean,
      default: false
    },
    lastRateDate: {
      type: Date
    },
    loginsInQuarterAfterRate: {
      type: Number,
      default: 0
    },
    transactionsCount: {
      type: Number
    },
    dailyTransferLimit: Number,
    dailyTransferForeignLimit: Number,
    deliveryMechanism: {
      type: String,
      default: 'Send Mail'
    },
    deliveryMechanismFirstTime: {
      type: Boolean,
      default: true
    },
    showLinkingPopUp: {
      type: Boolean,
      default: true
    },
    isEncrypted: Boolean
  },
  { timestamps: true }
);
model.index({ cif: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('Customer', model);
