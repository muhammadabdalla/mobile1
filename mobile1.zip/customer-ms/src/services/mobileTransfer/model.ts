import mongoose from 'mongoose';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionModel } from '../../helpers/encryptionModel';
import { encryptionConfig } from '../../config';

const model = new mongoose.Schema(
  {
    cif: {
      type: String,
      unique: true
    },
    enabled: {
      type: Boolean,
      default: true
    },
    fullName: String,
    accountNumber: String,
    mobileNumber: String,
    isEncrypted: Boolean
  },
  { timestamps: true, versionKey: false }
);
model.index({ cif: 1 });
model.index({ phoneNumber: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('mobiletransfer', model);
