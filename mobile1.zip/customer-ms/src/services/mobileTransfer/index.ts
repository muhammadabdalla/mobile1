import moment from 'moment';
import { InternalError, NotFoundError } from '../../core/ApiError';
import MobileTransfer from './model';
import Customer from '../settings/model';
import messages from '../../messages';
import { MobileTransferInterface } from 'app-request';
import { produce, prepareKafkaResponse } from '../../kafka';
import { logger } from '../../core/Logger';
import { getCustomerInfo } from '../settings';
import generateAdminToken from '../../helpers/adminToken';

export const addOrUpdateCustomerMobileTransfer = async (
  cif: string,
  fullName: string,
  phoneNumber: string,
  body: MobileTransferInterface,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    if (!phoneNumber) {
      throw new InternalError();
    }
    if (body.accountNumber) {
      const isValidAccountNumber = verifyAccountNumber(cif, body.accountNumber);
      if (!isValidAccountNumber) {
        throw new InternalError();
      }
    }

    await checkValidAccount(body.accountNumber, authorization, tracingHeaders);

    const checkExistance = await MobileTransfer.find({
      $and: [{ cif: { $ne: cif } }, { mobileNumber: phoneNumber }, { enabled: true }]
    });

    if (checkExistance && checkExistance.length > 0) {
      throw new InternalError(messages.mobileNumberTransfer.alreadyExists.en);
    }

    const customerMobileTransfer = await MobileTransfer.findOne({ cif: cif });

    body.fullName = fullName;
    body.mobileNumber = phoneNumber;

    if (customerMobileTransfer) {
      await MobileTransfer.updateOne({ cif }, body);
      return { message: 'success' };
    }

    body.cif = cif;
    const newCustomerMobileTransfer = new MobileTransfer(body);
    await newCustomerMobileTransfer.save();

    return { message: 'success' };
  } catch (e: any) {
    logger.debug(e.message);
    throw e;
  }
};

export const getCustomerMobileTransfer = async (
  cif: string,
  fullName: string,
  mobileNumber: string
) => {
  try {
    mobileNumber = mobileNumber.slice(-11);
    const searchCondition = mobileNumber ? { mobileNumber } : { cif };
    const customerMobileTransfer = await MobileTransfer.findOne(searchCondition, {
      _id: 0,
      createdAt: 0,
      updatedAt: 0
    });
    if (customerMobileTransfer) {
      customerMobileTransfer.fullName = maskString(customerMobileTransfer.fullName as string, 3);
      return customerMobileTransfer;
    } else {
      if ('cif' in searchCondition) {
        return {
          accountNumber: '',
          mobileNumber: '',
          fullName: fullName,
          cif: cif,
          enabled: false
        };
      } else {
        throw new NotFoundError(messages.mobileNumberTransfer.notFound.en);
      }
    }
  } catch (e: any) {
    logger.debug(e.message);
    throw e;
  }
};

export const getCustomerDetail = async (
  cif: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const result = await getCustomerInfo(cif, authorization, tracingHeaders);
    return result.length > 0 ? result[0] : false;
  } catch (e: any) {
    logger.error(e.message);
    throw new InternalError();
  }
};

export const validateMobileNumberForTransfer = async (
  mobileNumber: string,
  tracingHeaders: any
) => {
  try {
    let isValid = false;
    let maskedName = null;
    const customerMobileTransfer = await MobileTransfer.findOne(
      { mobileNumber },
      {
        _id: 0,
        createdAt: 0,
        updatedAt: 0
      }
    );

    if (customerMobileTransfer?.enabled) {
      isValid = true;
    }

    if (customerMobileTransfer?.cif) {
      const adminToken = await generateAdminToken();
      const adminAuthorizationHeader = `Bearer ${adminToken}`;

      const customerData = await getCustomerDetail(
        customerMobileTransfer?.cif,
        adminAuthorizationHeader,
        tracingHeaders
      );

      if (customerData) {
        maskedName = maskFullName(customerData.ShortName);
      }
    }

    return { isValid, maskedName };
  } catch (e: any) {
    console.log(e);
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

const verifyAccountNumber = (cif: string, accountNumber: string) => {
  return accountNumber.startsWith(cif);
};

const checkValidAccount = async (
  accountNumber: string,
  authorization: string,
  tracingHeaders: any
) => {
  const accountData = {
    topic: 't24Request',
    route: `account/${accountNumber}`,
    authorization
  };
  const accountProducerData = await produce(accountData, tracingHeaders);
  const accountKafkaData = await prepareKafkaResponse(accountProducerData);

  const accountInfo = accountKafkaData[0];

  if (accountInfo.Currency != 'EGP') {
    throw new InternalError();
  }
};

const maskString = (stringToMask: string, n = 2): string => {
  let maskedString = stringToMask.slice(0, n);
  for (const character of stringToMask.slice(n, -n)) {
    maskedString += character == ' ' ? ' ' : '*';
  }
  maskedString += stringToMask.slice(-n);
  return maskedString;
};

const maskAndKeepFirst = (s: string): string => {
  return `${s.substring(0, 1) + '*'.repeat(s.substring(1, s.length).length)}`;
};

const maskFullName = (stringToMask: string): string => {
  const strArray = stringToMask.split(' ');
  let maskedName = '';
  for (let i = 0; i < strArray.length; i++) {
    const element = strArray[i];
    if (i === 0) maskedName = element;
    else maskedName += ` ${maskAndKeepFirst(element)}`;
  }
  return maskedName;
};

export const updateCustomerInfo = async (data: any) => {
  try {
    const mobileTransfer = await MobileTransfer.findOne({ cif: data.Id });
    const userSettings = await Customer.findOne(
      { cif: data.Id },
      { createdAt: 0, updatedAt: 0, cif: 0, _id: 0, __v: 0 }
    );

    if (!mobileTransfer) {
      await new MobileTransfer({
        cif: data.Id,
        fullName: data.ShortName,
        enabled: false,
        mobileNumber: data.Sms[0]
      }).save();
    } else {
      mobileTransfer.mobileNumber = data.Sms[0];
      mobileTransfer.fullName = data.ShortName;
      mobileTransfer.save();
    }

    if (userSettings?.lastRateDate) {
      const now = moment(Date.now());
      const lastRateDate = moment(userSettings.lastRateDate);
      const duration = moment.duration(now.diff(lastRateDate)).months();
      if (duration <= 3) {
        await Customer.updateOne({ cif: data.Id }, { $inc: { loginsInQuarterAfterRate: 1 } });
      } else {
        await Customer.updateOne(
          { cif: data.Id },
          { loginsInQuarterAfterRate: 1, lastRateDate: new Date(), showRatePopUp: false }
        );
      }
    }

    await Customer.updateOne({ cif: data.Id }, { deliveryMechanism: data.DeliveryMechanism });
  } catch (e) {
    logger.error(e);
  }
};
