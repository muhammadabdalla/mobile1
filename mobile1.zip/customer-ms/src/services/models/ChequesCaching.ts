import mongoose from 'mongoose';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionModel } from '../../helpers/encryptionModel';
import { encryptionConfig } from '../../config';

const model = new mongoose.Schema({
  cif: String,
  accountId: String,
  ChequeId: String,
  Status: String,
  Fees: Number,
  isEncrypted: Boolean
});

model.index({ cif: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('ChequesCaching', model);
