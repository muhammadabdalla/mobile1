import mongoose from 'mongoose';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionModel } from '../../helpers/encryptionModel';
import { encryptionConfig } from '../../config';

const model = new mongoose.Schema({
  cif: String,
  user: String,
  phoneNumber: String,
  stars: Number,
  comment: String,
  isEncrypted: Boolean
});
model.index({ stars: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('Rating', model);
