import { Request } from 'express';

declare interface PublicRequest extends Request {
  apiKey: string;
}

declare interface RoleRequest extends PublicRequest {
  currentRoleCode: string;
}

declare interface ProtectedRequest extends RoleRequest {
  user: any;
  accessToken: string;
  correlationId: any;
}

declare interface MobileTransferInterface {
  cif: string;
  accountNumber: string;
  mobileNumber: string;
  fullName: string;
  enabled: boolean;
}

declare interface CustomerSettingInterface {
  cif: string;
  defaultAccount: string;
  pushId: string;
  firstLogin: boolean;
  showSoftTokenApp: boolean;
  showSharePopup: boolean;
  showBalance: boolean;
  showMobileTransferPopup: boolean;
  pushNotifications: boolean;
  kycLastUpdatedDate: string;
  registrationAlertUpdatedDate: string;
  tutorials: [string];
  showMobileAdd: boolean;
  numberOfWebLogins: number;
  hasReadNotification: boolean;
  lastNotificationId: string;
  dailyTransferLimit: number;
  dailyTransferForeignLimit: number;
  showRatePopUp: boolean;
  lastRateDate: Date;
  loginsInQuarterAfterRate: number;
  transactionsCount: number;
  deliveryMechanism: string;
  deliveryMechanismFirstTime: {
    type: string;
    default: true;
  };
  showLinkingPopUp: boolean;
  disallowedTravelCurr: [string];
}
