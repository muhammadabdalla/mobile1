export const branches: any = {
  en: [
    {
      name: '10th of Ramadan Branch',
      location: '3rd Industrial Zone, Area MC3',
      governorateName: 'Cairo',
      googleLatitude: 30.30176,
      googleLongitude: 31.746269,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: '6th October Branch',
      location: '4th Industrial Zone, 2/3 Banks Area, 6th October City ',
      governorateName: 'Giza',
      googleLatitude: 29.944218545337,
      googleLongitude: 30.8954358534657,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Abbasia Branch',
      location: 'Abbasia Sq.',
      governorateName: 'Cairo',
      googleLatitude: 30.0726133762396,
      googleLongitude: 31.2868563575256,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Al Alfy Branch',
      location: '45 D El Gomhoria St. ',
      governorateName: 'Cairo',
      googleLatitude: 30.054245,
      googleLongitude: 31.246028,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Al Fayoum Branch',
      location: '17 Al Horreya St., Bandar Al Fayoum ',
      governorateName: 'Fayoum',
      googleLatitude: 29.3074062945988,
      googleLongitude: 30.8479014978901,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Al Shams Club Branch',
      location: '79 Abd EL-Hamid Badawy St., Heliopolis ',
      governorateName: 'Cairo',
      googleLatitude: 30.1188880122237,
      googleLongitude: 31.3530805172629,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Alex. Branch',
      location: '73 Eng. Ahmed Mohamed Ismail St., Wabour El Miyah ',
      governorateName: 'Alexandria',
      googleLatitude: 31.1984800658828,
      googleLongitude: 29.9175942428019,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Alex. Port Branch',
      location: 'Alex. Port, Gate Entrance No. 54 ',
      governorateName: 'Alexandria',
      googleLatitude: 31.164861,
      googleLongitude: 29.861515,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Assuit Branch',
      location: '101 ElHelaly St., next to directorate of security, Asuit ',
      governorateName: 'Assiut',
      googleLatitude: 27.183785,
      googleLongitude: 31.194395,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Aswan Branch ',
      location: 'Aswan Plaza Towers, Corniche Road, Aswan',
      governorateName: 'Aswan',
      googleLatitude: 24.097428,
      googleLongitude: 32.898389,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Azhar Branch  ',
      location: '160 Gohar ElKaed St., Cairo',
      governorateName: 'Cairo',
      googleLatitude: 30.0457604299398,
      googleLongitude: 31.2666263529418,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Banha Branch',
      location: '60 Cornich ElNile St., Banha',
      governorateName: 'Banha',
      googleLatitude: 30.4790265843749,
      googleLongitude: 31.1796983210443,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Bani Suef Branch',
      location: 'Nile Cornich St., Zahret Enile Building, Beni Sweif City ',
      governorateName: 'Bani Suef',
      googleLatitude: 29.06337,
      googleLongitude: 31.103273,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Borg El Arab Branch  ',
      location: 'New Borg El-Arab City, Banks District ',
      governorateName: 'Alexandria',
      googleLatitude: 30.8844083385561,
      googleLongitude: 29.5772304451746,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Cairo Festival City Branch ',
      location: 'Cairo Festival City, Unit # 1-086',
      governorateName: 'Cairo',
      googleLatitude: 30.02931,
      googleLongitude: 31.40769,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'City Stars Branch ',
      location: 'City stars Mall, Unit 1240B, Market level Phase 2 ',
      governorateName: 'Cairo',
      googleLatitude: 30.0731223267534,
      googleLongitude: 31.3473722297713,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Damanhur Branch',
      location: '56 Abd El Sallam El Shazly St., Damnhour ',
      governorateName: 'Damnhour ',
      googleLatitude: 31.0374837517845,
      googleLongitude: 30.4549872661027,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Damietta Branch',
      location: 'Damiette-Ras ElBur Road, Corniche ElNil ',
      governorateName: 'Damietta',
      googleLatitude: 31.4267741218492,
      googleLongitude: 31.8008414813362,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Damietta Port Branch',
      location: 'Customer Service Building, Damietta Port',
      governorateName: 'Damietta',
      googleLatitude: 31.4469314893722,
      googleLongitude: 31.766732349862,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Alex. Downtown Branch',
      location: 'Before the International Garden, next to Carrefour Downtown',
      governorateName: 'Alexandria',
      googleLatitude: 31.1684673231238,
      googleLongitude: 29.9315208112566,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Ain El Sokhna Port Branch',
      location: 'El Soukhna Port (beside CIB branch) ',
      governorateName: 'El Ain El Sokhna',
      googleLatitude: 29.634713,
      googleLongitude: 32.308989,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Haram Branch',
      location: '85 El Harram St. ',
      governorateName: 'Giza',
      googleLatitude: 29.9892317212072,
      googleLongitude: 31.148652157758,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Horreya Branch',
      location: '73 El Horreya Road ',
      governorateName: 'Alexandria',
      googleLatitude: 31.1986914437351,
      googleLongitude: 29.9083787379804,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Mahalla  Branch',
      location: '10 Shoukry ElKawatly St., ElMahalla',
      governorateName: 'Mahalla',
      googleLatitude: 30.9769229089686,
      googleLongitude: 31.1707576533538,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Mandara Branch',
      location: '373 Al Gesh Rd., Al Mandara, Alexandria',
      governorateName: 'Alexandria',
      googleLatitude: 31.2463966250103,
      googleLongitude: 29.9661268339066,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Mansoura Branch',
      location: '199 El Gomhouria St., Borg kasr El Nil, Al Mansoura',
      governorateName: 'Mansoura',
      googleLatitude: 31.0475014442772,
      googleLongitude: 31.3842351582685,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Merag Branch',
      location: '10th Neighborhood, Merag City, New Maadi',
      governorateName: 'Cairo',
      googleLatitude: 29.974858,
      googleLongitude: 31.315527,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Mercato Branch',
      location: 'Hadabet Um El Sid, Sharm ElSheikh',
      governorateName: 'Sharm El Sheikh',
      googleLatitude: 27.9105119795466,
      googleLongitude: 34.3203252657936,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Mesaha Branch',
      location: '19 El Mesaha St., El Mesaha Tower, Dokki ',
      governorateName: 'Giza',
      googleLatitude: 30.0340512939477,
      googleLongitude: 31.2140202972729,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Nile Branch ',
      location: '3 Ibn Al Arhab St., Giza',
      governorateName: 'Giza',
      googleLatitude: 30.027080957819,
      googleLongitude: 31.2167990809912,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Suez Branch',
      location: '302 El Geish St., next to El suez police station ',
      governorateName: 'Suez',
      googleLatitude: 29.9642164414543,
      googleLongitude: 32.5559859016791,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Korba Branch  ',
      location: '6 Baghdad St., Korba, Heliopolis',
      governorateName: 'Cairo',
      googleLatitude: 30.0894163660218,
      googleLongitude: 31.3216102147846,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'El Sudan Branch',
      location: '1 khartoum St., 359 Sudan St., Mohandeseen ',
      governorateName: 'Giza',
      googleLatitude: 30.0703243746963,
      googleLongitude: 31.1985001106056,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Fairmont branch',
      location: 'Fairmont Hotel Nile City, Lower level',
      governorateName: 'Cairo',
      googleLatitude: 30.0715039960257,
      googleLongitude: 31.2276368478777,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Faisal Branch',
      location: '271 Faisal St., Police Buildings',
      governorateName: 'Giza',
      googleLatitude: 30.071766,
      googleLongitude: 31.227942,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'First Mall Branch',
      location: 'Giza St. ',
      governorateName: 'Giza',
      googleLatitude: 30.0242198229703,
      googleLongitude: 31.2171933415838,
      functionality: [],
      type: 'Branch'
    },
    {
      name: 'Four Seasons Branch',
      location: 'Kornish El Nil St.',
      governorateName: 'Cairo',
      googleLatitude: 30.0362346226495,
      googleLongitude: 31.2294049114806,
      functionality: [],
      type: 'Branch'
    },
    {
      name: 'Garden City Branch',
      location: '5 Midan Al Saray Al Kobra',
      governorateName: 'Cairo',
      googleLatitude: 30.0355435572727,
      googleLongitude: 31.232380770229,
      functionality: [],
      type: 'Branch'
    },
    {
      name: 'Golf Branch',
      location: '13 Al Nozha St. ',
      governorateName: 'Cairo',
      googleLatitude: 30.080418300494,
      googleLongitude: 31.3404368134527,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Gouna Branch ',
      location: 'Kafr Al Gouna, (H) building, Unit 102-103 ',
      governorateName: 'Cairo',
      googleLatitude: 27.3968289327246,
      googleLongitude: 33.6759250842379,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Abo El Hol Branch',
      location: '232 El Harram St.',
      governorateName: 'Giza',
      googleLatitude: 29.9984267360862,
      googleLongitude: 31.1716621765559,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Hayatt Sharm Branch',
      location: 'Hyatt Regency Hotel, Sharm ElSheikh ',
      governorateName: 'Sharm El Sheikh',
      googleLatitude: 27.9164397677085,
      googleLongitude: 34.3490571390884,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Hegaz Branch ',
      location: '33 Al Hegaz St., Heliopolis',
      governorateName: 'Cairo',
      googleLatitude: 30.099143833471,
      googleLongitude: 31.3235202795732,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Heliopolis Branch',
      location: '24 Cleopatra St. ',
      governorateName: 'Cairo',
      googleLatitude: 30.0916033460382,
      googleLongitude: 31.3285483905529,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Hurghada Branch',
      location: 'Lotus Elgawhara Project, ElKawthar, infront of Sindbad Aqua, Hurghada ',
      governorateName: 'Hurghada',
      googleLatitude: 27.1913661494941,
      googleLongitude: 33.8314980165365,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Ismailia Branch',
      location: 'Gamal Abd ElNasser St., ElAshry Tower',
      governorateName: 'Ismailia',
      googleLatitude: 30.6112538940234,
      googleLongitude: 32.2709825456028,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Kafr el Sheikh branch',
      location: '1 Salah Salem St., Venice tower 2',
      governorateName: 'Kafr ELSheikh',
      googleLatitude: 31.1137785335618,
      googleLongitude: 30.9383778795283,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Kasr El-Aini Branch',
      location: '8 Ibrahim Naguib St., Garden City',
      governorateName: 'Cairo',
      googleLatitude: 30.038110505153,
      googleLongitude: 31.2329490410099,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Kasr ElNil Branch',
      location: 'Kasr ElNil St. & Elwy St. Intersection ',
      governorateName: 'Cairo',
      googleLatitude: 30.0484552503662,
      googleLongitude: 31.2414441068732,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Luxor Branch',
      location: 'Khaled Ibn ElWaleed St.',
      governorateName: 'Luxor ',
      googleLatitude: 25.6883644384925,
      googleLongitude: 32.6320210170991,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Maadi Branch',
      location: 'Road No. 9, Maadi Palace Building, Station Sq.',
      governorateName: 'Cairo',
      googleLatitude: 29.9601220445345,
      googleLongitude: 31.2595134918361,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Maadi El Nasr Branch',
      location: '7/2 El Nasr St., El Shatr El Tasa, New Maadi ',
      governorateName: 'Cairo',
      googleLatitude: 29.9762351169404,
      googleLongitude: 31.2847714078466,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Laselky Branch',
      location: 'Shop No. 2&3, building No. 1/ 4 El Laselky St., New Maadi ',
      governorateName: 'Cairo',
      googleLatitude: 29.9771691634738,
      googleLongitude: 31.2827727048229,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Madinaty Branch',
      location: 'Banks District, 1st Stage, Madinaty ',
      governorateName: 'Cairo',
      googleLatitude: 30.1071521097164,
      googleLongitude: 31.6470052938577,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Mall of Egypt Branch',
      location: 'Gate #F2 Mall of Egypt, El Wahat Rd., 6th October City',
      governorateName: 'Cairo',
      googleLatitude: 29.9735162302873,
      googleLongitude: 31.0161216349104,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Menia Branch',
      location: 'Grand Aton Hotel, Corniche Al Nile St., Al Menya',
      governorateName: 'Menya ',
      googleLatitude: 28.1141015526036,
      googleLongitude: 30.7502407431103,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Merghany Branch',
      location: '140 El Merghany St. ',
      governorateName: 'Cairo',
      googleLatitude: 30.0896035923075,
      googleLongitude: 31.3392098738232,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Mivida Branch',
      location: 'Mivida Compound, Administrative building A2, New Cairo ',
      governorateName: 'Cairo',
      googleLatitude: 30.01029,
      googleLongitude: 31.537909,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Mohandeseen Branch',
      location: '48 Gezirat El Arab St.',
      governorateName: 'Giza',
      googleLatitude: 30.0560702772863,
      googleLongitude: 31.2011683273191,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Mokattam Branch',
      location: 'No. 354 - "D" Area, Nafoora Sq. ',
      governorateName: 'Cairo',
      googleLatitude: 30.0154528780128,
      googleLongitude: 31.281440217186,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Nadi el Seid Branch',
      location: '12 Nadi ElSeid St., Dokki ',
      governorateName: 'Giza',
      googleLatitude: 30.043072606414,
      googleLongitude: 31.2041827822075,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Nasr City Branch',
      location: '33 Abou Dawoud ElZahery St., off Makram Ebeid St.',
      governorateName: 'Cairo',
      googleLatitude: 30.0606749414398,
      googleLongitude: 31.3499763781186,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'National Research Center (NRC) Branch',
      location: 'National Research Center, El Behos St. ',
      governorateName: 'Giza',
      googleLatitude: 30.0357105253286,
      googleLongitude: 31.2051437338383,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Nawal Branch ',
      location: '5 Nawal St., 67 Soliman Gohar St., Dokki',
      governorateName: 'Giza',
      googleLatitude: 30.045600850712,
      googleLongitude: 31.2134550392698,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Neama Bay Branch',
      location: 'Sharm Trade Center, Mall 14, Naama Bay, Sharm ElSheikh ',
      governorateName: 'Sharm El Sheikh',
      googleLatitude: 27.9105180755798,
      googleLongitude: 34.3203233856012,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'New Cairo Branch ',
      location: 'Plot 116-118 First Sector, Parallel to Road 90 ',
      governorateName: 'Cairo',
      googleLatitude: 30.0186664128962,
      googleLongitude: 31.4231162473392,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Obour Branch ',
      location: 'Shop No. 60 & 61, Golf City Mall, El Obour City ',
      governorateName: 'Cairo',
      googleLatitude: 30.1725597675378,
      googleLongitude: 31.4763284473343,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Avenue Mall Branch',
      location: 'Avenue Mall, El Obour City',
      governorateName: 'Cairo',
      googleLatitude: 30.2025505761684,
      googleLongitude: 31.4545242050671,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Obour Building Branch ',
      location: '6 Obour building, Salah Salem St.',
      governorateName: 'Cairo',
      googleLatitude: 30.078974,
      googleLongitude: 31.313553,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Palm Strip Mall Branch',
      location: 'Palm Strip Mall, behind Dar Elfouad Hospital',
      governorateName: 'Giza',
      googleLatitude: 29.9908303140091,
      googleLongitude: 30.9673965260408,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Petroleum Complex Branch',
      location: 'Km 19, Alex-Cairo Desert Road',
      governorateName: 'Alexandria',
      googleLatitude: 31.1036966372696,
      googleLongitude: 29.8646419070666,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Point 90 Branch',
      location: 'Point 90 Mall, Street 90 (opposite AUC Gate 5), Fifth Settlement',
      governorateName: 'Cairo',
      googleLatitude: 30.0209316302463,
      googleLongitude: 31.4949946488505,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Portsaid Branch ',
      location: '21-23 July St., El Shark Zone, Portsaid ',
      governorateName: 'Portsaid',
      googleLatitude: 31.2693555214414,
      googleLongitude: 32.3068207006855,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Rehab Branch',
      location: 'Banks District, Building No. (4), El Rehab City',
      governorateName: 'Cairo',
      googleLatitude: 30.0586386482985,
      googleLongitude: 31.4921279469043,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Rihanna Residence (Nabq) Branch',
      location: 'Nabq Bay, Sharm ElSheikh ',
      governorateName: 'Sharm El Sheikh',
      googleLatitude: 28.0209143879027,
      googleLongitude: 34.4355313010198,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Roushdy Branch',
      location: '431 El Horreya Road, Roushdy ',
      governorateName: 'Alexandria',
      googleLatitude: 31.2271017793896,
      googleLongitude: 29.950887564304,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'San Stefano Branch',
      location: 'Shop No. (30A), San Stefano ',
      governorateName: 'Alexandria',
      googleLatitude: 31.2462141021629,
      googleLongitude: 29.9665539440204,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sarwat Branch',
      location: '44 Abdel Khalek Tharwat St. ',
      governorateName: 'Cairo',
      googleLatitude: 30.050586773554,
      googleLongitude: 31.24465869272,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Semouha Branch',
      location: '74 Albert Al Awal St., Baroun Tower, Semouha ',
      governorateName: 'Alexandria',
      googleLatitude: 31.2065166047805,
      googleLongitude: 29.9460182985677,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Shebeen El Koum Branch',
      location: '10 Samih Mubarak, Shebeen El Koum, Monofya',
      governorateName: 'Shbeen ElKoum',
      googleLatitude: 30.5640031482918,
      googleLongitude: 31.0103512500878,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sheikh Zayed Branch',
      location: 'Arkan Mall, in front of Zayed 2000 Compound, El Sheikh Zayed',
      governorateName: 'Giza',
      googleLatitude: 30.0206218268807,
      googleLongitude: 31.003012311425,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sheraton Branch',
      location: '13 Khaled Ibn Waleed St., Sheraton Buildings ',
      governorateName: 'Cairo',
      googleLatitude: 30.1031450232924,
      googleLongitude: 31.3776407352748,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sherouk Branch',
      location: 'City Plaza Mall, next to BUE, El Shourouk City                          ',
      governorateName: 'Cairo',
      googleLatitude: 30.1144968655807,
      googleLongitude: 31.6068952292702,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Shoubra Branch',
      location: 'Dawltyan St., El Khalafawy Sq., Shoubra',
      governorateName: 'Cairo',
      googleLatitude: 30.0999849318086,
      googleLongitude: 31.2425976795886,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sodic Branch',
      location: 'H5 Project Zee Strip (Sodic), El Sheikh Zaid City',
      governorateName: 'Giza',
      googleLatitude: 30.0552648069452,
      googleLongitude: 30.9427796406724,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Sohag Branch',
      location: '2 El Gomhoureya St. Corniche El Nil, Souhag',
      governorateName: 'Sohag',
      googleLatitude: 26.565408,
      googleLongitude: 31.696515,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Tanta Branch',
      location: '95 El Gesh St., Tanta ',
      governorateName: 'Tanta',
      googleLatitude: 30.8038695269492,
      googleLongitude: 30.9961488367961,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Tayraan Branch ',
      location: 'Tayaran St., Nasr City',
      governorateName: 'Cairo',
      googleLatitude: 30.071938,
      googleLongitude: 31.324174,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Zagazig Branch',
      location: '56 Saad Zaghloul St., Kornesh Rd., Zagazig El Sharqia ',
      governorateName: 'Zagazig',
      googleLatitude: 30.5839763901815,
      googleLongitude: 31.4892920956413,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Zamalek Branch ',
      location: '3 Hassan Sabry St. Zamalek',
      governorateName: 'Cairo',
      googleLatitude: 30.056644770467,
      googleLongitude: 31.2204617853779,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Zaytoun Branch  ',
      location: '10 Ibn Sandar Sq., Al Zaytoon, Cairo',
      governorateName: 'Cairo',
      googleLatitude: 30.0887655989934,
      googleLongitude: 31.3014684833656,
      type: 'Branch',
      functionality: ['western union']
    },
    {
      name: 'Park St. Branch  ',
      location:
        '17 El Bostan St. park St. Mall, Building 3, Unit #3005 & 3103, El Sheikh Zayed, 6th of October , Giza',
      governorateName: 'Giza',
      googleLatitude: 30.025234661538274,
      googleLongitude: 31.011056638501003,
      type: 'Branch',
      functionality: []
    }
  ]
};
