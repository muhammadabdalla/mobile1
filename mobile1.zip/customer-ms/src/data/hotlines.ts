export const hotlines: any = {
  en: [
    {
      name: 'Egypt',
      key: '',
      hotline: '19555',
      highlighted: true
    },
    {
      name: 'Overseas',
      key: '+202',
      hotline: '226733107'
    }
  ],
  ar: [
    {
      name: 'مصر',
      key: '',
      hotline: '19555',
      highlighted: true
    },
    {
      name: 'في الخارج',
      key: '+202',
      hotline: '226733107'
    }
  ]
};
