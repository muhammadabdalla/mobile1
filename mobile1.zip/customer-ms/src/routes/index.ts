import express from 'express';
import cards from './settings/index';
import mobilePhoneTransfer from './mobileTransfer/index';

const router = express.Router();

router.use('/customer/mobileTransfer', mobilePhoneTransfer);
router.use('/customer', cards);

export default router;
