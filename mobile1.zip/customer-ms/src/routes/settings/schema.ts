import Joi from 'joi';
import { filters } from '../../config';

export default {
  customer: {
    body: Joi.object({
      showSoftTokenApp: Joi.boolean().optional(),
      showBalance: Joi.boolean().optional(),
      showSharePopup: Joi.boolean().optional(),
      showMobileAdd: Joi.boolean().optional(),
      defaultAccount: Joi.string().optional(),
      pushId: Joi.string().optional().empty(''),
      pushNotifications: Joi.boolean().optional(),
      showMobileTransferPopup: Joi.boolean().optional(),
      kycLastUpdatedDate: Joi.string().optional().allow(''),
      registrationAlertUpdatedDate: Joi.string().optional().allow(''),
      tutorials: Joi.array().items(Joi.string()).optional(),
      hasReadNotification: Joi.boolean().optional(),
      lastNotificationId: Joi.string().optional(),
      showRatePopUp: Joi.boolean().optional(),
      lastRateDate: Joi.date().optional(),
      loginsInQuarterAfterRate: Joi.number().optional(),
      deliveryMechanismFirstTime: Joi.boolean().optional(),
      showLinkingPopUp: Joi.boolean().optional()
    })
  },
  staticPages: {
    query: Joi.object({
      type: Joi.string().optional().valid('login', 'profile', 'tips', 'otp')
    })
  },
  notification: {
    body: Joi.object({
      cif: Joi.string().required(),
      message: Joi.string().required(),
      notificationCode: Joi.string().required(),
      channel: Joi.string().required(),
      transactionSuccessful: Joi.boolean().optional()
    })
  },
  listOfAtms: {
    query: Joi.object({
      latitude: Joi.number().optional(),
      longitude: Joi.number().optional(),
      range: Joi.number().min(1).optional().allow(''),
      search: Joi.string().optional().allow(''),
      filter: Joi.string().valid(filters.all, filters.branch, filters.atm).required()
    })
  },
  getNotifications: {
    query: Joi.object({
      page: Joi.number().min(1).required(),
      limit: Joi.number().min(1).required()
    })
  },
  listOfBranches: {
    query: Joi.object({
      search: Joi.string().optional().allow('')
    })
  },
  checkLimit: {
    body: Joi.object({
      CountryCode: Joi.string().optional().allow(''),
      TransferScope: Joi.string().valid('DOM', 'INT', 'FX').required(),
      Amount: Joi.number().required(),
      Currency: Joi.string().required()
    })
  },
  chequebook: {
    body: Joi.object({
      AccId: Joi.string().required(),
      DeliveryBranch: Joi.string().required(),
      NoofChequeBooks: Joi.number().required(),
      NumberOfLeaves: Joi.number().valid(16, 24, 32, 40, 48).required(),
      Currency: Joi.string().required(),
      CountryCode: Joi.string().required().allow('')
    })
  },
  chequebookHistory: {
    query: Joi.object({
      accountId: Joi.string().required()
    })
  },
  ratings: {
    body: Joi.object({
      stars: Joi.number().min(1).max(5).required(),
      comment: Joi.string().optional()
    })
  },
  report: {
    body: Joi.object({
      category: Joi.string()
        .valid(
          'accounts',
          'creditCard',
          'loans',
          'investments',
          'transfers',
          'billPayment',
          'profile'
        )
        .required(),
      comment: Joi.string().required()
    })
  },

  ModifyEmail: {
    body: Joi.object({
      Email: Joi.string().required(),
      otp: Joi.string().length(6).required()
    })
  },

  UpdateDeliveryMechanism: {
    body: Joi.object({
      DeliveryMechanism: Joi.string().valid('Electronic', 'Send Mail').required()
    })
  }
};
