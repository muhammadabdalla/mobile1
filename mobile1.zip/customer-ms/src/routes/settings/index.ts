import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/settings';
import authenticate from '../../helpers/authenticate';
import { ProtectedRequest } from 'app-request';
const router = express.Router();
import { validate } from 'express-validation';
import schema from './schema';
import { defaultRadius } from '../../config';
import tracingHeaders from '../../helpers/tracingHeaders';

router.get(
  '/',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getUserSettings(req.user.cif);
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/',
  authenticate(),
  validate(schema.customer),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.updateUserSettings(req.user.cif, req.body);
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/faq',
  validate(schema.staticPages),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getFaq(
      String(req.query.type || 'login'),
      req.headers['accept-language']
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/hotlines',
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getHotline(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/notification',
  authenticate(),
  validate(schema.notification),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.sendNotification(req.body, tracingHeaders(req));
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/notifications',
  authenticate(),
  validate(schema.getNotifications),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getUserNotifications(
      req.user.cif,
      Number(req.query.page),
      Number(req.query.limit)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/termsAndConditions',
  authenticate(),
  validate(schema.staticPages),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getTermsAndConditions(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);
router.get(
  '/security/tips',
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getSecurityTips();
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/atms',
  validate(schema.listOfAtms),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getListOfAtms(
      req.query.latitude,
      req.query.longitude,
      Number(req.query.range || defaultRadius),
      req.query.search,
      String(req.query.filter),
      req.headers['accept-language']
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/branches',
  validate(schema.listOfBranches),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getListOfBranches(
      req.query.search,
      req.headers['accept-language']
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/checkLimit',
  authenticate(),
  validate(schema.checkLimit),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.checkLimit(
      req.user.cif,
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/chequebook/submit',
  validate(schema.chequebook),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.submitChequeBook(
      req.body,
      req.user.cif,
      req.user.id,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/chequebook/validate',
  validate(schema.chequebook),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.validateChequeBook(
      req.body,
      req.user.cif,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/chequebook/termsAndConditions',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getChequebookTermsAndConditions(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/chequebook/branches',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getChequebookBranches(
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/chequebook/history',
  validate(schema.chequebookHistory),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getChequebookHistory(
      String(req.query.accountId || ''),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/chequebook/history/unauth',
  validate(schema.chequebookHistory),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getChequebookUnauthHistory(
      String(req.query.accountId || ''),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/submit/rating',
  validate(schema.ratings),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.submitRating(
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      req.body,
      String(req.headers.platform)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/submit/report',
  validate(schema.report),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.reportIssue(
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      req.body,
      String(req.headers.platform)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/update/submit',
  validate(schema.ModifyEmail),
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.modifyEmail(
      req.user.cif,
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/address',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCustomerAddress(
      req.user.cif,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/update/deliveryStatment',
  authenticate(),
  validate(schema.UpdateDeliveryMechanism),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.UpdateDeliveryMechanism(
      req.user.cif,
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

export default router;
