import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/mobileTransfer';
import authenticate from '../../helpers/authenticate';
import { ProtectedRequest } from 'app-request';
const router = express.Router();
import { validate } from 'express-validation';
import schema from './schema';
import tracingHeaders from '../../helpers/tracingHeaders';

router.post(
  '/',
  authenticate(),
  validate(schema.addOrUpdateMobileTransfer),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.addOrUpdateCustomerMobileTransfer(
      req.user.cif,
      req.user.name,
      req.user.phoneNumber,
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/',
  authenticate(),
  validate(schema.getCustomerMobileTransfer),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const mobileNumber = String(req.query.mobileNumber || '');
    const result = await service.getCustomerMobileTransfer(
      req.user.cif,
      req.user.name,
      mobileNumber
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/validateMobileNumberForTransfer',
  authenticate(),
  validate(schema.verifyMobileNumber),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const mobileNumber = String(req.query.mobileNumber || '');
    const result = await service.validateMobileNumberForTransfer(mobileNumber, tracingHeaders(req));
    new SuccessResponse('Success', result).send(res);
  })
);

export default router;
