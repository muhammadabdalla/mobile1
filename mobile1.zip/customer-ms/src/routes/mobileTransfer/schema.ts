import Joi from 'joi';

export default {
  addOrUpdateMobileTransfer: {
    body: Joi.object({
      enabled: Joi.boolean().required(),
      accountNumber: Joi.string().when('enabled', {
        is: true,
        then: Joi.required(),
        otherwise: Joi.optional().allow('')
      })
    })
  },
  getCustomerMobileTransfer: {
    query: Joi.object({
      mobileNumber: Joi.string().optional(),
      cif: Joi.string().optional()
    })
  },
  verifyMobileNumber: {
    query: Joi.object({
      mobileNumber: Joi.string().required()
    })
  }
};
