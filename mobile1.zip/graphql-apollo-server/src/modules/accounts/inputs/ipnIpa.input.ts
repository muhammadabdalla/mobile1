import { InputType, Field } from 'type-graphql';
import { IsNotEmpty } from 'class-validator';

@InputType()
export class IpnIpaInput {
  @IsNotEmpty()
  @Field()
  AccId: string;

  @IsNotEmpty()
  @Field()
  Mobile: string;

  @IsNotEmpty()
  @Field()
  Type: string;

  @IsNotEmpty()
  @Field()
  Key: string;
}
