import { ObjectType, Field, Float } from 'type-graphql';

@ObjectType()
class scheduleTransferBody {
  @Field()
  debitAcc: string;

  @Field(() => Float)
  amount: number;

  @Field()
  description: string;

  @Field()
  currency: string;

  @Field()
  beneficiaryID: string;
}
@ObjectType()
class scheduleTransferIdBody {
  @Field()
  body: scheduleTransferBody;

  @Field()
  transferFrequency: string;

  @Field()
  scheduleDate: string;

  @Field({ nullable: true })
  nextTransferDate: string;

  @Field()
  user: string;

  @Field()
  userId: string;

  @Field()
  totalTransferCount: number;

  @Field()
  currentTransferCount: number;
}

@ObjectType()
export class ScheduledTransfersHistory {
  @Field()
  scheduleId: scheduleTransferIdBody;

  @Field()
  status: String;

  @Field()
  createdAt: String;

  @Field()
  updatedAt: String;
}
