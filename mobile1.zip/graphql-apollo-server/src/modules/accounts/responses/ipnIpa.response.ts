import { ObjectType, Field } from 'type-graphql';

@ObjectType()
export class IpnIpaResponse {
  @Field()
  Ipa: string;

  @Field()
  Name: string;
}
