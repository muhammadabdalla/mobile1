import { ObjectType, Field } from 'type-graphql';

@ObjectType()
export class TransferMethodsResponse {
  @Field()
  key: string;

  @Field()
  label: string;

  @Field()
  icon: string;

  @Field()
  logo: string;
}
