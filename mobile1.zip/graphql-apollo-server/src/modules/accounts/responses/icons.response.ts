import { Field, ObjectType } from 'type-graphql';

@ObjectType()
export class BankIcon {
  @Field({ nullable: true })
  name: string;

  @Field({ nullable: true })
  url: string;
}

@ObjectType()
export class BankIconUri {
  @Field({ nullable: true })
  name: string;

  @Field({ nullable: true })
  dataUri: string;
}

@ObjectType()
export class ThemeUri {
  @Field({ nullable: true })
  name: string;

  @Field({ nullable: true })
  dataUri: string;
}
