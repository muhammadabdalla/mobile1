import express from 'express';
import cards from './cards/index';

const router = express.Router();

router.use('/debit', cards);

export default router;
