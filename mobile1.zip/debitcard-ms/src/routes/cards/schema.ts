import Joi from 'joi';

export default {
  accountCards: {
    params: Joi.object().keys({
      account: Joi.string().required()
    })
  },
  setStatusCards: {
    body: Joi.object().keys({
      cardToken: Joi.string().required(),
      action: Joi.string().valid('Restrict', 'Normal', 'Stolen', 'Lost', 'Activate').required(),
      smsToken: Joi.when('action', {
        is: 'Activate',
        then: Joi.string().required()
      }).when('action', {
        is: 'Normal',
        then: Joi.string().required()
      })
    })
  },
  setLinkStateToAccount: {
    body: Joi.object().keys({
      CardToken: Joi.string().required(),
      AccId: Joi.string().required(),
      Action: Joi.string().valid('Active', 'Inactive').required()
    })
  },
  setPrimaryAccount: {
    body: Joi.object().keys({
      CardToken: Joi.string().required(),
      AccId: Joi.string().required(),
      Action: Joi.string().valid('Primary').required()
    })
  },

  setOnlineCards: {
    body: Joi.object().keys({
      cardToken: Joi.string().required(),
      action: Joi.string().valid('Enable', 'Disable').required()
    })
  },
  cardDetails: {
    body: Joi.object({
      cardNumber: Joi.string().required()
    })
  },
  getCardUsage: {
    body: Joi.object({
      cardToken: Joi.string().required()
    })
  },
  accountTransactions: {
    params: Joi.object({
      account: Joi.string().required()
    }),
    query: Joi.object({
      fromDate: Joi.string().optional(),
      toDate: Joi.string().optional(),
      search: Joi.string().optional(),
      lastTransaction: Joi.string().optional(),
      limit: Joi.number().optional().min(1).max(100),
      country: Joi.string().optional()
    })
  },
  enableTravelNote: {
    body: Joi.object().keys({
      CardToken: Joi.string().required(),
      Country: Joi.string().required(),
      FromDate: Joi.string().required(),
      ToDate: Joi.string().required(),
      MobileNo: Joi.string().required()
    })
  },
  getTravelNote: {
    query: Joi.object().keys({
      CardToken: Joi.string().required()
    })
  },
  replaceDebitCard: {
    body: Joi.object({
      cardNumber: Joi.string().required(),
      deliveryMethod: Joi.string().valid('pickup', 'delivery').required(),
      pickupBranch: Joi.alternatives().conditional('deliveryMethod', {
        is: 'pickup',
        then: Joi.string().required(),
        otherwise: Joi.string().optional().allow('')
      })
    })
  },
  canReplaceCard: {
    body: Joi.object({
      cardNumber: Joi.string().required()
    })
  },
  requestDebitCard: {
    body: Joi.object({
      accountNumber: Joi.string().required()
    })
  }
};
