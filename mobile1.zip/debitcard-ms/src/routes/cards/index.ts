import express from 'express';
import { SuccessResponse } from '../../core/ApiResponse';
import asyncHandler from '../../helpers/asyncHandler';
import * as service from '../../services/cards';
import { validate } from 'express-validation';
import authenticate from '../../helpers/authenticate';
import { ProtectedRequest } from 'app-request';
import schema from './schema';
import tracingHeaders from '../../helpers/tracingHeaders';
const router = express.Router();

router.get(
  '/account/:account',
  authenticate(),
  validate(schema.accountCards),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getDebitCardsPerAccount(
      parseInt(req.params.account),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/customer/cards/:account',
  authenticate(),
  validate(schema.accountCards),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getDebitCardsPerCustomer(
      parseInt(req.params.account),
      parseInt(req.user.cif),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/setstatus',
  authenticate(),
  validate(schema.setStatusCards),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.changeCardStatus(
      {
        CardToken: req.body.cardToken,
        Cif: req.user.cif,
        Action: req.body.action
      },
      req.user.id,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/setOnlineCards',
  authenticate(),
  validate(schema.setOnlineCards),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.changeOnlinePaymentStatus(
      {
        CardToken: req.body.cardToken,
        Cif: req.user.cif,
        Action: req.body.action
      },
      req.user.id,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/debitcardaccount/setStatus',
  authenticate(),
  validate(schema.setLinkStateToAccount),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.changeLinkStateToAccount(
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/debitcardaccount/setprimary',
  authenticate(),
  validate(schema.setPrimaryAccount),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.changeDefaultAccount(
      req.body,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/transactions/:account',
  authenticate(),
  validate(schema.accountTransactions),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getAccountTransactions(
      parseInt(req.params.account),
      {
        fromDate: String(req.query.fromDate || ''),
        toDate: String(req.query.toDate || ''),
        search: String(req.query.search || '').toLowerCase(),
        lastTransaction: String(req.query.lastTransaction || ''),
        limit: Number(req.query.limit || '0'),
        country: String(req.query.country || 'EG')
      },
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/travelNote/enable',
  authenticate(),
  validate(schema.enableTravelNote),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.enableTravelNote(
      {
        CardToken: req.body.CardToken,
        Country: req.body.Country,
        Cif: req.user.cif,
        FromDate: req.body.FromDate,
        ToDate: req.body.ToDate,
        MobileNo: req.body.MobileNo
      },
      req.user.id,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.delete(
  '/travelNote/delete/:id',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.deleteTravelNote(
      encodeURIComponent(req.params.id),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/travelNote/list',
  authenticate(),
  validate(schema.getTravelNote),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getTravelNotes(
      String(req.query.CardToken || ''),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/replace',
  authenticate(),
  validate(schema.replaceDebitCard),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.replaceDebitCard(
      req.body,
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      String(req.headers.platform),
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/canReplaceCard',
  authenticate(),
  validate(schema.canReplaceCard),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.canReplaceCard(req.body.cardNumber, req.user.cif);
    new SuccessResponse('Success', result).send(res);
  })
);

router.get(
  '/termsAndConditions',
  authenticate(),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getTermsAndConditions(req.headers['accept-language']);
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/card',
  authenticate(),
  validate(schema.cardDetails),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getDebitCardDetails(
      req.body.cardNumber,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/usage',
  authenticate(),
  validate(schema.getCardUsage),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.getCardUsage(
      req.body.cardToken,
      req.headers.authorization || '',
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

router.post(
  '/request',
  authenticate(),
  validate(schema.requestDebitCard),
  asyncHandler(async (req: ProtectedRequest, res) => {
    const result = await service.requestDebitCard(
      req.body.accountNumber,
      req.user.cif,
      req.user.id,
      req.user.phoneNumber,
      tracingHeaders(req)
    );
    new SuccessResponse('Success', result).send(res);
  })
);

export default router;
