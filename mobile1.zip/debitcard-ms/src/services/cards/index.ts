import { produce } from '../../kafka';
import {
  CardReplacementExistsError,
  ForbiddenError,
  InternalError,
  NotFoundError,
  OverlappingError
} from '../../core/ApiError';
import { logger } from '../../core/Logger';
import messages from '../../messages';
import moment from 'moment';
import * as lodash from 'lodash';
import { handlePagination } from '../../helpers/pagination';
import updateStatistics from '../../helpers/statistics';
import CardReplacement from '../../services/cards/model';
import {
  kafkaTopics,
  transOptions,
  status,
  deliveryMethod,
  defaultLanguage,
  customErrorTypes,
  languages
} from '../../config';
import { termsAndConditions } from '../../helpers/termsAndConditions';

export const getDebitCardsPerAccount = async (
  account: number,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcards/account/${account}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    return prepareKafkaResponse(producerData);
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const getDebitCardsPerCustomer = async (
  account: number,
  cif: number,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const customerCardsData = {
      route: `debitcards/customer/${cif}`,
      authorization
    };
    const accountCardsData = {
      route: `debitcards/account/${account}`,
      authorization
    };
    const producerCustomerData = await produce(customerCardsData, tracingHeaders);
    const producerAccountData = await produce(accountCardsData, tracingHeaders);
    const preparedCustomerData = await prepareKafkaResponse(producerCustomerData);
    const preparedAccountsData = await prepareKafkaResponse(producerAccountData);
    let isLinked = false;
    if (preparedCustomerData.length === preparedAccountsData.length) {
      isLinked = true;
    }
    return { isLinked, debitCards: preparedCustomerData };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const changeCardStatus = async (
  body: {
    CardToken: string;
    Cif: string;
    Action: string;
  },
  user: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcards/setstatus`,
      method: 'post',
      authorization,
      body
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'updateDebitCardStatus',
      requestType: body.Action,
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.success
    }).catch((e: any) => logger.error(e.message));
    return { message: 'Success' };
  } catch (e) {
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'updateDebitCardStatus',
      requestType: body.Action,
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.fail
    }).catch((e: any) => logger.error(e.message));
    logger.error(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const changeOnlinePaymentStatus = async (
  body: {
    CardToken: string;
    Cif: string;
    Action: string;
  },
  user: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcards/setonlinepayments`,
      method: 'post',
      authorization,
      body
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'updateOnlinePayment',
      requestType: body.Action,
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.success
    }).catch((e: any) => logger.error(e.message));
    return { message: 'Success' };
  } catch (e) {
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'updateOnlinePayment',
      requestType: body.Action,
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.fail
    }).catch((e: any) => logger.error(e.message));
    logger.error(e.message);
    if (e.message === 'cardNotActive') throw new ForbiddenError(messages.cards.notActive.en);
    else throw new InternalError(messages.cards.internalError.en);
  }
};

export const prepareKafkaResponse = async (message: any) => {
  if (!message.value) throw new InternalError(messages.cards.missingValue.en);
  const data = JSON.parse(message.value.toString());
  if (!data.error) {
    return data.message.Data || data.message.data;
  } else {
    logger.debug(data.message);
    if (data.message === messages.cards.notActive.en) throw new InternalError('cardNotActive');
    if (data.message === messages.cards.overlapping.en) throw new InternalError('overlappingError');
    else throw new InternalError(messages.cards.internalError.en);
  }
};

export const getAccountTransactions = async (
  account: number,
  query: {
    fromDate: string;
    toDate: string;
    search: string;
    lastTransaction: string;
    limit: number;
    country: string;
  },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const country = query.country;
    if (!query.toDate) query.toDate = moment().format(transOptions.dateFormat);
    if (!query.fromDate)
      query.fromDate = moment()
        .subtract(transOptions.duration, 'months')
        .format(transOptions.dateFormat);

    const data = {
      route: `account/txns/${account}/${query.fromDate}/${query.toDate}`,
      authorization,
      topic: kafkaTopics.t24Request,
      country
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    let filteredData: any = [];
    if (result && result.length) {
      result.map((item: any) => {
        if (item.isDbtCrdTrans) {
          item.correlationId = `${item.TransRef}-${item.Timestamp}`;
          filteredData.push(item);
        }
      });
    }
    const comparisonDate = moment().subtract(1, 'months').format(transOptions.dateFormat);
    if (query.toDate >= comparisonDate)
      filteredData = await mergeTransactions(
        filteredData,
        query.fromDate,
        query.toDate,
        account,
        authorization,
        tracingHeaders
      );

    if (query.search) filteredData = handleSearch(result, query.search);
    filteredData = lodash.orderBy(filteredData, ['Timestamp'], ['desc']);
    return {
      transactions: handlePagination(
        filteredData,
        query.limit || 20,
        query.lastTransaction || '',
        'correlationId'
      )
    };
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const mergeTransactions = async (
  completedResult: any[],
  fromDate: string,
  toDate: string,
  account: number,
  authorization: string,
  tracingHeaders: any
) => {
  const data = {
    route: `debitcards/periodpendingtxns/${account}/${fromDate}/${toDate}`,
    authorization,
    topic: kafkaTopics.t24Request
  };
  const producerData = await produce(data, tracingHeaders);
  const pendingResult = await prepareKafkaResponse(producerData);
  let mappingResult = [];
  let description: string;
  if (pendingResult && pendingResult.length) {
    mappingResult = pendingResult.map((item: any) => {
      description = item.TerminalLoc;
      if (item.TransactionType === 'Purchase') description = `POS Purchase - ${item.TerminalLoc}`;
      if (item.TransactionType === 'Withdrawal')
        description = `ATM Withdrawal - ${item.TerminalLoc}`;
      return {
        AccID: item.Account,
        BookingDate: item.FromDate,
        TransRef: item.IDRef,
        Description: description,
        Withdrawals: -item.SettlementAmount,
        Currency: item.SettlementCurrency,
        Deposits: 0,
        Timestamp: item.DateTime,
        ValueDate: item.ToDate,
        Status: 'pre-authorized',
        correlationId: `${item.IDRef}-${item.DateTime}`
      };
    });
  }
  return completedResult.concat(mappingResult);
};

export const enableTravelNote = async (
  body: {
    CardToken: string;
    Country: string;
    Cif: string;
    FromDate: string;
    ToDate: string;
    MobileNo: string;
  },
  user: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcards/settravelnote`,
      method: 'post',
      authorization,
      body
    };
    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'enableTravelWindow',
      startDate: body.FromDate,
      endDate: body.ToDate,
      countries: [body.Country],
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.success
    }).catch((e: any) => logger.error(e.message));
    return { message: 'Success' };
  } catch (e) {
    const cardNumber = await getCardByCardToken(body.CardToken, authorization, tracingHeaders);
    updateStatistics('', {
      cif: body.Cif,
      user,
      type: 'debitCardActions',
      subType: 'enableTravelWindow',
      startDate: body.FromDate,
      endDate: body.ToDate,
      countries: [body.Country],
      date: new Date(),
      microservice: 'debitCard',
      source: 'card',
      contractId: body.CardToken,
      cardNumber,
      status: status.fail
    }).catch((e: any) => logger.error(e.message));
    if (e.message === 'overlappingError') throw new OverlappingError();
    else throw new InternalError();
  }
};

export const deleteTravelNote = async (id: string, authorization: string, tracingHeaders: any) => {
  const data = {
    route: `debitcards/deletetravelnote/${id}`,
    method: 'delete',
    authorization
  };
  const producerData = await produce(data, tracingHeaders);
  await prepareKafkaResponse(producerData);
  return { message: 'Success' };
};

export const getTravelNotes = async (
  cardToken: string,
  authorization: string,
  tracingHeaders: any
) => {
  const data = {
    route: `debitcards/travelnotes/${cardToken.replace('?', '%3F')}`,
    authorization
  };
  const producerData = await produce(data, tracingHeaders);
  return prepareKafkaResponse(producerData);
};

export const handleSearch = (result: any, search: string) => {
  return lodash.filter(result, (item) => {
    return new RegExp('\\b' + search, 'gi').test(item.Description);
  });
};

export const getCardByCardToken = async (
  cardToken: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcards/cardtoken/${cardToken.replace('?', '%3F')}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const card = await prepareKafkaResponse(producerData);
    return card && card[0] ? card[0].CardNumber : '';
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError();
  }
};
export const getDebitCardDetails = async (
  cardNumber: string,
  authorization: string,
  tracingHeaders?: any
) => {
  try {
    const data = {
      route: `debitcards/card`,
      authorization,
      method: 'post',
      body: {
        CardNumber: cardNumber
      }
    };
    const producerData = await produce(data, tracingHeaders);
    const card = await prepareKafkaResponse(producerData);
    if (card && card.length > 0) {
      return card[0];
    } else {
      throw new NotFoundError();
    }
  } catch (e) {
    logger.debug(e.message);
    throw new NotFoundError();
  }
};
export const getCardUsage = async (
  cardToken: string,
  authorization: string,
  tracingHeaders?: any
) => {
  try {
    const data = {
      route: `debitcards/usage/${encodeURIComponent(cardToken)}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const result = await prepareKafkaResponse(producerData);
    if (result && result.length > 0) {
      return result[0];
    } else {
      throw new InternalError();
    }
  } catch (e) {
    logger.debug(e.message);
    throw new InternalError();
  }
};

export const replaceDebitCard = async (
  body: any,
  cif: string,
  user: string,
  phoneNumber: string,
  platform: string,
  authorization: string,
  tracingHeaders: any
) => {
  try {
    if (body.deliveryMethod === 'delivery') {
      const address = await getUserAddress(cif, authorization, tracingHeaders);
      body.deliveryMethod = deliveryMethod.delivery;
      body.cardExchangeLocation = address;
    } else {
      body.deliveryMethod = deliveryMethod.pickup;
      body.cardExchangeLocation = body.pickupBranch;
    }
    const data = {
      topic: kafkaTopics.smtp,
      function: 'sendEmailService',
      body,
      cif,
      template: 'replaceDebitCard'
    };
    await produce(data, tracingHeaders, false);

    const cardNumber = body.cardNumber.slice(-4);
    const exists: any = await CardReplacement.findOne({ cif, cardNumber, isCreditCard: false });
    if (exists) {
      throw new CardReplacementExistsError(messages.cards.CardReplacementExists.en, {
        date: moment(exists.createdAt).format('l')
      });
    }
    const cardReplacement = new CardReplacement({
      cif,
      cardNumber,
      isCreditCard: false
    });

    await cardReplacement.save();
    updateStatistics('', {
      cif,
      user,
      type: 'replace',
      subType: 'replaceDebitCard',
      date: new Date(),
      microservice: 'debitCard',
      platform,
      mobile: phoneNumber,
      status: status.success
    }).catch((e) => e.message);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    if (e.type === customErrorTypes.CardReplacementExistsError) {
      throw new CardReplacementExistsError(e.message, e.data);
    } else {
      throw new InternalError(e.message);
    }
  }
};

const getUserAddress = async (cif: string, authorization: string, tracingHeaders: any) => {
  try {
    const data = {
      topic: kafkaTopics.t24Request,
      route: `customer/${cif}`,
      authorization
    };
    const producerData = await produce(data, tracingHeaders);
    const kafkaData = await prepareKafkaResponse(producerData);
    if (kafkaData) {
      return kafkaData[0].Language.toString() === languages.english
        ? kafkaData[0].Address[0]
        : kafkaData[0].Address[1];
    } else return {};
  } catch (error) {
    logger.error(error.message);
    throw new InternalError();
  }
};

export const getTermsAndConditions = async (language = 'en') => {
  const data = termsAndConditions[language] || termsAndConditions[defaultLanguage];
  return { result: data.replace(/[\n]/gm, '') };
};

export const canReplaceCard = async (creditCardNumber: string, cif: string) => {
  const cardNumber = creditCardNumber.slice(-4);
  const exists: any = await CardReplacement.findOne({ cif, cardNumber, isCreditCard: false });
  if (exists) {
    throw new CardReplacementExistsError(messages.cards.CardReplacementExists.en, {
      date: moment(exists.createdAt).format('l')
    });
  } else {
    return { message: 'Success' };
  }
};

export const requestDebitCard = async (
  accountNumber: any,
  cif: string,
  user: string,
  phoneNumber: string,
  tracingHeaders: any
) => {
  try {
    await validateDebitAccount(accountNumber);
    const data = {
      topic: kafkaTopics.smtp,
      function: 'sendEmailService',
      body: {
        accountNumber
      },
      cif,
      template: 'debitCard'
    };
    await produce(data, tracingHeaders, false);
    updateStatistics('', {
      cif,
      user,
      type: 'request',
      subType: 'requestDebitCard',
      date: new Date(),
      microservice: 'debitCard',
      requestDetail: accountNumber,
      mobile: phoneNumber,
      status: status.success
    }).catch((e) => e.message);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(e.message);
  }
};

export const changeLinkStateToAccount = async (
  body: {
    CardToken: string;
    AccId: string;
    Action: string;
  },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcardaccount/setstatus`,
      method: 'post',
      authorization,
      body
    };

    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};

export const changeDefaultAccount = async (
  body: {
    CardToken: string;
    AccId: string;
    Action: string;
  },
  authorization: string,
  tracingHeaders: any
) => {
  try {
    const data = {
      route: `debitcardaccount/setprimary`,
      method: 'post',
      authorization,
      body
    };

    const producerData = await produce(data, tracingHeaders);
    await prepareKafkaResponse(producerData);
    return { message: 'Success' };
  } catch (e) {
    logger.error(e.message);
    throw new InternalError(messages.cards.internalError.en);
  }
};
export const validateDebitAccount = async (accountNumber: string) => {
  const draftAccRegex = /^[0-9]{8}15[0-9][1-9][0-9]{4}$/;
  if (draftAccRegex.test(accountNumber)) {
    throw new ForbiddenError(messages.accounts.overDraftAccount.en);
  }
};
