export default {
  accounts: {
    overDraftAccount: {
      en: 'Draft account not allowed to transfer'
    }
  },
  cards: {
    timeout: {
      en: 'Request Timeout'
    },
    missingValue: {
      en: 'Missing Value'
    },
    internalError: {
      en: 'Internal Server Error'
    },
    notActive: {
      en: 'Card not active'
    },
    overlapping: {
      en: 'Dates are overalapping with another travel window'
    },
    CardReplacementExists: {
      en: 'Card replacement already exists for this card'
    }
  },
  authorization: {
    notFound: {
      en: 'Authorization must be provided'
    },
    invalid: {
      en: 'Invalid token'
    }
  }
};
