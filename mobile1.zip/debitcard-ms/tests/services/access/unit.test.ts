import * as service from '../../../src/services/cards';
import {
  mockKafkaSuccess,
  cardsResult,
  transactionResult,
  travelNoteResult
} from '../../mocks/kafka';
import moment from 'moment';
import { transOptions } from '../../../src/config';
import { string } from 'joi';
const account = 10100111554400;
const fromDate = moment().subtract(transOptions.duration, 'months').format(transOptions.dateFormat);
const toDate = moment().format(transOptions.dateFormat);

describe('Get list of debit cards', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('Should return success', async () => {
    mockKafkaSuccess(fromDate, toDate);
    const response = await service.getDebitCardsPerAccount(account, 'npm', null);
    expect(response).toStrictEqual(cardsResult);
  });
});

describe('Change card status', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    const body = {
      CardToken: 'testCardToken',
      Cif: '11111',
      Action: 'Restrict'
    };
    const response = await service.changeCardStatus(body, '', '', null);
    expect(response).toStrictEqual({ message: 'Success' });
  });
});

describe('Change online payment', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    const body = {
      CardToken: 'testCardToken',
      Cif: '11111',
      Action: 'Enable'
    };
    const response = await service.changeOnlinePaymentStatus(body, '', '', null);
    expect(response).toStrictEqual({ message: 'Success' });
  });
});

describe('Get account transactions', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess(fromDate, toDate);
    const response = await service.getAccountTransactions(
      12345,
      {
        fromDate,
        toDate,
        search: '',
        lastTransaction: '',
        limit: 2,
        country: 'EG'
      },
      '',
      null
    );
    expect(response.transactions).toStrictEqual(transactionResult);
  });
});

describe('Get travel notes', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess(fromDate, toDate);
    const response = await service.getTravelNotes('12345', '', null);
    expect(response).toStrictEqual(travelNoteResult);
  });
});

describe('Add travel notes', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess(fromDate, toDate);
    const body = {
      CardToken: 'testCardToken',
      Country: 'LB',
      Cif: '10100111',
      FromDate: '20210101',
      ToDate: '20210102',
      MobileNo: 'test'
    };
    const response = await service.enableTravelNote(body, '', '', null);
    expect(response).toStrictEqual({ message: 'Success' });
  });
});

describe('Disable travel notes', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('Should return success', async () => {
    mockKafkaSuccess(fromDate, toDate);
    const response = await service.deleteTravelNote('123123', '', null);
    expect(response).toStrictEqual({ message: 'Success' });
  });
});
