import * as kafka from '../../src/kafka';
export const produceResult = {
  cards: {
    value:
      '{"error": false, "message": { "Data": [{"CardToken": "?testCardToken", "CustomerNo": "111111", "ExpiryDate": "20240531", "CardStatus": "ACTIVE", "OnlinePayment": true  }] }}'
  },
  empty: {
    value: '{"error": false, "message": { "Data": [] }}'
  },
  travelNote: {
    value:
      '{"error": false, "message": { "Data": [{ "Id": "MDAzfD9DNllXRTIyS1c2UU0yOEF8MTIxMTAzMHwxMTMxMzZ8LS0xMDAxMjYyNnwtLTEwMDEyNjI2fDQyMg==", "Country": "Lebanon" }] }}'
  },
  transactions: {
    value:
      '{"error": false, "message": { "Data": [{"AccID":"1010021511070201", "isDbtCrdTrans": true, "BookingDate":"20210101","TransRef":"FT210018CFXP","Description":"Quarterly Stamp Tax Deductions","ValueDate":"20201231","Withdrawals":-0.42,"Deposits":0,"Balance":-63.42,"Currency":"EGP", "correlationId": "FT210018CFXP-undefined"}] }}'
  },
  pendingTransactions: {
    value:
      '{"error": false, "message": { "Data": [{"Account":"1010021511070201","FromDate":"20210101","TerminalLoc": "Testing", "ToDate": "20210505", "IDRef":"FT210018CFXP","Description":"Quarterly Stamp Tax Deductions","ValueDate":"20201231","SettlementAmount":-0.42,"Deposits":0,"DateTime":"20201231.0000","SettlementCurrency":"EGP", "correlationId": "FT210018CFXP-undefined"}] }}'
  }
};
export const cardsResult = [
  {
    CardToken: '?testCardToken',
    CustomerNo: '111111',
    ExpiryDate: '20240531',
    CardStatus: 'ACTIVE',
    OnlinePayment: true
  }
];
export const travelNoteResult = [
  {
    Id: 'MDAzfD9DNllXRTIyS1c2UU0yOEF8MTIxMTAzMHwxMTMxMzZ8LS0xMDAxMjYyNnwtLTEwMDEyNjI2fDQyMg==',
    Country: 'Lebanon'
  }
];

export const transactionResult = [
  {
    AccID: '1010021511070201',
    BookingDate: '20210101',
    TransRef: 'FT210018CFXP',
    Description: 'Quarterly Stamp Tax Deductions',
    ValueDate: '20201231',
    Withdrawals: -0.42,
    Deposits: 0,
    correlationId: 'FT210018CFXP-undefined',
    Balance: -63.42,
    Currency: 'EGP',
    isDbtCrdTrans: true
  },
  {
    AccID: '1010021511070201',
    BookingDate: '20210101',
    TransRef: 'FT210018CFXP',
    Description: 'Testing',
    Withdrawals: 0.42,
    Currency: 'EGP',
    Deposits: 0,
    Timestamp: '20201231.0000',
    Status: 'pre-authorized',
    ValueDate: '20210505',
    correlationId: 'FT210018CFXP-20201231.0000'
  }
];

export const mockKafkaSuccess = (fromDate: string, toDate: string) => {
  jest.spyOn(kafka, 'createConsumer');
  const mock = jest.spyOn(kafka, 'produce');
  mock.mockImplementation(async (data) => {
    switch (data.route) {
      case 'debitcards/account/10100111554400':
        return Promise.resolve(produceResult.cards);
      case 'debitcards/setstatus':
        return Promise.resolve(produceResult.empty);
      case `debitcards/setonlinepayments`:
        return Promise.resolve(produceResult.empty);
      case `account/txns/12345/${fromDate}/${toDate}`:
        return Promise.resolve(produceResult.transactions);
      case `debitcards/periodpendingtxns/12345/${fromDate}/${toDate}`:
        return Promise.resolve(produceResult.pendingTransactions);
      case `debitcards/travelnotes/12345`:
        return Promise.resolve(produceResult.travelNote);
      case `debitcards/deletetravelnote/123123`:
        return Promise.resolve(produceResult.empty);
      case `debitcards/settravelnote`:
        return Promise.resolve(produceResult.empty);
      case `debitcards/cardtoken/testCardToken`:
        return Promise.resolve(produceResult.empty);
    }
  });
};
