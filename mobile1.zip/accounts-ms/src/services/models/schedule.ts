import mongoose from 'mongoose';
import { encryptionModel } from '../../helpers/encryptionModel';
import { SensitiveFields } from '../../helpers/enums/sensitiveFields';
import { encryptionConfig } from '../../config';

const model = new mongoose.Schema(
  {
    body: {
      debitAcc: String,
      amount: Number,
      description: String,
      currency: String,
      chargeType: String,
      beneficiaryID: mongoose.Types.ObjectId
    },
    transferFrequency: String,
    scheduleDate: Date,
    nextTransferDate: Date,
    currentTransferCount: { type: Number, default: 0 },
    //If total transfer count is 0, the number of transfers is considered infinite
    totalTransferCount: { type: Number, default: 0 },
    user: String,
    userId: String,
    platform: String,
    isEncrypted: Boolean
  },
  { timestamps: true }
);
model.index({ user: 1 });
model.index({ nextTransferDate: 1 });
if (encryptionConfig.ENCRYPTION === 'true') encryptionModel(model, SensitiveFields);
export default mongoose.model('ScheduleTransfer', model);
