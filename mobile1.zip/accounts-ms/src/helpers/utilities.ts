import { countries, listOfCurrencies } from '../config';

export function sortCurrencies(result: any, country: string = countries.EG): any {
  const firstCurrency = country === countries.AE ? listOfCurrencies.EGP : listOfCurrencies.USD;
  const desiredOrder: string[] = ['CHF', 'AED', 'SAR', 'EUR', 'GBP', 'USD', firstCurrency];

  const sortedData = result.sort((a: any, b: any) => {
    return desiredOrder.indexOf(a.CurrencyCode) - desiredOrder.indexOf(b.CurrencyCode);
  });
  sortedData.reverse();

  // Add this static data cause this is the reference for the currency rate
  sortedData.unshift(
    country === countries.AE
      ? {
          CountryCode: countries.AE,
          CurrencyCode: 'AED',
          CurrencyNameEnglish: 'U.A.E Dirham',
          CurrencyNameArabic: 'درهم اماراتي',
          CurrencyMultiplyDivider: 'M',
          CashBuyRate: 1,
          CashSellRate: 1,
          TransferBuyRate: 1,
          TransferSellRate: 1,
          LastUpdateDate: '20210728',
          LastUpdateTime: '11573010',
          Status: 'ACTIVE'
        }
      : {
          CountryCode: 'EG',
          CurrencyCode: 'EGP',
          CurrencyNameEnglish: 'Egyptian Pound',
          CurrencyNameArabic: 'الجنيه المصري',
          CurrencyMultiplyDivider: 'D',
          CashBuyRate: 1,
          CashSellRate: 1,
          TransferBuyRate: 1,
          TransferSellRate: 1,
          LastUpdateDate: 20230131,
          LastUpdateTime: 1328,
          Status: 'ACTIVE'
        }
  );
  return sortedData;
}
