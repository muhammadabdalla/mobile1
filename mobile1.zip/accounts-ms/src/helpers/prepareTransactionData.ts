import { dateMapping } from './dateMapping';

export default (data: any, fileExtensionType: string) => {
  if (fileExtensionType === 'excel') return data.map((item: any) => getTransactionData(item));

  const groupedData = data.reduce((result: any, item: any) => {
    const date = item.BookingDate;
    if (!result[date]) {
      result[date] = [];
    }
    result[date].push(getTransactionData(item));
    return result;
  }, {});
  return Object.entries(groupedData).map(([date, items]) => ({
    date: dateMapping(date),
    items
  }));
};

const getTransactionData = (transactionRecord: any) => {
  return {
    Description: transactionRecord.Description,
    BookingDate: transactionRecord.BookingDate,
    ValueDate: transactionRecord.ValueDate,
    Withdrawals: transactionRecord.Withdrawals,
    Deposits: transactionRecord.Deposits,
    Balance: transactionRecord.Balance,
    Currency: transactionRecord.Currency,
    Time: transactionRecord.Timestamp
  };
};
