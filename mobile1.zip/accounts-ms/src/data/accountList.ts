export default <any>{
  en: [
    {
      title: 'Current accounts',
      data: [
        {
          title: 'Daily Current account',
          label: 'currentDemand',
          value: 'DEMAND',
          onlyEGP: false,
          currencies: [
            {
              title: 'Common currencies',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                },
                {
                  ID: 'AED',
                  EnglishName: 'United Arab Emirates Dirham'
                }
              ]
            },
            {
              title: 'Other currencies',
              data: [
                {
                  ID: 'CAD',
                  EnglishName: 'Canadian Dollar'
                },
                {
                  ID: 'SAR',
                  EnglishName: 'Saudi Riyal'
                },
                {
                  ID: 'KWD',
                  EnglishName: 'Kuwaiti Dinar'
                },
                {
                  ID: 'CHF',
                  EnglishName: 'Swiss Franc'
                },
                {
                  ID: 'DKK',
                  EnglishName: 'Danish Krone'
                },
                {
                  ID: 'JPY',
                  EnglishName: 'Japanese Yen'
                },
                {
                  ID: 'SEK',
                  EnglishName: 'Swedish Krona'
                },
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: false
        },
        {
          title: 'Current / Call account',
          label: 'currentCall',
          value: 'CALL',
          onlyEGP: false,
          currencies: [
            {
              title: 'Common currencies',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                },
                {
                  ID: 'AED',
                  EnglishName: 'United Arab Emirates Dirham'
                }
              ]
            },
            {
              title: 'Other currencies',
              data: [
                {
                  ID: 'CAD',
                  EnglishName: 'Canadian Dollar'
                },
                {
                  ID: 'SAR',
                  EnglishName: 'Saudi Riyal'
                },
                {
                  ID: 'KWD',
                  EnglishName: 'Kuwaiti Dinar'
                },
                {
                  ID: 'CHF',
                  EnglishName: 'Swiss Franc'
                },
                {
                  ID: 'DKK',
                  EnglishName: 'Danish Krone'
                },
                {
                  ID: 'JPY',
                  EnglishName: 'Japanese Yen'
                },
                {
                  ID: 'SEK',
                  EnglishName: 'Swedish Krona'
                },
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: false
        }
      ]
    },
    {
      title: 'Saving accounts',
      data: [
        {
          title: 'Saving account',
          label: 'savingAccount',
          value: 'Saving',
          onlyEGP: false,
          currencies: [
            {
              title: 'Common currencies',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                }
              ]
            },
            {
              title: 'Other currencies',
              data: [
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: true
        },
        {
          title: 'Golden Saving Plus account',
          label: 'goldenSavingPlus',
          value: 'GOLDEN',
          onlyEGP: true,
          currencies: [
            {
              title: 'Common currencies',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                }
              ]
            },
            {
              title: 'Other currencies',
              data: []
            }
          ],
          hasFrequency: true
        }
      ]
    }
  ],
  ar: [
    {
      title: 'حسابات جارية',
      data: [
        {
          title: 'حساب جاري بعائد يومي',
          label: 'currentDemand',
          value: 'DEMAND',
          onlyEGP: false,
          currencies: [
            {
              title: 'العملات المتداولة',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                },
                {
                  ID: 'AED',
                  EnglishName: 'United Arab Emirates Dirham'
                }
              ]
            },
            {
              title: 'عملات أخري',
              data: [
                {
                  ID: 'CAD',
                  EnglishName: 'Canadian Dollar'
                },
                {
                  ID: 'SAR',
                  EnglishName: 'Saudi Riyal'
                },
                {
                  ID: 'KWD',
                  EnglishName: 'Kuwaiti Dinar'
                },
                {
                  ID: 'CHF',
                  EnglishName: 'Swiss Franc'
                },
                {
                  ID: 'DKK',
                  EnglishName: 'Danish Krone'
                },
                {
                  ID: 'JPY',
                  EnglishName: 'Japanese Yen'
                },
                {
                  ID: 'SEK',
                  EnglishName: 'Swedish Krona'
                },
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: false
        },
        {
          title: 'حساب جاري / تحت الطلب',
          label: 'currentCall',
          value: 'CALL',
          onlyEGP: false,
          currencies: [
            {
              title: 'العملات المتداولة',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                },
                {
                  ID: 'AED',
                  EnglishName: 'United Arab Emirates Dirham'
                }
              ]
            },
            {
              title: 'عملات أخري',
              data: [
                {
                  ID: 'CAD',
                  EnglishName: 'Canadian Dollar'
                },
                {
                  ID: 'SAR',
                  EnglishName: 'Saudi Riyal'
                },
                {
                  ID: 'KWD',
                  EnglishName: 'Kuwaiti Dinar'
                },
                {
                  ID: 'CHF',
                  EnglishName: 'Swiss Franc'
                },
                {
                  ID: 'DKK',
                  EnglishName: 'Danish Krone'
                },
                {
                  ID: 'JPY',
                  EnglishName: 'Japanese Yen'
                },
                {
                  ID: 'SEK',
                  EnglishName: 'Swedish Krona'
                },
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: false
        }
      ]
    },
    {
      title: 'حسابات توفير',
      data: [
        {
          title: 'حساب توفير',
          label: 'savingAccount',
          value: 'Saving',
          onlyEGP: false,
          currencies: [
            {
              title: 'العملات المتداولة',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                },
                {
                  ID: 'USD',
                  EnglishName: 'United States Dollar'
                },
                {
                  ID: 'EUR',
                  EnglishName: 'Euro'
                }
              ]
            },
            {
              title: 'عملات أخري',
              data: [
                {
                  ID: 'GBP',
                  EnglishName: 'Pound sterling'
                }
              ]
            }
          ],
          hasFrequency: true
        },
        {
          title: 'حساب توفير جولدن بلس',
          label: 'goldenSavingPlus',
          value: 'GOLDEN',
          onlyEGP: true,
          currencies: [
            {
              title: 'العملات المتداولة',
              data: [
                {
                  ID: 'EGP',
                  EnglishName: 'Egyptian Pound'
                }
              ]
            },
            {
              title: 'عملات أخري',
              data: []
            }
          ],
          hasFrequency: true
        }
      ]
    }
  ]
};
