export default interface FxResponse {
  Data: {
    SourceCurrency: string;
    DestinationCurrency: string;
    SourceAmount: number;
    DestinationAmount: number;
    ExchangeRate: number;
  }[];
}
