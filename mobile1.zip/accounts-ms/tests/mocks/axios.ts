import * as config from '../../src/config';
import axios from 'axios';

export const axiosResults = {
  conversion: { data: { Data: [{ CurrencyCode: 'EGP', TransferBuyRate: 1 }] } }
};

export const mockAxiosCall = (
  method: 'post' | 'get' | 'put' | 'delete',
  options: string | undefined
) => {
  const mock = jest.spyOn(axios, method);
  // @ts-ignore
  mock.mockImplementation(async (url) => {
    switch (url) {
      case `${config.cloudApiBaseUrl}/rates/exchange/EGP`:
        return Promise.resolve(axiosResults.conversion);
    }
    return Promise.resolve({});
  });
};
